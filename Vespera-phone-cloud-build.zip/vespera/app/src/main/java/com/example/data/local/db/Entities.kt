package com.example.data.local.db

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "users",
    indices = [Index(value = ["username"], unique = true)]
)
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val userId: Long = 0L,
    val username: String,
    val passwordHash: String,
    val salt: String,
    val avatarPath: String? = null,
    val avatarColorHex: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "songs",
    foreignKeys = [
        ForeignKey(
            entity = UserEntity::class,
            parentColumns = ["userId"],
            childColumns = ["ownerUserId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["ownerUserId"]),
        Index(value = ["ownerUserId", "downloadDate"]),
        Index(value = ["ownerUserId", "lastPlayedAt"])
    ]
)
data class SongEntity(
    @PrimaryKey(autoGenerate = true) val songId: Long = 0L,
    val ownerUserId: Long,
    val originalTitle: String,
    val customTitle: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val artworkPath: String? = null,
    val audioFilePath: String,
    val downloadDate: Long = System.currentTimeMillis(),
    val playCount: Int = 0,
    val lastPlayedAt: Long? = null,
    val fileSizeBytes: Long = 0L,
    val audioFormat: String = "M4A",
    val sourceType: String = "LOCAL", // "LOCAL" or "YOUTUBE"
    val sourceUrl: String? = null,
    val isFavorite: Boolean = false,
    val isAvailableOffline: Boolean = true
) {
    val displayTitle: String
        get() = customTitle.ifBlank { originalTitle }
}

@Entity(
    tableName = "playlists",
    foreignKeys = [
        ForeignKey(
            entity = UserEntity::class,
            parentColumns = ["userId"],
            childColumns = ["ownerUserId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["ownerUserId"])]
)
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val playlistId: Long = 0L,
    val ownerUserId: Long,
    val name: String,
    val customCoverPath: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val lastPlayedAt: Long? = null
)

@Entity(
    tableName = "playlist_songs",
    primaryKeys = ["playlistId", "songId"],
    foreignKeys = [
        ForeignKey(
            entity = PlaylistEntity::class,
            parentColumns = ["playlistId"],
            childColumns = ["playlistId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = SongEntity::class,
            parentColumns = ["songId"],
            childColumns = ["songId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["playlistId", "songId"], unique = true),
        Index(value = ["songId"])
    ]
)
data class PlaylistSongCrossRef(
    val playlistId: Long,
    val songId: Long,
    val position: Int,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "playback_history",
    foreignKeys = [
        ForeignKey(
            entity = UserEntity::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = SongEntity::class,
            parentColumns = ["songId"],
            childColumns = ["songId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["userId", "playedAt"]),
        Index(value = ["songId"]),
        Index(value = ["playlistId"])
    ]
)
data class PlaybackHistoryEntity(
    @PrimaryKey(autoGenerate = true) val historyId: Long = 0L,
    val userId: Long,
    val songId: Long,
    val playlistId: Long? = null,
    val playedAt: Long = System.currentTimeMillis(),
    val durationListenedMs: Long = 0L,
    val completed: Boolean = false
)

enum class DownloadStatus {
    QUEUED,
    FETCHING_INFO,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED
}

@Entity(
    tableName = "download_tasks",
    foreignKeys = [
        ForeignKey(
            entity = UserEntity::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["userId", "createdAt"])]
)
data class DownloadTaskEntity(
    @PrimaryKey val taskId: String,
    val userId: Long,
    val youtubeUrl: String,
    val videoId: String,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val thumbnailUrl: String? = null,
    val localThumbnailPath: String? = null,
    val tempAudioPath: String? = null,
    val audioQuality: String = "HIGH",
    val audioFormat: String = "M4A",
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val progressPercent: Int = 0,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,
    val speedBytesPerSec: Long = 0L,
    val etaSeconds: Long = -1L,
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "user_settings",
    foreignKeys = [
        ForeignKey(
            entity = UserEntity::class,
            parentColumns = ["userId"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class UserSettingsEntity(
    @PrimaryKey val userId: Long,
    val preferredQuality: String = "HIGH",
    val shuffleEnabled: Boolean = false,
    val repeatMode: Int = 0, // 0 = OFF, 1 = ONE, 2 = PLAYLIST
    val lastPlayingSongId: Long? = null,
    val lastPlayingPlaylistId: Long? = null,
    val lastPositionMs: Long = 0L,
    val autoFetchLyrics: Boolean = true,
    val keepScreenOnPlayer: Boolean = false
)

@Entity(
    tableName = "lyrics",
    primaryKeys = ["songId"],
    foreignKeys = [
        ForeignKey(
            entity = SongEntity::class,
            parentColumns = ["songId"],
            childColumns = ["songId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class LyricsEntity(
    val songId: Long,
    val userId: Long,
    val plainLyrics: String? = null,
    val syncedLrc: String? = null,
    val source: String = "MANUAL", // "LRCLIB" or "MANUAL"
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "shuffle_cycles",
    primaryKeys = ["cycleKey"]
)
data class ShuffleCycleEntity(
    val cycleKey: String, // "$userId:${playlistId ?: "library"}"
    val orderedSongIdsCsv: String,
    val currentIndex: Int,
    val lastCycleTailSongId: Long? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

data class PlaylistSongItem(
    @Embedded val song: SongEntity,
    val position: Int,
    val addedAt: Long
)

data class PlaylistWithMeta(
    val playlist: PlaylistEntity,
    val songCount: Int,
    val collageArtworks: List<String>
)
