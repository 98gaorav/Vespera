package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.ui.theme.*
import com.example.ui.util.parsePaletteColor
import java.io.File

@Composable
fun SongArtwork(
    artworkPath: String?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 12.dp
) {
    val shape = RoundedCornerShape(cornerRadius)
    val file = artworkPath?.let { File(it) }?.takeIf { it.exists() }

    if (file != null) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(file)
                .crossfade(true)
                .build(),
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier
                .clip(shape)
                .background(PaletteDeepNavy)
        )
    } else {
        Image(
            painter = painterResource(id = R.drawable.img_default_album_art),
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier
                .clip(shape)
                .background(PaletteDeepNavy)
        )
    }
}

@Composable
fun PlaylistCollageArtwork(
    customCoverPath: String?,
    collageArtworks: List<String>,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 14.dp
) {
    val shape = RoundedCornerShape(cornerRadius)
    val customFile = customCoverPath?.let { File(it) }?.takeIf { it.exists() }
    if (customFile != null) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(customFile)
                .crossfade(true)
                .build(),
            contentDescription = contentDescription,
            contentScale = ContentScale.Crop,
            modifier = modifier.clip(shape)
        )
        return
    }

    val validPaths = collageArtworks.filter { File(it).exists() }.take(4)
    when {
        validPaths.isEmpty() -> {
            Box(
                modifier = modifier
                    .clip(shape)
                    .background(
                        Brush.linearGradient(
                            colors = listOf(PaletteDeepNavy, PaletteDeepTeal, PaletteTerracotta)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.LibraryMusic,
                    contentDescription = contentDescription,
                    tint = PaletteCream,
                    modifier = Modifier.fillMaxSize(0.45f)
                )
            }
        }
        validPaths.size == 1 -> {
            SongArtwork(
                artworkPath = validPaths[0],
                contentDescription = contentDescription,
                modifier = modifier,
                cornerRadius = cornerRadius
            )
        }
        else -> {
            val padded = listOf(
                validPaths.getOrNull(0),
                validPaths.getOrNull(1),
                validPaths.getOrNull(2) ?: validPaths.getOrNull(1),
                validPaths.getOrNull(3) ?: validPaths.getOrNull(0)
            )
            Column(modifier = modifier.clip(shape)) {
                Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    SongArtwork(
                        artworkPath = padded[0],
                        contentDescription = null,
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        cornerRadius = 0.dp
                    )
                    SongArtwork(
                        artworkPath = padded[1],
                        contentDescription = null,
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        cornerRadius = 0.dp
                    )
                }
                Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    SongArtwork(
                        artworkPath = padded[2],
                        contentDescription = null,
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        cornerRadius = 0.dp
                    )
                    SongArtwork(
                        artworkPath = padded[3],
                        contentDescription = null,
                        modifier = Modifier.weight(1f).fillMaxHeight(),
                        cornerRadius = 0.dp
                    )
                }
            }
        }
    }
}

@Composable
fun UserAvatar(
    username: String,
    avatarPath: String?,
    avatarColorHex: String,
    size: Dp = 44.dp,
    modifier: Modifier = Modifier
) {
    val file = avatarPath?.let { File(it) }?.takeIf { it.exists() }
    if (file != null) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current)
                .data(file)
                .crossfade(true)
                .build(),
            contentDescription = "$username profile picture",
            contentScale = ContentScale.Crop,
            modifier = modifier
                .size(size)
                .clip(CircleShape)
                .background(PaletteDeepNavy)
        )
    } else {
        val bg = parsePaletteColor(avatarColorHex)
        val initial = username.trim().firstOrNull()?.uppercaseChar()?.toString() ?: "V"
        val textColor = if (bg == PaletteWarmOrange) NavyAbyss else PaletteCream
        Box(
            modifier = modifier
                .size(size)
                .clip(CircleShape)
                .background(bg),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = initial,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = textColor
            )
        }
    }
}

@Composable
fun AnimatedEqualizerBars(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    barColor: Color = PaletteWarmOrange
) {
    if (!isPlaying) {
        Row(
            modifier = modifier.height(14.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            repeat(3) { idx ->
                Box(
                    modifier = Modifier
                        .width(3.dp)
                        .height(if (idx == 1) 10.dp else 6.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(barColor.copy(alpha = 0.7f))
                )
            }
        }
        return
    }

    val transition = rememberInfiniteTransition(label = "eq_bars")
    val bar1 by transition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(420, easing = LinearEasing), RepeatMode.Reverse),
        label = "b1"
    )
    val bar2 by transition.animateFloat(
        initialValue = 0.9f,
        targetValue = 0.25f,
        animationSpec = infiniteRepeatable(tween(520, easing = LinearEasing), RepeatMode.Reverse),
        label = "b2"
    )
    val bar3 by transition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(tween(370, easing = LinearEasing), RepeatMode.Reverse),
        label = "b3"
    )
    Row(
        modifier = modifier.height(16.dp),
        horizontalArrangement = Arrangement.spacedBy(2.5.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        listOf(bar1, bar2, bar3).forEach { frac ->
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height((16 * frac).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(barColor)
            )
        }
    }
}
