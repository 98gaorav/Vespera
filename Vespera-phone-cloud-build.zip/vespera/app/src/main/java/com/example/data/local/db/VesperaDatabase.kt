package com.example.data.local.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

class VesperaConverters {
    @TypeConverter
    fun fromDownloadStatus(status: DownloadStatus): String = status.name

    @TypeConverter
    fun toDownloadStatus(value: String): DownloadStatus =
        runCatching { DownloadStatus.valueOf(value) }.getOrDefault(DownloadStatus.FAILED)
}

@Database(
    entities = [
        UserEntity::class,
        SongEntity::class,
        PlaylistEntity::class,
        PlaylistSongCrossRef::class,
        PlaybackHistoryEntity::class,
        DownloadTaskEntity::class,
        UserSettingsEntity::class,
        LyricsEntity::class,
        ShuffleCycleEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(VesperaConverters::class)
abstract class VesperaDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun songDao(): SongDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun playbackHistoryDao(): PlaybackHistoryDao
    abstract fun downloadTaskDao(): DownloadTaskDao
    abstract fun userSettingsDao(): UserSettingsDao
    abstract fun lyricsDao(): LyricsDao
    abstract fun shuffleCycleDao(): ShuffleCycleDao

    companion object {
        @Volatile
        private var INSTANCE: VesperaDatabase? = null

        fun getInstance(context: Context): VesperaDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    VesperaDatabase::class.java,
                    "vespera_offline_music.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
