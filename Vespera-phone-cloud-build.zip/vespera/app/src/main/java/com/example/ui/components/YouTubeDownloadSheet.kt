package com.example.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.local.db.DownloadStatus
import com.example.data.local.db.DownloadTaskEntity
import com.example.ui.YouTubePreviewState
import com.example.ui.theme.*
import com.example.ui.util.formatBytes
import com.example.ui.util.formatDurationMs
import com.example.ui.util.formatEtaSeconds
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun YouTubeDownloadSheet(
    state: YouTubePreviewState,
    onUrlChange: (String) -> Unit,
    onFetchInfo: (String?) -> Unit,
    onTitleChange: (String) -> Unit,
    onArtworkPicked: (android.net.Uri?) -> Unit,
    onQualityChange: (String) -> Unit,
    onStartDownload: () -> Unit,
    onDismiss: () -> Unit
) {
    val clipboard = LocalClipboardManager.current
    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> if (uri != null) onArtworkPicked(uri) }
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = NavySurface,
        contentColor = PaletteCream
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.DownloadForOffline,
                    contentDescription = null,
                    tint = PaletteWarmOrange,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "YouTube Audio Download",
                        style = MaterialTheme.typography.titleLarge,
                        color = PaletteCream
                    )
                    Text(
                        text = "Audio-only extraction for offline playback",
                        style = MaterialTheme.typography.bodySmall,
                        color = CreamSoft
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = state.urlInput,
                onValueChange = onUrlChange,
                singleLine = true,
                label = { Text("YouTube URL") },
                placeholder = { Text("https://youtu.be/...") },
                trailingIcon = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(
                            onClick = {
                                val pasted = clipboard.getText()?.text.orEmpty()
                                if (pasted.isNotBlank()) {
                                    onUrlChange(pasted)
                                    onFetchInfo(pasted)
                                }
                            },
                            modifier = Modifier.testTag("yt_paste_button")
                        ) {
                            Text("Paste", color = PaletteWarmOrange)
                        }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PaletteWarmOrange,
                    unfocusedBorderColor = PaletteDeepTeal,
                    focusedTextColor = PaletteCream,
                    unfocusedTextColor = PaletteCream,
                    focusedLabelColor = PaletteWarmOrange,
                    unfocusedLabelColor = CreamSoft
                ),
                modifier = Modifier.fillMaxWidth().testTag("yt_url_input")
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = { onFetchInfo(null) },
                enabled = !state.isFetching && state.urlInput.isNotBlank(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = PaletteDeepTeal,
                    contentColor = PaletteCream
                ),
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("yt_fetch_info_button")
            ) {
                if (state.isFetching) {
                    CircularProgressIndicator(
                        color = PaletteCream,
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Fetching Audio Metadata…")
                } else {
                    Icon(Icons.Rounded.Search, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Retrieve Track Info")
                }
            }

            if (state.error != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    color = TerracottaDeep,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = state.error,
                        style = MaterialTheme.typography.bodySmall,
                        color = PaletteCream,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            AnimatedVisibility(visible = state.trackInfo != null) {
                val info = state.trackInfo
                if (info != null) {
                    Column(modifier = Modifier.padding(top = 16.dp)) {
                        Surface(
                            color = PaletteDeepNavy,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(74.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable {
                                            photoPicker.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        }
                                ) {
                                    AsyncImage(
                                        model = ImageRequest.Builder(LocalContext.current)
                                            .data(state.customArtworkUri ?: info.thumbnailUrl)
                                            .crossfade(true)
                                            .build(),
                                        contentDescription = "Track thumbnail",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .padding(4.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(NavyAbyss.copy(alpha = 0.85f))
                                            .padding(4.dp)
                                    ) {
                                        Icon(
                                            Icons.Rounded.Edit,
                                            contentDescription = "Replace artwork",
                                            tint = PaletteWarmOrange,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = info.artist,
                                        style = MaterialTheme.typography.labelMedium,
                                        color = PaletteWarmOrange,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Duration: ${if (info.durationMs > 0) formatDurationMs(info.durationMs) else "Auto"}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CreamSoft
                                    )
                                    Text(
                                        text = "Tap artwork to customize",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CreamMuted
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = state.editableTitle,
                            onValueChange = onTitleChange,
                            label = { Text("Song name") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PaletteWarmOrange,
                                unfocusedBorderColor = PaletteDeepTeal,
                                focusedTextColor = PaletteCream,
                                unfocusedTextColor = PaletteCream,
                                focusedLabelColor = PaletteWarmOrange,
                                unfocusedLabelColor = CreamSoft
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("yt_editable_title")
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Audio Quality (M4A Audio-Only)",
                            style = MaterialTheme.typography.titleSmall,
                            color = PaletteCream
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            listOf(
                                "HIGH" to "High",
                                "STANDARD" to "Standard",
                                "DATA_SAVER" to "Saver"
                            ).forEach { (key, label) ->
                                val selected = state.selectedQuality == key
                                FilterChip(
                                    selected = selected,
                                    onClick = { onQualityChange(key) },
                                    label = { Text(label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = PaletteWarmOrange,
                                        selectedLabelColor = NavyAbyss,
                                        containerColor = NavyAbyss,
                                        labelColor = PaletteCream
                                    ),
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.weight(1f).height(50.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, PaletteDeepTeal)
                ) {
                    Text("Cancel", color = PaletteCream)
                }
                Button(
                    onClick = onStartDownload,
                    enabled = state.trackInfo != null && !state.isFetching,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = PaletteWarmOrange,
                        contentColor = NavyAbyss
                    ),
                    modifier = Modifier.weight(1.4f).height(50.dp).testTag("yt_start_download_button")
                ) {
                    Icon(Icons.Rounded.Download, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Download Audio", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun ActiveDownloadsSection(
    tasks: List<DownloadTaskEntity>,
    onPause: (String) -> Unit,
    onResume: (String) -> Unit,
    onCancel: (String) -> Unit,
    onDismissFailed: (String) -> Unit
) {
    if (tasks.isEmpty()) return

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(
            text = "Active Downloads",
            style = MaterialTheme.typography.titleMedium,
            color = PaletteWarmOrange
        )
        tasks.forEach { task ->
            ActiveDownloadCard(
                task = task,
                onPause = { onPause(task.taskId) },
                onResume = { onResume(task.taskId) },
                onCancel = { onCancel(task.taskId) },
                onDismissFailed = { onDismissFailed(task.taskId) }
            )
        }
    }
}

@Composable
private fun ActiveDownloadCard(
    task: DownloadTaskEntity,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onDismissFailed: () -> Unit
) {
    val progressFrac = (task.progressPercent.coerceIn(0, 100)) / 100f
    Surface(
        color = PaletteDeepNavy,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, PaletteDeepTeal.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Vertical progress indicator as explicitly required
            Box(
                modifier = Modifier
                    .width(8.dp)
                    .height(64.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(NavyAbyss)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(progressFrac.coerceAtLeast(0.06f))
                        .align(Alignment.BottomCenter)
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            if (task.status == DownloadStatus.FAILED) PaletteTerracotta
                            else PaletteWarmOrange
                        )
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            AsyncImage(
                model = task.localThumbnailPath?.let { File(it) } ?: task.thumbnailUrl,
                contentDescription = task.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(54.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(NavyAbyss)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Song: ${task.title}",
                    style = MaterialTheme.typography.titleSmall,
                    color = PaletteCream,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                val statusLine = when (task.status) {
                    DownloadStatus.QUEUED -> "Queued…"
                    DownloadStatus.FETCHING_INFO -> "Extracting audio stream…"
                    DownloadStatus.DOWNLOADING -> "Download progress: ${task.progressPercent}%"
                    DownloadStatus.PAUSED -> "Paused at ${task.progressPercent}%"
                    DownloadStatus.FAILED -> task.errorMessage ?: "Download failed"
                    else -> "${task.progressPercent}%"
                }
                Text(
                    text = statusLine,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (task.status == DownloadStatus.FAILED) PaletteTerracotta else PaletteWarmOrange
                )
                if (task.status == DownloadStatus.DOWNLOADING) {
                    val sizeText = if (task.totalBytes > 0L) {
                        "${formatBytes(task.downloadedBytes)} / ${formatBytes(task.totalBytes)}"
                    } else {
                        formatBytes(task.downloadedBytes)
                    }
                    Text(
                        text = "$sizeText · ${formatEtaSeconds(task.etaSeconds)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = CreamSoft,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Row {
                when (task.status) {
                    DownloadStatus.DOWNLOADING, DownloadStatus.FETCHING_INFO, DownloadStatus.QUEUED -> {
                        IconButton(onClick = onPause, modifier = Modifier.minimumInteractiveComponentSize()) {
                            Icon(Icons.Rounded.PauseCircle, contentDescription = "Pause download", tint = PaletteCream)
                        }
                    }
                    DownloadStatus.PAUSED -> {
                        IconButton(onClick = onResume, modifier = Modifier.minimumInteractiveComponentSize()) {
                            Icon(Icons.Rounded.PlayCircle, contentDescription = "Resume download", tint = PaletteWarmOrange)
                        }
                    }
                    DownloadStatus.FAILED -> {
                        IconButton(onClick = onResume, modifier = Modifier.minimumInteractiveComponentSize()) {
                            Icon(Icons.Rounded.Refresh, contentDescription = "Retry download", tint = PaletteWarmOrange)
                        }
                    }
                    else -> {}
                }
                IconButton(
                    onClick = if (task.status == DownloadStatus.FAILED) onDismissFailed else onCancel,
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Rounded.Close, contentDescription = "Cancel download", tint = PaletteTerracotta)
                }
            }
        }
    }
}
