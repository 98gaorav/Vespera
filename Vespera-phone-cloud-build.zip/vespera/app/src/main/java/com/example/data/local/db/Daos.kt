package com.example.data.local.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("SELECT * FROM users WHERE LOWER(username) = LOWER(:username) LIMIT 1")
    suspend fun findByUsername(username: String): UserEntity?

    @Query("SELECT * FROM users WHERE userId = :userId LIMIT 1")
    fun observeUserById(userId: Long): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE userId = :userId LIMIT 1")
    suspend fun getUserById(userId: Long): UserEntity?

    @Query("SELECT * FROM users ORDER BY createdAt ASC")
    fun observeAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE userId IN (:userIds) ORDER BY createdAt ASC")
    fun observeUsersByIds(userIds: List<Long>): Flow<List<UserEntity>>
}

@Dao
interface SongDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSong(song: SongEntity): Long

    @Update
    suspend fun updateSong(song: SongEntity)

    @Query("SELECT * FROM songs WHERE ownerUserId = :userId AND isAvailableOffline = 1 ORDER BY downloadDate DESC")
    fun observeAllSongs(userId: Long): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE ownerUserId = :userId AND isAvailableOffline = 1 AND lastPlayedAt IS NOT NULL ORDER BY lastPlayedAt DESC LIMIT 12")
    fun observeRecentlyPlayed(userId: Long): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE ownerUserId = :userId AND isAvailableOffline = 1 ORDER BY downloadDate DESC LIMIT 10")
    fun observeRecentlyAdded(userId: Long): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE ownerUserId = :userId AND isAvailableOffline = 1 AND isFavorite = 1 ORDER BY customTitle ASC")
    fun observeFavoriteSongs(userId: Long): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE songId = :songId LIMIT 1")
    fun observeSongById(songId: Long): Flow<SongEntity?>

    @Query("SELECT * FROM songs WHERE songId = :songId LIMIT 1")
    suspend fun getSongById(songId: Long): SongEntity?

    @Query("SELECT * FROM songs WHERE ownerUserId = :userId AND isAvailableOffline = 1 AND (customTitle LIKE '%' || :query || '%' OR originalTitle LIKE '%' || :query || '%' OR artist LIKE '%' || :query || '%' OR album LIKE '%' || :query || '%') ORDER BY playCount DESC, customTitle ASC")
    fun searchSongs(userId: Long, query: String): Flow<List<SongEntity>>

    @Query("UPDATE songs SET customTitle = :newTitle WHERE songId = :songId")
    suspend fun renameSong(songId: Long, newTitle: String)

    @Query("UPDATE songs SET artworkPath = :artworkPath WHERE songId = :songId")
    suspend fun updateArtwork(songId: Long, artworkPath: String?)

    @Query("UPDATE songs SET isFavorite = :favorite WHERE songId = :songId")
    suspend fun setFavorite(songId: Long, favorite: Boolean)

    @Query("UPDATE songs SET playCount = playCount + 1, lastPlayedAt = :playedAt WHERE songId = :songId")
    suspend fun incrementPlayCount(songId: Long, playedAt: Long)

    @Query("DELETE FROM songs WHERE songId = :songId")
    suspend fun deleteSongById(songId: Long)

    @Query("SELECT COUNT(*) FROM songs WHERE ownerUserId = :userId AND isAvailableOffline = 1")
    fun observeDownloadedCount(userId: Long): Flow<Int>

    @Query("SELECT COALESCE(SUM(fileSizeBytes), 0) FROM songs WHERE ownerUserId = :userId AND isAvailableOffline = 1")
    fun observeTotalStorageBytes(userId: Long): Flow<Long>

    @Query("SELECT * FROM songs WHERE ownerUserId = :userId AND isAvailableOffline = 1 AND playCount > 0 ORDER BY playCount DESC, lastPlayedAt DESC")
    fun observeTopPlayedSongs(userId: Long): Flow<List<SongEntity>>
}

@Dao
interface PlaylistDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Update
    suspend fun updatePlaylist(playlist: PlaylistEntity)

    @Query("DELETE FROM playlists WHERE playlistId = :playlistId")
    suspend fun deletePlaylistById(playlistId: Long)

    @Query("SELECT * FROM playlists WHERE ownerUserId = :userId ORDER BY updatedAt DESC")
    fun observePlaylists(userId: Long): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists WHERE ownerUserId = :userId AND lastPlayedAt IS NOT NULL ORDER BY lastPlayedAt DESC LIMIT 8")
    fun observeRecentlyPlayedPlaylists(userId: Long): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists WHERE playlistId = :playlistId LIMIT 1")
    fun observePlaylistById(playlistId: Long): Flow<PlaylistEntity?>

    @Query("SELECT * FROM playlists WHERE playlistId = :playlistId LIMIT 1")
    suspend fun getPlaylistById(playlistId: Long): PlaylistEntity?

    @Query("SELECT * FROM playlists WHERE ownerUserId = :userId AND name LIKE '%' || :query || '%' ORDER BY updatedAt DESC")
    fun searchPlaylists(userId: Long, query: String): Flow<List<PlaylistEntity>>

    @Query("UPDATE playlists SET lastPlayedAt = :playedAt WHERE playlistId = :playlistId")
    suspend fun updateLastPlayed(playlistId: Long, playedAt: Long)

    @Query("UPDATE playlists SET name = :name, updatedAt = :updatedAt WHERE playlistId = :playlistId")
    suspend fun renamePlaylist(playlistId: Long, name: String, updatedAt: Long)

    @Query("UPDATE playlists SET customCoverPath = :coverPath, updatedAt = :updatedAt WHERE playlistId = :playlistId")
    suspend fun updatePlaylistCover(playlistId: Long, coverPath: String?, updatedAt: Long)

    @Query("SELECT s.*, ps.position AS position, ps.addedAt AS addedAt FROM songs s INNER JOIN playlist_songs ps ON s.songId = ps.songId WHERE ps.playlistId = :playlistId ORDER BY ps.position ASC")
    fun observeSongsInPlaylist(playlistId: Long): Flow<List<PlaylistSongItem>>

    @Query("SELECT s.*, ps.position AS position, ps.addedAt AS addedAt FROM songs s INNER JOIN playlist_songs ps ON s.songId = ps.songId WHERE ps.playlistId = :playlistId ORDER BY ps.position ASC")
    suspend fun getSongsInPlaylistOnce(playlistId: Long): List<PlaylistSongItem>

    @Query("SELECT songId FROM playlist_songs WHERE playlistId = :playlistId")
    fun observeSongIdsInPlaylist(playlistId: Long): Flow<List<Long>>

    @Query("SELECT playlistId FROM playlist_songs WHERE songId = :songId")
    fun observePlaylistIdsContainingSong(songId: Long): Flow<List<Long>>

    @Query("SELECT COUNT(*) FROM playlist_songs WHERE playlistId = :playlistId")
    suspend fun getPlaylistSongCount(playlistId: Long): Int

    @Query("SELECT COALESCE(MAX(position), 0) FROM playlist_songs WHERE playlistId = :playlistId")
    suspend fun getMaxPosition(playlistId: Long): Int

    @Query("SELECT EXISTS(SELECT 1 FROM playlist_songs WHERE playlistId = :playlistId AND songId = :songId)")
    suspend fun isSongInPlaylist(playlistId: Long, songId: Long): Boolean

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPlaylistSong(crossRef: PlaylistSongCrossRef): Long

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun removePlaylistSongRaw(playlistId: Long, songId: Long)

    @Query("SELECT * FROM playlist_songs WHERE playlistId = :playlistId ORDER BY position ASC")
    suspend fun getCrossRefsOrdered(playlistId: Long): List<PlaylistSongCrossRef>

    @Query("UPDATE playlist_songs SET position = :position WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun updatePosition(playlistId: Long, songId: Long, position: Int)

    @Query("UPDATE playlists SET updatedAt = :updatedAt WHERE playlistId = :playlistId")
    suspend fun touchPlaylist(playlistId: Long, updatedAt: Long)

    @Transaction
    suspend fun addSongsPreventDuplicates(playlistId: Long, songIds: List<Long>) {
        var nextPos = getMaxPosition(playlistId) + 1
        var addedAny = false
        for (songId in songIds) {
            if (!isSongInPlaylist(playlistId, songId)) {
                insertPlaylistSong(
                    PlaylistSongCrossRef(
                        playlistId = playlistId,
                        songId = songId,
                        position = nextPos++
                    )
                )
                addedAny = true
            }
        }
        if (addedAny) {
            touchPlaylist(playlistId, System.currentTimeMillis())
        }
    }

    @Transaction
    suspend fun removeSongAndRenumber(playlistId: Long, songId: Long) {
        removePlaylistSongRaw(playlistId, songId)
        val remaining = getCrossRefsOrdered(playlistId)
        remaining.forEachIndexed { index, ref ->
            val targetPos = index + 1
            if (ref.position != targetPos) {
                updatePosition(playlistId, ref.songId, targetPos)
            }
        }
        touchPlaylist(playlistId, System.currentTimeMillis())
    }

    @Transaction
    suspend fun renumberAllPlaylistsContainingSong(songId: Long, playlistIds: List<Long>) {
        for (pid in playlistIds) {
            val remaining = getCrossRefsOrdered(pid)
            remaining.forEachIndexed { index, ref ->
                val targetPos = index + 1
                if (ref.position != targetPos) {
                    updatePosition(pid, ref.songId, targetPos)
                }
            }
            touchPlaylist(pid, System.currentTimeMillis())
        }
    }
}

@Dao
interface PlaybackHistoryDao {
    @Insert
    suspend fun insertHistory(history: PlaybackHistoryEntity): Long

    @Query("UPDATE playback_history SET durationListenedMs = :durationMs, completed = :completed WHERE historyId = :historyId")
    suspend fun updateHistoryDuration(historyId: Long, durationMs: Long, completed: Boolean)

    @Query("SELECT * FROM playback_history WHERE userId = :userId AND playedAt >= :sinceTimestamp ORDER BY playedAt DESC")
    fun observeHistorySince(userId: Long, sinceTimestamp: Long): Flow<List<PlaybackHistoryEntity>>

    @Query("SELECT COALESCE(SUM(durationListenedMs), 0) FROM playback_history WHERE userId = :userId AND playedAt >= :sinceTimestamp")
    fun observeTotalListeningMsSince(userId: Long, sinceTimestamp: Long): Flow<Long>

    @Query("SELECT COUNT(*) FROM playback_history WHERE userId = :userId AND playedAt >= :sinceTimestamp")
    fun observeTotalPlaysSince(userId: Long, sinceTimestamp: Long): Flow<Int>

    @Query("SELECT playlistId FROM playback_history WHERE userId = :userId AND playlistId IS NOT NULL AND playedAt >= :sinceTimestamp GROUP BY playlistId ORDER BY COUNT(*) DESC LIMIT 1")
    fun observeMostPlayedPlaylistIdSince(userId: Long, sinceTimestamp: Long): Flow<Long?>
}

@Dao
interface DownloadTaskDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTask(task: DownloadTaskEntity)

    @Query("SELECT * FROM download_tasks WHERE userId = :userId AND status IN ('QUEUED', 'FETCHING_INFO', 'DOWNLOADING', 'PAUSED', 'FAILED') ORDER BY createdAt DESC")
    fun observeActiveTasks(userId: Long): Flow<List<DownloadTaskEntity>>

    @Query("SELECT * FROM download_tasks WHERE userId = :userId ORDER BY createdAt DESC LIMIT 25")
    fun observeRecentTasks(userId: Long): Flow<List<DownloadTaskEntity>>

    @Query("SELECT * FROM download_tasks WHERE taskId = :taskId LIMIT 1")
    suspend fun getTaskById(taskId: String): DownloadTaskEntity?

    @Query("UPDATE download_tasks SET status = :status WHERE taskId = :taskId")
    suspend fun updateStatus(taskId: String, status: DownloadStatus)

    @Query("DELETE FROM download_tasks WHERE taskId = :taskId")
    suspend fun deleteTask(taskId: String)
}

@Dao
interface UserSettingsDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSettings(settings: UserSettingsEntity)

    @Query("SELECT * FROM user_settings WHERE userId = :userId LIMIT 1")
    fun observeSettings(userId: Long): Flow<UserSettingsEntity?>

    @Query("SELECT * FROM user_settings WHERE userId = :userId LIMIT 1")
    suspend fun getSettingsOnce(userId: Long): UserSettingsEntity?
}

@Dao
interface LyricsDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertLyrics(lyrics: LyricsEntity)

    @Query("SELECT * FROM lyrics WHERE songId = :songId LIMIT 1")
    fun observeLyrics(songId: Long): Flow<LyricsEntity?>

    @Query("SELECT * FROM lyrics WHERE songId = :songId LIMIT 1")
    suspend fun getLyricsOnce(songId: Long): LyricsEntity?
}

@Dao
interface ShuffleCycleDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertCycle(cycle: ShuffleCycleEntity)

    @Query("SELECT * FROM shuffle_cycles WHERE cycleKey = :cycleKey LIMIT 1")
    suspend fun getCycle(cycleKey: String): ShuffleCycleEntity?

    @Query("DELETE FROM shuffle_cycles WHERE cycleKey = :cycleKey")
    suspend fun deleteCycle(cycleKey: String)
}
