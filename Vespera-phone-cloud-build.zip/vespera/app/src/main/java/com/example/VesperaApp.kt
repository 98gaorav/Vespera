package com.example

import android.app.Application
import com.example.data.local.db.VesperaDatabase
import com.example.data.local.storage.LocalStorageManager
import com.example.data.network.LyricsRepository
import com.example.data.network.YouTubeAudioExtractor
import com.example.data.preferences.SessionManager
import com.example.data.repository.*
import com.example.player.PlaybackController

class AppContainer(application: Application) {
    val database: VesperaDatabase = VesperaDatabase.getInstance(application)
    val sessionManager = SessionManager(application)
    val storageManager = LocalStorageManager(application)
    val youTubeExtractor = YouTubeAudioExtractor()

    val authRepository = AuthRepository(
        userDao = database.userDao(),
        settingsDao = database.userSettingsDao(),
        sessionManager = sessionManager,
        storageManager = storageManager
    )
    val musicRepository = MusicRepository(
        songDao = database.songDao(),
        playlistDao = database.playlistDao(),
        storageManager = storageManager
    )
    val playlistRepository = PlaylistRepository(
        playlistDao = database.playlistDao(),
        storageManager = storageManager
    )
    val analyticsRepository = AnalyticsRepository(
        songDao = database.songDao(),
        playlistDao = database.playlistDao(),
        historyDao = database.playbackHistoryDao()
    )
    val lyricsRepository = LyricsRepository(
        lyricsDao = database.lyricsDao()
    )
    val downloadRepository = DownloadRepository(
        context = application,
        downloadTaskDao = database.downloadTaskDao(),
        extractor = youTubeExtractor,
        storageManager = storageManager
    )
    val playbackController = PlaybackController(
        context = application,
        songDao = database.songDao(),
        playlistDao = database.playlistDao(),
        historyDao = database.playbackHistoryDao(),
        settingsDao = database.userSettingsDao(),
        shuffleCycleDao = database.shuffleCycleDao()
    )
}

class VesperaApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
