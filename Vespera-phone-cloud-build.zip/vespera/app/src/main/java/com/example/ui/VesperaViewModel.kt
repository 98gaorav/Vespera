package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.VesperaApp
import com.example.data.local.db.*
import com.example.data.network.LrcLine
import com.example.data.network.LrcParser
import com.example.data.network.YouTubeTrackInfo
import com.example.data.repository.AnalyticsRange
import com.example.data.repository.AnalyticsSnapshot
import com.example.player.PlaybackUiState
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class YouTubePreviewState(
    val urlInput: String = "",
    val isFetching: Boolean = false,
    val trackInfo: YouTubeTrackInfo? = null,
    val editableTitle: String = "",
    val customArtworkUri: Uri? = null,
    val selectedQuality: String = "HIGH",
    val error: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class VesperaViewModel(application: Application) : AndroidViewModel(application) {

    private val container = (application as VesperaApp).container
    private val authRepo = container.authRepository
    private val musicRepo = container.musicRepository
    private val playlistRepo = container.playlistRepository
    private val analyticsRepo = container.analyticsRepository
    private val lyricsRepo = container.lyricsRepository
    private val downloadRepo = container.downloadRepository
    private val playbackController = container.playbackController
    private val settingsDao = container.database.userSettingsDao()

    private val _sessionLoaded = MutableStateFlow(false)
    val sessionLoaded: StateFlow<Boolean> = _sessionLoaded.asStateFlow()

    val activeUserId: StateFlow<Long?> = authRepo.activeUserId
        .onEach { uid ->
            _sessionLoaded.value = true
            playbackController.onUserChanged(uid)
        }
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    val activeUser: StateFlow<UserEntity?> = authRepo.activeUser
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val signedInAccounts: StateFlow<List<UserEntity>> = authRepo.signedInAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allRegisteredAccounts: StateFlow<List<UserEntity>> = authRepo.allRegisteredAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSongs: StateFlow<List<SongEntity>> = activeUserId.flatMapLatest { uid ->
        if (uid == null) flowOf(emptyList()) else musicRepo.observeAllSongs(uid)
    }.onEach { songs ->
        playbackController.syncCollectionSongs(songs)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentlyPlayedSongs: StateFlow<List<SongEntity>> = activeUserId.flatMapLatest { uid ->
        if (uid == null) flowOf(emptyList()) else musicRepo.observeRecentlyPlayed(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentlyAddedSongs: StateFlow<List<SongEntity>> = activeUserId.flatMapLatest { uid ->
        if (uid == null) flowOf(emptyList()) else musicRepo.observeRecentlyAdded(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalStorageBytes: StateFlow<Long> = activeUserId.flatMapLatest { uid ->
        if (uid == null) flowOf(0L) else musicRepo.observeTotalStorageBytes(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val playlistsWithMeta: StateFlow<List<PlaylistWithMeta>> = activeUserId.flatMapLatest { uid ->
        if (uid == null) flowOf(emptyList()) else playlistRepo.observePlaylistsWithMeta(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentlyPlayedPlaylists: StateFlow<List<PlaylistWithMeta>> = activeUserId.flatMapLatest { uid ->
        if (uid == null) flowOf(emptyList()) else playlistRepo.observeRecentlyPlayedPlaylists(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeDownloads: StateFlow<List<DownloadTaskEntity>> = activeUserId.flatMapLatest { uid ->
        if (uid == null) flowOf(emptyList()) else downloadRepo.observeActiveTasks(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userSettings: StateFlow<UserSettingsEntity?> = activeUserId.flatMapLatest { uid ->
        if (uid == null) flowOf(null) else settingsDao.observeSettings(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val playbackState: StateFlow<PlaybackUiState> = playbackController.uiState

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val searchMatchedSongs: StateFlow<List<SongEntity>> = combine(activeUserId, _searchQuery) { uid, q ->
        uid to q.trim()
    }.flatMapLatest { (uid, q) ->
        if (uid == null || q.isEmpty()) flowOf(emptyList()) else musicRepo.searchSongs(uid, q)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchMatchedPlaylists: StateFlow<List<PlaylistWithMeta>> = combine(playlistsWithMeta, _searchQuery) { lists, q ->
        val clean = q.trim()
        if (clean.isEmpty()) emptyList()
        else lists.filter { it.playlist.name.contains(clean, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchMatchedArtists: StateFlow<List<String>> = combine(allSongs, _searchQuery) { songs, q ->
        val clean = q.trim()
        if (clean.isEmpty()) emptyList()
        else songs.map { it.artist }.distinct().filter { it.contains(clean, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchMatchedAlbums: StateFlow<List<String>> = combine(allSongs, _searchQuery) { songs, q ->
        val clean = q.trim()
        if (clean.isEmpty()) emptyList()
        else songs.map { it.album }.distinct().filter { it.contains(clean, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _analyticsRange = MutableStateFlow(AnalyticsRange.ALL_TIME)
    val analyticsRange: StateFlow<AnalyticsRange> = _analyticsRange.asStateFlow()

    val analyticsSnapshot: StateFlow<AnalyticsSnapshot> = combine(activeUserId, _analyticsRange) { uid, range ->
        uid to range
    }.flatMapLatest { (uid, range) ->
        if (uid == null) flowOf(AnalyticsSnapshot(range = range))
        else analyticsRepo.observeAnalytics(uid, range)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AnalyticsSnapshot())

    val currentSongLyrics: StateFlow<LyricsEntity?> = playbackState.map { it.currentSong?.songId }
        .distinctUntilChanged()
        .flatMapLatest { songId ->
            if (songId == null) flowOf(null) else lyricsRepo.observeLyrics(songId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val parsedLrcLines: StateFlow<List<LrcLine>> = currentSongLyrics.map { entity ->
        LrcParser.parse(entity?.syncedLrc)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _lyricsLoading = MutableStateFlow(false)
    val lyricsLoading: StateFlow<Boolean> = _lyricsLoading.asStateFlow()

    private val _youtubePreview = MutableStateFlow(YouTubePreviewState())
    val youtubePreview: StateFlow<YouTubePreviewState> = _youtubePreview.asStateFlow()

    private val _uiMessages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val uiMessages: SharedFlow<String> = _uiMessages.asSharedFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _authBusy = MutableStateFlow(false)
    val authBusy: StateFlow<Boolean> = _authBusy.asStateFlow()

    // Track completed download count to trigger UI celebration animation
    val recentDownloads: StateFlow<List<DownloadTaskEntity>> = activeUserId.flatMapLatest { uid ->
        if (uid == null) flowOf(emptyList()) else downloadRepo.observeRecentTasks(uid)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Auth Actions ---

    fun clearAuthError() {
        _authError.value = null
    }

    fun login(username: String, password: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _authBusy.value = true
            _authError.value = null
            val res = authRepo.login(username, password)
            _authBusy.value = false
            res.onSuccess {
                _uiMessages.tryEmit("Welcome back, ${it.username}")
                onSuccess()
            }.onFailure {
                _authError.value = it.message ?: "Login failed"
            }
        }
    }

    fun signUp(username: String, password: String, confirmPassword: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _authBusy.value = true
            _authError.value = null
            val res = authRepo.signUp(username, password, confirmPassword)
            _authBusy.value = false
            res.onSuccess {
                _uiMessages.tryEmit("Account created for ${it.username}")
                onSuccess()
            }.onFailure {
                _authError.value = it.message ?: "Sign up failed"
            }
        }
    }

    fun switchAccount(userId: Long) {
        viewModelScope.launch {
            authRepo.switchAccount(userId).onSuccess {
                _uiMessages.tryEmit("Switched account")
            }.onFailure {
                _uiMessages.tryEmit(it.message ?: "Unable to switch account")
            }
        }
    }

    fun signOutActive() {
        viewModelScope.launch {
            authRepo.signOutActive()
            _uiMessages.tryEmit("Signed out")
        }
    }

    fun changePassword(current: String, next: String, confirm: String, onSuccess: () -> Unit) {
        val uid = activeUserId.value ?: return
        viewModelScope.launch {
            authRepo.changePassword(uid, current, next, confirm)
                .onSuccess {
                    _uiMessages.tryEmit("Password updated securely")
                    onSuccess()
                }
                .onFailure {
                    _uiMessages.tryEmit(it.message ?: "Password update failed")
                }
        }
    }

    fun updateProfilePicture(uri: Uri) {
        val uid = activeUserId.value ?: return
        viewModelScope.launch {
            authRepo.updateProfilePicture(uid, uri)
                .onSuccess { _uiMessages.tryEmit("Profile picture updated") }
                .onFailure { _uiMessages.tryEmit("Failed to update picture") }
        }
    }

    // --- Library & Song Management ---

    fun importAudioFiles(uris: List<Uri>) {
        val uid = activeUserId.value ?: return
        if (uris.isEmpty()) return
        viewModelScope.launch {
            var count = 0
            for (uri in uris) {
                musicRepo.importLocalAudio(uid, uri).onSuccess { count++ }
            }
            if (count > 0) {
                _uiMessages.tryEmit("Imported $count audio track${if (count > 1) "s" else ""} offline")
            } else {
                _uiMessages.tryEmit("Could not import selected audio file(s)")
            }
        }
    }

    fun renameSong(songId: Long, newTitle: String) {
        viewModelScope.launch {
            musicRepo.renameSong(songId, newTitle)
                .onSuccess { _uiMessages.tryEmit("Song renamed") }
                .onFailure { _uiMessages.tryEmit(it.message ?: "Rename failed") }
        }
    }

    fun updateSongArtwork(songId: Long, uri: Uri) {
        val uid = activeUserId.value ?: return
        viewModelScope.launch {
            musicRepo.updateSongArtwork(uid, songId, uri)
                .onSuccess { _uiMessages.tryEmit("Artwork updated") }
                .onFailure { _uiMessages.tryEmit("Unable to update artwork") }
        }
    }

    fun toggleFavorite(songId: Long) {
        viewModelScope.launch { musicRepo.toggleFavorite(songId) }
    }

    fun deleteSong(songId: Long) {
        viewModelScope.launch {
            musicRepo.deleteSongPermanently(songId)
            _uiMessages.tryEmit("Song deleted from device")
        }
    }

    fun observeSongById(songId: Long): Flow<SongEntity?> = musicRepo.observeSongById(songId)

    // --- YouTube Download Flow ---

    fun updateYouTubeUrl(url: String) {
        _youtubePreview.update { it.copy(urlInput = url, error = null) }
    }

    fun updateYouTubeEditableTitle(title: String) {
        _youtubePreview.update { it.copy(editableTitle = title) }
    }

    fun updateYouTubeCustomArtwork(uri: Uri?) {
        _youtubePreview.update { it.copy(customArtworkUri = uri) }
    }

    fun updateYouTubeQuality(quality: String) {
        _youtubePreview.update { it.copy(selectedQuality = quality) }
    }

    fun resetYouTubePreview() {
        val defaultQual = userSettings.value?.preferredQuality ?: "HIGH"
        _youtubePreview.value = YouTubePreviewState(selectedQuality = defaultQual)
    }

    fun fetchYouTubeInfo(urlOverride: String? = null) {
        val targetUrl = (urlOverride ?: _youtubePreview.value.urlInput).trim()
        if (targetUrl.isEmpty()) {
            _youtubePreview.update { it.copy(error = "Paste a YouTube link first.") }
            return
        }
        if (!downloadRepo.isValidYouTubeUrl(targetUrl)) {
            _youtubePreview.update { it.copy(error = "Invalid YouTube URL. Supported: youtube.com, youtu.be, music.youtube.com") }
            return
        }
        viewModelScope.launch {
            _youtubePreview.update { it.copy(urlInput = targetUrl, isFetching = true, error = null) }
            downloadRepo.fetchYouTubeMetadata(targetUrl)
                .onSuccess { info ->
                    _youtubePreview.update {
                        it.copy(
                            isFetching = false,
                            trackInfo = info,
                            editableTitle = info.title,
                            error = null
                        )
                    }
                }
                .onFailure { err ->
                    _youtubePreview.update {
                        it.copy(isFetching = false, error = err.message ?: "Could not fetch video info")
                    }
                }
        }
    }

    fun startYouTubeDownload(onQueued: () -> Unit) {
        val uid = activeUserId.value ?: return
        val preview = _youtubePreview.value
        val info = preview.trackInfo
        if (info == null) {
            _youtubePreview.update { it.copy(error = "Fetch video details first.") }
            return
        }
        viewModelScope.launch {
            downloadRepo.enqueueDownload(
                userId = uid,
                youtubeUrl = preview.urlInput,
                videoId = info.videoId,
                customTitle = preview.editableTitle.ifBlank { info.title },
                artist = info.artist,
                durationMs = info.durationMs,
                thumbnailUrl = info.thumbnailUrl,
                customArtworkUri = preview.customArtworkUri,
                quality = preview.selectedQuality
            )
            resetYouTubePreview()
            _uiMessages.tryEmit("Audio download started in background")
            onQueued()
        }
    }

    fun pauseDownload(taskId: String) {
        viewModelScope.launch { downloadRepo.pauseDownload(taskId) }
    }

    fun resumeDownload(taskId: String) {
        viewModelScope.launch { downloadRepo.resumeDownload(taskId) }
    }

    fun cancelDownload(taskId: String) {
        viewModelScope.launch {
            downloadRepo.cancelDownload(taskId)
            _uiMessages.tryEmit("Download cancelled")
        }
    }

    fun dismissDownloadTask(taskId: String) {
        viewModelScope.launch { downloadRepo.dismissTask(taskId) }
    }

    // --- Playlists ---

    fun observePlaylist(playlistId: Long): Flow<PlaylistEntity?> = playlistRepo.observePlaylistById(playlistId)
    fun observePlaylistSongs(playlistId: Long): Flow<List<PlaylistSongItem>> = playlistRepo.observeSongsInPlaylist(playlistId)
    fun observePlaylistsContainingSong(songId: Long): Flow<List<Long>> = playlistRepo.observePlaylistIdsContainingSong(songId)

    fun createPlaylist(name: String, coverUri: Uri?, songIds: List<Long>, onCreated: (Long) -> Unit) {
        val uid = activeUserId.value ?: return
        viewModelScope.launch {
            playlistRepo.createPlaylist(uid, name, coverUri, songIds)
                .onSuccess { pid ->
                    _uiMessages.tryEmit("Playlist created")
                    onCreated(pid)
                }
                .onFailure { _uiMessages.tryEmit(it.message ?: "Failed to create playlist") }
        }
    }

    fun toggleSongInPlaylist(playlistId: Long, playlistName: String, songId: Long) {
        viewModelScope.launch {
            val added = playlistRepo.toggleSongInPlaylist(playlistId, songId)
            _uiMessages.tryEmit(
                if (added) "Added to $playlistName" else "Removed from $playlistName"
            )
        }
    }

    fun addSongsToPlaylist(playlistId: Long, songIds: List<Long>) {
        viewModelScope.launch {
            playlistRepo.addSongsToPlaylist(playlistId, songIds)
            _uiMessages.tryEmit("Added songs to playlist")
        }
    }

    fun removeSongFromPlaylist(playlistId: Long, songId: Long) {
        viewModelScope.launch {
            playlistRepo.removeSongFromPlaylist(playlistId, songId)
            _uiMessages.tryEmit("Song removed & playlist renumbered")
        }
    }

    fun renamePlaylist(playlistId: Long, newName: String) {
        viewModelScope.launch { playlistRepo.renamePlaylist(playlistId, newName) }
    }

    fun updatePlaylistCover(playlistId: Long, uri: Uri) {
        val uid = activeUserId.value ?: return
        viewModelScope.launch { playlistRepo.updatePlaylistCover(uid, playlistId, uri) }
    }

    fun deletePlaylist(playlistId: Long, onDeleted: () -> Unit = {}) {
        viewModelScope.launch {
            playlistRepo.deletePlaylist(playlistId)
            _uiMessages.tryEmit("Playlist deleted")
            onDeleted()
        }
    }

    // --- Playback ---

    fun playSong(song: SongEntity, collection: List<SongEntity> = allSongs.value, playlistId: Long? = null, sourceLabel: String = "Offline Library") {
        playbackController.playSongFromCollection(song, collection, playlistId, sourceLabel)
        maybeAutoFetchLyrics(song)
    }

    fun playOnRepeat(song: SongEntity, collection: List<SongEntity> = allSongs.value, playlistId: Long? = null, sourceLabel: String = "Offline Library") {
        playbackController.setRepeatOne(song, collection, playlistId, sourceLabel)
        maybeAutoFetchLyrics(song)
        _uiMessages.tryEmit("Playing '${song.displayTitle}' on repeat")
    }

    fun playPlaylist(songs: List<SongEntity>, playlistId: Long, playlistName: String, shuffle: Boolean) {
        playbackController.playPlaylist(songs, playlistId, playlistName, shuffle)
        songs.firstOrNull()?.let { maybeAutoFetchLyrics(it) }
    }

    fun togglePlayPause() = playbackController.togglePlayPause()
    fun seekTo(ms: Long) = playbackController.seekTo(ms)
    fun skipNext() {
        playbackController.skipNext()
        playbackState.value.currentSong?.let { maybeAutoFetchLyrics(it) }
    }
    fun skipPrevious() = playbackController.skipPrevious()
    fun toggleShuffle() = playbackController.toggleShuffle()
    fun cycleRepeatMode() = playbackController.cycleRepeatMode()
    fun jumpToQueueIndex(idx: Int) = playbackController.jumpToQueueIndex(idx)

    // --- Lyrics ---

    private fun maybeAutoFetchLyrics(song: SongEntity) {
        if (userSettings.value?.autoFetchLyrics == false) return
        val uid = activeUserId.value ?: song.ownerUserId
        viewModelScope.launch {
            lyricsRepo.fetchAndCacheLyricsIfNeeded(
                songId = song.songId,
                userId = uid,
                title = song.displayTitle,
                artist = song.artist,
                durationMs = song.durationMs,
                forceRefresh = false
            )
        }
    }

    fun refreshCurrentLyrics() {
        val song = playbackState.value.currentSong ?: return
        val uid = activeUserId.value ?: song.ownerUserId
        viewModelScope.launch {
            _lyricsLoading.value = true
            lyricsRepo.fetchAndCacheLyricsIfNeeded(
                songId = song.songId,
                userId = uid,
                title = song.displayTitle,
                artist = song.artist,
                durationMs = song.durationMs,
                forceRefresh = true
            )
            _lyricsLoading.value = false
        }
    }

    fun saveManualLyrics(songId: Long, plain: String?, synced: String?) {
        val uid = activeUserId.value ?: return
        viewModelScope.launch {
            lyricsRepo.saveManualLyrics(songId, uid, plain, synced)
            _uiMessages.tryEmit("Lyrics saved offline")
        }
    }

    // --- Search & Analytics & Settings ---

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setAnalyticsRange(range: AnalyticsRange) {
        _analyticsRange.value = range
    }

    fun updateSettings(transform: (UserSettingsEntity) -> UserSettingsEntity) {
        val uid = activeUserId.value ?: return
        viewModelScope.launch {
            val current = settingsDao.getSettingsOnce(uid) ?: UserSettingsEntity(userId = uid)
            settingsDao.upsertSettings(transform(current))
        }
    }
}
