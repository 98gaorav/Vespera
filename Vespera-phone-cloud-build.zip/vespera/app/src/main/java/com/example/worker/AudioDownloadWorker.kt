package com.example.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.example.R
import com.example.VesperaApp
import com.example.data.local.db.DownloadStatus
import com.example.data.local.db.SongEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class AudioDownloadWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val taskId = inputData.getString(KEY_TASK_ID) ?: return@withContext Result.failure()
        val app = applicationContext as VesperaApp
        val container = app.container
        val downloadDao = container.database.downloadTaskDao()
        val songDao = container.database.songDao()
        val storage = container.storageManager
        val extractor = container.youTubeExtractor

        ensureNotificationChannel()

        val initialTask = downloadDao.getTaskById(taskId) ?: return@withContext Result.failure()
        if (initialTask.status == DownloadStatus.CANCELLED || initialTask.status == DownloadStatus.PAUSED) {
            return@withContext Result.success()
        }

        runCatching {
            setForeground(createForegroundInfo(taskId, initialTask.title, initialTask.progressPercent))
        }

        try {
            downloadDao.upsertTask(
                initialTask.copy(
                    status = DownloadStatus.FETCHING_INFO,
                    errorMessage = null
                )
            )

            // Ensure metadata is populated
            val currentTask = downloadDao.getTaskById(taskId) ?: return@withContext Result.failure()
            val resolvedStream = extractor.resolveAudioStream(
                videoId = currentTask.videoId,
                qualityPreference = currentTask.audioQuality
            ).getOrThrow()

            // Download thumbnail locally if not already saved (e.g. user didn't pick custom artwork)
            var localThumbPath = currentTask.localThumbnailPath
            if (localThumbPath.isNullOrBlank() && !currentTask.thumbnailUrl.isNullOrBlank()) {
                localThumbPath = downloadThumbnail(
                    url = currentTask.thumbnailUrl,
                    destFile = File(storage.artworkDir(currentTask.userId), "yt_${taskId.take(8)}.jpg")
                )
            }

            val ext = resolvedStream.formatExtension
            val cleanBase = storage.cleanFileName(currentTask.title)
            val partFile = currentTask.tempAudioPath?.let { File(it) }
                ?: File(storage.audioDir(currentTask.userId), "${cleanBase}_${taskId.take(6)}.$ext.part")

            val existingBytes = if (partFile.exists()) partFile.length() else 0L

            val reqBuilder = Request.Builder()
                .url(resolvedStream.streamUrl)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
            if (existingBytes > 0L) {
                reqBuilder.header("Range", "bytes=$existingBytes-")
            }

            client.newCall(reqBuilder.build()).execute().use { resp ->
                if (!resp.isSuccessful && resp.code != 206) {
                    throw IllegalStateException("Download HTTP ${resp.code}")
                }
                val isPartial = resp.code == 206
                val body = resp.body ?: throw IllegalStateException("Empty audio response")
                val contentLength = body.contentLength()
                val totalBytes = when {
                    isPartial && contentLength > 0 -> existingBytes + contentLength
                    contentLength > 0 -> contentLength
                    resolvedStream.contentLengthBytes > 0 -> resolvedStream.contentLengthBytes
                    else -> 0L
                }

                var downloadedBytes = if (isPartial) existingBytes else 0L
                if (!isPartial && partFile.exists()) {
                    partFile.delete()
                }

                downloadDao.upsertTask(
                    currentTask.copy(
                        status = DownloadStatus.DOWNLOADING,
                        audioFormat = ext.uppercase(),
                        localThumbnailPath = localThumbPath,
                        tempAudioPath = partFile.absolutePath,
                        totalBytes = totalBytes,
                        downloadedBytes = downloadedBytes
                    )
                )

                val buffer = ByteArray(16 * 1024)
                var windowBytes = 0L
                var windowStartNs = System.nanoTime()
                var lastPersistTimeMs = 0L

                body.byteStream().use { input ->
                    FileOutputStream(partFile, isPartial).use { output ->
                        while (true) {
                            if (isStopped) {
                                return@withContext Result.success()
                            }
                            // Check if paused or cancelled in DB
                            val dbCheck = downloadDao.getTaskById(taskId)
                            if (dbCheck == null || dbCheck.status == DownloadStatus.CANCELLED) {
                                partFile.delete()
                                return@withContext Result.success()
                            }
                            if (dbCheck.status == DownloadStatus.PAUSED) {
                                return@withContext Result.success()
                            }

                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            downloadedBytes += read
                            windowBytes += read

                            val nowMs = System.currentTimeMillis()
                            if (nowMs - lastPersistTimeMs >= 300L) {
                                val elapsedSec = ((System.nanoTime() - windowStartNs) / 1_000_000_000.0).coerceAtLeast(0.05)
                                val speedBps = (windowBytes / elapsedSec).toLong().coerceAtLeast(1L)
                                val progress = if (totalBytes > 0L) {
                                    ((downloadedBytes * 100L) / totalBytes).toInt().coerceIn(0, 99)
                                } else 0
                                val etaSec = if (totalBytes > downloadedBytes && speedBps > 0L) {
                                    ((totalBytes - downloadedBytes) / speedBps).coerceAtLeast(0L)
                                } else -1L

                                downloadDao.upsertTask(
                                    dbCheck.copy(
                                        status = DownloadStatus.DOWNLOADING,
                                        progressPercent = progress,
                                        downloadedBytes = downloadedBytes,
                                        totalBytes = totalBytes,
                                        speedBytesPerSec = speedBps,
                                        etaSeconds = etaSec
                                    )
                                )
                                runCatching {
                                    setForeground(createForegroundInfo(taskId, dbCheck.title, progress))
                                }

                                lastPersistTimeMs = nowMs
                                if (elapsedSec >= 2.0) {
                                    windowBytes = 0L
                                    windowStartNs = System.nanoTime()
                                }
                            }
                        }
                    }
                }

                // Finalize & verify saved audio file before inserting into library
                if (!partFile.exists() || partFile.length() == 0L) {
                    throw IllegalStateException("Downloaded audio file verification failed (0 bytes).")
                }

                val finalFile = File(storage.audioDir(currentTask.userId), "${cleanBase}_${taskId.take(6)}.$ext")
                if (finalFile.exists()) finalFile.delete()
                if (!partFile.renameTo(finalFile)) {
                    partFile.copyTo(finalFile, overwrite = true)
                    partFile.delete()
                }
                if (!finalFile.exists() || finalFile.length() == 0L) {
                    throw IllegalStateException("Unable to verify saved offline audio file.")
                }

                val verifiedMeta = storage.extractAudioMetadata(
                    userId = currentTask.userId,
                    audioFile = finalFile,
                    fallbackTitle = currentTask.title,
                    fallbackFormat = ext.uppercase()
                )
                val finalDuration = if (currentTask.durationMs > 0L) currentTask.durationMs else verifiedMeta.durationMs
                val finalArtwork = localThumbPath ?: verifiedMeta.artworkPath

                val song = SongEntity(
                    ownerUserId = currentTask.userId,
                    originalTitle = currentTask.title,
                    customTitle = currentTask.title,
                    artist = currentTask.artist.ifBlank { verifiedMeta.artist },
                    album = "YouTube Audio",
                    durationMs = finalDuration,
                    artworkPath = finalArtwork,
                    audioFilePath = finalFile.absolutePath,
                    fileSizeBytes = finalFile.length(),
                    audioFormat = ext.uppercase(),
                    sourceType = "YOUTUBE",
                    sourceUrl = currentTask.youtubeUrl,
                    isAvailableOffline = true
                )
                songDao.insertSong(song)

                val latestTask = downloadDao.getTaskById(taskId) ?: currentTask
                downloadDao.upsertTask(
                    latestTask.copy(
                        status = DownloadStatus.COMPLETED,
                        progressPercent = 100,
                        downloadedBytes = finalFile.length(),
                        totalBytes = finalFile.length(),
                        speedBytesPerSec = 0L,
                        etaSeconds = 0L,
                        tempAudioPath = null
                    )
                )
                postCompletionNotification(currentTask.title, success = true, message = "Saved to offline library")
                Result.success()
            }
        } catch (e: Exception) {
            val latest = downloadDao.getTaskById(taskId)
            if (latest != null && latest.status != DownloadStatus.PAUSED && latest.status != DownloadStatus.CANCELLED) {
                downloadDao.upsertTask(
                    latest.copy(
                        status = DownloadStatus.FAILED,
                        speedBytesPerSec = 0L,
                        etaSeconds = -1L,
                        errorMessage = e.message ?: "Download failed"
                    )
                )
                postCompletionNotification(latest.title, success = false, message = e.message ?: "Download failed")
            }
            Result.failure()
        }
    }

    private fun downloadThumbnail(url: String, destFile: File): String? {
        return runCatching {
            val req = Request.Builder().url(url).build()
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return null
                val bytes = resp.body?.bytes() ?: return null
                if (bytes.isEmpty()) return null
                destFile.writeBytes(bytes)
                destFile.absolutePath
            }
        }.getOrNull()
    }

    private fun ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                applicationContext.getString(R.string.download_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            manager.createNotificationChannel(channel)
        }
    }

    private fun createForegroundInfo(taskId: String, title: String, progress: Int): ForegroundInfo {
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("Downloading Audio")
            .setContentText(title)
            .setProgress(100, progress.coerceIn(0, 100), progress <= 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(
                taskId.hashCode(),
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            ForegroundInfo(taskId.hashCode(), notification)
        }
    }

    private fun postCompletionNotification(title: String, success: Boolean, message: String) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle(if (success) "Download Complete" else "Download Failed")
            .setContentText("$title — $message")
            .setAutoCancel(true)
            .build()
        manager.notify(("done_$title").hashCode(), notification)
    }

    companion object {
        const val KEY_TASK_ID = "task_id"
        private const val CHANNEL_ID = "vespera_downloads"
    }
}
