package com.example.player

import android.content.ComponentName
import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.data.local.db.*
import com.example.domain.shuffle.ShuffleCycleState
import com.example.domain.shuffle.ShuffleEngine
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File

enum class RepeatModeState(val code: Int) {
    OFF(0),
    ONE(1),
    PLAYLIST(2);

    fun next(): RepeatModeState = when (this) {
        OFF -> PLAYLIST
        PLAYLIST -> ONE
        ONE -> OFF
    }

    companion object {
        fun fromCode(code: Int): RepeatModeState = entries.firstOrNull { it.code == code } ?: OFF
    }
}

data class PlaybackUiState(
    val currentSong: SongEntity? = null,
    val queue: List<SongEntity> = emptyList(),
    val currentQueueIndex: Int = -1,
    val sourcePlaylistId: Long? = null,
    val sourceLabel: String = "Offline Library",
    val isPlaying: Boolean = false,
    val positionMs: Long = 0L,
    val durationMs: Long = 0L,
    val shuffleEnabled: Boolean = false,
    val repeatMode: RepeatModeState = RepeatModeState.OFF,
    val outputDeviceName: String = "Phone Speaker"
)

class PlaybackController(
    private val context: Context,
    private val songDao: SongDao,
    private val playlistDao: PlaylistDao,
    private val historyDao: PlaybackHistoryDao,
    private val settingsDao: UserSettingsDao,
    private val shuffleCycleDao: ShuffleCycleDao,
    private val shuffleEngine: ShuffleEngine = ShuffleEngine()
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _uiState = MutableStateFlow(PlaybackUiState())
    val uiState: StateFlow<PlaybackUiState> = _uiState.asStateFlow()

    private var controller: MediaController? = null
    private var activeUserId: Long? = null
    private var rawCollectionSongs: List<SongEntity> = emptyList()
    private var activeShuffleCycle: ShuffleCycleState? = null
    private var currentHistoryRowId: Long? = null
    private var listeningAccumulatorMs: Long = 0L
    private var lastTickRealtimeMs: Long = 0L
    private var positionTickerJob: Job? = null
    private var songObserverJob: Job? = null

    init {
        connectController()
    }

    private fun connectController() {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener(
            {
                runCatching {
                    val mc = future.get()
                    controller = mc
                    mc.addListener(playerListener)
                    syncFromController(mc)
                }
            },
            ContextCompat.getMainExecutor(context)
        )
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _uiState.update { it.copy(isPlaying = isPlaying) }
            if (isPlaying) {
                lastTickRealtimeMs = System.currentTimeMillis()
                startPositionTicker()
            } else {
                flushListeningTime(completed = false)
                stopPositionTicker()
            }
            refreshOutputDevice()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            val mc = controller ?: return
            val dur = mc.duration.takeIf { it > 0 } ?: _uiState.value.currentSong?.durationMs ?: 0L
            _uiState.update { it.copy(durationMs = dur) }
            if (playbackState == Player.STATE_ENDED) {
                scope.launch { handleTrackEnded() }
            }
        }
    }

    fun onUserChanged(userId: Long?) {
        if (activeUserId == userId) return
        flushListeningTime(completed = false)
        activeUserId = userId
        activeShuffleCycle = null
        rawCollectionSongs = emptyList()
        currentHistoryRowId = null
        controller?.stop()
        controller?.clearMediaItems()
        _uiState.value = PlaybackUiState(outputDeviceName = detectOutputDevice())

        if (userId != null) {
            scope.launch {
                val settings = settingsDao.getSettingsOnce(userId)
                if (settings != null) {
                    _uiState.update {
                        it.copy(
                            shuffleEnabled = settings.shuffleEnabled,
                            repeatMode = RepeatModeState.fromCode(settings.repeatMode)
                        )
                    }
                }
            }
        }
    }

    fun playSongFromCollection(
        song: SongEntity,
        collection: List<SongEntity>,
        playlistId: Long? = null,
        sourceLabel: String = "Offline Library",
        forceRepeatOne: Boolean = false
    ) {
        scope.launch {
            val uid = activeUserId ?: song.ownerUserId
            activeUserId = uid
            rawCollectionSongs = collection.ifEmpty { listOf(song) }

            val currentRepeat = if (forceRepeatOne) RepeatModeState.ONE else _uiState.value.repeatMode
            val shuffleOn = _uiState.value.shuffleEnabled

            val orderedQueue = if (shuffleOn) {
                val cycle = shuffleEngine.createNewCycle(
                    songIds = rawCollectionSongs.map { it.songId },
                    preserveCurrentSongId = song.songId,
                    previousCycleLastSongId = activeShuffleCycle?.lastCycleTailId
                )
                activeShuffleCycle = cycle
                persistCycle(uid, playlistId, cycle)
                val map = rawCollectionSongs.associateBy { it.songId }
                cycle.orderedIds.mapNotNull { map[it] }
            } else {
                rawCollectionSongs
            }

            if (playlistId != null) {
                playlistDao.updateLastPlayed(playlistId, System.currentTimeMillis())
            }
            if (forceRepeatOne) {
                saveSettingsRepeat(uid, RepeatModeState.ONE)
            }

            val startIndex = orderedQueue.indexOfFirst { it.songId == song.songId }.coerceAtLeast(0)
            _uiState.update {
                it.copy(
                    queue = orderedQueue,
                    currentQueueIndex = startIndex,
                    sourcePlaylistId = playlistId,
                    sourceLabel = sourceLabel,
                    repeatMode = currentRepeat
                )
            }

            startPlayingSong(song, playlistId, recordPlayCount = true)
        }
    }

    fun playPlaylist(
        songs: List<SongEntity>,
        playlistId: Long,
        playlistName: String,
        shuffle: Boolean
    ) {
        if (songs.isEmpty()) return
        scope.launch {
            val uid = activeUserId ?: songs.first().ownerUserId
            activeUserId = uid
            rawCollectionSongs = songs
            saveSettingsShuffle(uid, shuffle)

            val ordered = if (shuffle) {
                val cycle = shuffleEngine.createNewCycle(
                    songIds = songs.map { it.songId },
                    preserveCurrentSongId = null,
                    previousCycleLastSongId = null
                )
                activeShuffleCycle = cycle
                persistCycle(uid, playlistId, cycle)
                val map = songs.associateBy { it.songId }
                cycle.orderedIds.mapNotNull { map[it] }
            } else {
                songs
            }

            val firstSong = ordered.first()
            playlistDao.updateLastPlayed(playlistId, System.currentTimeMillis())
            _uiState.update {
                it.copy(
                    queue = ordered,
                    currentQueueIndex = 0,
                    sourcePlaylistId = playlistId,
                    sourceLabel = playlistName,
                    shuffleEnabled = shuffle
                )
            }
            startPlayingSong(firstSong, playlistId, recordPlayCount = true)
        }
    }

    fun togglePlayPause() {
        val mc = controller ?: return
        if (mc.isPlaying) {
            mc.pause()
        } else {
            if (mc.playbackState == Player.STATE_ENDED) {
                mc.seekTo(0L)
            }
            if (mc.mediaItemCount == 0 && _uiState.value.currentSong != null) {
                val s = _uiState.value.currentSong!!
                scope.launch { startPlayingSong(s, _uiState.value.sourcePlaylistId, recordPlayCount = true) }
            } else {
                mc.play()
            }
        }
    }

    fun seekTo(positionMs: Long) {
        val mc = controller ?: return
        val clamped = positionMs.coerceIn(0L, _uiState.value.durationMs.coerceAtLeast(1L))
        mc.seekTo(clamped)
        _uiState.update { it.copy(positionMs = clamped) }
    }

    fun skipNext() {
        scope.launch {
            val state = _uiState.value
            val uid = activeUserId ?: state.currentSong?.ownerUserId ?: return@launch
            if (state.queue.isEmpty()) return@launch

            if (state.shuffleEnabled) {
                val allIds = rawCollectionSongs.map { it.songId }.ifEmpty { state.queue.map { it.songId } }
                val cycle = activeShuffleCycle ?: ShuffleCycleState(
                    orderedIds = state.queue.map { it.songId },
                    currentIndex = state.currentQueueIndex.coerceAtLeast(0)
                )
                val (nextCycle, nextId) = shuffleEngine.moveNext(
                    state = cycle,
                    allSongIds = allIds,
                    repeatPlaylist = true // Manual Next wraps to a fresh cycle
                )
                activeShuffleCycle = nextCycle
                persistCycle(uid, state.sourcePlaylistId, nextCycle)

                val map = (rawCollectionSongs + state.queue).associateBy { it.songId }
                val newQueue = nextCycle.orderedIds.mapNotNull { map[it] }
                val nextSong = nextId?.let { map[it] } ?: return@launch
                _uiState.update {
                    it.copy(queue = newQueue, currentQueueIndex = nextCycle.currentIndex)
                }
                startPlayingSong(nextSong, state.sourcePlaylistId, recordPlayCount = true)
            } else {
                val nextIdx = if (state.currentQueueIndex + 1 < state.queue.size) {
                    state.currentQueueIndex + 1
                } else 0
                val nextSong = state.queue[nextIdx]
                _uiState.update { it.copy(currentQueueIndex = nextIdx) }
                startPlayingSong(nextSong, state.sourcePlaylistId, recordPlayCount = true)
            }
        }
    }

    fun skipPrevious() {
        scope.launch {
            val mc = controller
            if (mc != null && mc.currentPosition > 3500L) {
                mc.seekTo(0L)
                _uiState.update { it.copy(positionMs = 0L) }
                return@launch
            }
            val state = _uiState.value
            val uid = activeUserId ?: state.currentSong?.ownerUserId ?: return@launch
            if (state.queue.isEmpty()) return@launch

            if (state.shuffleEnabled && activeShuffleCycle != null) {
                val (prevCycle, prevId) = shuffleEngine.movePrevious(activeShuffleCycle!!)
                activeShuffleCycle = prevCycle
                persistCycle(uid, state.sourcePlaylistId, prevCycle)
                val prevSong = prevId?.let { id -> state.queue.firstOrNull { it.songId == id } } ?: state.queue.first()
                _uiState.update { it.copy(currentQueueIndex = prevCycle.currentIndex) }
                startPlayingSong(prevSong, state.sourcePlaylistId, recordPlayCount = true)
            } else {
                val prevIdx = if (state.currentQueueIndex > 0) state.currentQueueIndex - 1 else state.queue.lastIndex
                val prevSong = state.queue[prevIdx]
                _uiState.update { it.copy(currentQueueIndex = prevIdx) }
                startPlayingSong(prevSong, state.sourcePlaylistId, recordPlayCount = true)
            }
        }
    }

    fun toggleShuffle() {
        scope.launch {
            val state = _uiState.value
            val newShuffle = !state.shuffleEnabled
            val uid = activeUserId ?: state.currentSong?.ownerUserId
            if (uid != null) saveSettingsShuffle(uid, newShuffle)

            val currentSong = state.currentSong
            val sourceSongs = rawCollectionSongs.ifEmpty { state.queue }

            if (newShuffle && sourceSongs.isNotEmpty()) {
                val cycle = shuffleEngine.createNewCycle(
                    songIds = sourceSongs.map { it.songId },
                    preserveCurrentSongId = currentSong?.songId,
                    previousCycleLastSongId = activeShuffleCycle?.lastCycleTailId
                )
                activeShuffleCycle = cycle
                if (uid != null) persistCycle(uid, state.sourcePlaylistId, cycle)
                val map = sourceSongs.associateBy { it.songId }
                val shuffledQueue = cycle.orderedIds.mapNotNull { map[it] }
                _uiState.update {
                    it.copy(
                        shuffleEnabled = true,
                        queue = shuffledQueue,
                        currentQueueIndex = cycle.currentIndex
                    )
                }
            } else {
                val restoredIdx = currentSong?.let { s ->
                    sourceSongs.indexOfFirst { it.songId == s.songId }
                }?.coerceAtLeast(0) ?: 0
                _uiState.update {
                    it.copy(
                        shuffleEnabled = false,
                        queue = sourceSongs,
                        currentQueueIndex = restoredIdx
                    )
                }
            }
        }
    }

    fun cycleRepeatMode() {
        scope.launch {
            val nextMode = _uiState.value.repeatMode.next()
            _uiState.update { it.copy(repeatMode = nextMode) }
            activeUserId?.let { saveSettingsRepeat(it, nextMode) }
        }
    }

    fun setRepeatOne(song: SongEntity, collection: List<SongEntity>, playlistId: Long? = null, sourceLabel: String = "Offline Library") {
        playSongFromCollection(
            song = song,
            collection = collection,
            playlistId = playlistId,
            sourceLabel = sourceLabel,
            forceRepeatOne = true
        )
    }

    fun jumpToQueueIndex(index: Int) {
        val state = _uiState.value
        val song = state.queue.getOrNull(index) ?: return
        scope.launch {
            if (state.shuffleEnabled && activeShuffleCycle != null) {
                activeShuffleCycle = activeShuffleCycle!!.copy(currentIndex = index)
                activeUserId?.let { persistCycle(it, state.sourcePlaylistId, activeShuffleCycle!!) }
            }
            _uiState.update { it.copy(currentQueueIndex = index) }
            startPlayingSong(song, state.sourcePlaylistId, recordPlayCount = true)
        }
    }

    fun syncCollectionSongs(updatedSongs: List<SongEntity>) {
        if (updatedSongs.isEmpty()) return
        rawCollectionSongs = updatedSongs
        val state = _uiState.value
        val byId = updatedSongs.associateBy { it.songId }

        // Keep currentSong and queue titles/artwork fresh if renamed or artwork updated
        val refreshedCurrent = state.currentSong?.let { byId[it.songId] }
        if (state.shuffleEnabled && activeShuffleCycle != null) {
            val synced = shuffleEngine.syncWithLibrary(activeShuffleCycle!!, updatedSongs.map { it.songId })
            activeShuffleCycle = synced
            val syncedQueue = synced.orderedIds.mapNotNull { byId[it] }
            _uiState.update {
                it.copy(
                    currentSong = refreshedCurrent ?: it.currentSong,
                    queue = syncedQueue.ifEmpty { it.queue },
                    currentQueueIndex = synced.currentIndex
                )
            }
        } else {
            val refreshedQueue = state.queue.mapNotNull { byId[it.songId] }
            _uiState.update {
                it.copy(
                    currentSong = refreshedCurrent ?: it.currentSong,
                    queue = refreshedQueue.ifEmpty { it.queue }
                )
            }
        }
    }

    private suspend fun handleTrackEnded() {
        val state = _uiState.value
        val currentSong = state.currentSong ?: return
        val uid = activeUserId ?: currentSong.ownerUserId
        flushListeningTime(completed = true)

        when (state.repeatMode) {
            RepeatModeState.ONE -> {
                // Repeat ONE: restart current song AND count completed repeat as a new play!
                startPlayingSong(currentSong, state.sourcePlaylistId, recordPlayCount = true)
            }
            RepeatModeState.PLAYLIST -> {
                if (state.shuffleEnabled) {
                    val allIds = rawCollectionSongs.map { it.songId }.ifEmpty { state.queue.map { it.songId } }
                    val cycle = activeShuffleCycle ?: ShuffleCycleState(
                        orderedIds = state.queue.map { it.songId },
                        currentIndex = state.currentQueueIndex.coerceAtLeast(0)
                    )
                    val (nextCycle, nextId) = shuffleEngine.moveNext(
                        state = cycle,
                        allSongIds = allIds,
                        repeatPlaylist = true
                    )
                    activeShuffleCycle = nextCycle
                    persistCycle(uid, state.sourcePlaylistId, nextCycle)
                    val map = (rawCollectionSongs + state.queue).associateBy { it.songId }
                    val newQueue = nextCycle.orderedIds.mapNotNull { map[it] }
                    val nextSong = nextId?.let { map[it] } ?: return
                    _uiState.update {
                        it.copy(queue = newQueue, currentQueueIndex = nextCycle.currentIndex)
                    }
                    startPlayingSong(nextSong, state.sourcePlaylistId, recordPlayCount = true)
                } else {
                    val nextIdx = if (state.currentQueueIndex + 1 < state.queue.size) {
                        state.currentQueueIndex + 1
                    } else 0
                    val nextSong = state.queue.getOrNull(nextIdx) ?: return
                    _uiState.update { it.copy(currentQueueIndex = nextIdx) }
                    startPlayingSong(nextSong, state.sourcePlaylistId, recordPlayCount = true)
                }
            }
            RepeatModeState.OFF -> {
                if (state.shuffleEnabled) {
                    val allIds = rawCollectionSongs.map { it.songId }.ifEmpty { state.queue.map { it.songId } }
                    val cycle = activeShuffleCycle ?: ShuffleCycleState(
                        orderedIds = state.queue.map { it.songId },
                        currentIndex = state.currentQueueIndex.coerceAtLeast(0)
                    )
                    val (nextCycle, nextId) = shuffleEngine.moveNext(
                        state = cycle,
                        allSongIds = allIds,
                        repeatPlaylist = false
                    )
                    if (nextId != null) {
                        activeShuffleCycle = nextCycle
                        persistCycle(uid, state.sourcePlaylistId, nextCycle)
                        val nextSong = (rawCollectionSongs + state.queue).firstOrNull { it.songId == nextId } ?: return
                        _uiState.update { it.copy(currentQueueIndex = nextCycle.currentIndex) }
                        startPlayingSong(nextSong, state.sourcePlaylistId, recordPlayCount = true)
                    } else {
                        _uiState.update { it.copy(isPlaying = false, positionMs = 0L) }
                    }
                } else {
                    if (state.currentQueueIndex + 1 < state.queue.size) {
                        val nextIdx = state.currentQueueIndex + 1
                        val nextSong = state.queue[nextIdx]
                        _uiState.update { it.copy(currentQueueIndex = nextIdx) }
                        startPlayingSong(nextSong, state.sourcePlaylistId, recordPlayCount = true)
                    } else {
                        _uiState.update { it.copy(isPlaying = false, positionMs = 0L) }
                    }
                }
            }
        }
    }

    private suspend fun startPlayingSong(
        song: SongEntity,
        playlistId: Long?,
        recordPlayCount: Boolean
    ) {
        flushListeningTime(completed = false)
        val file = File(song.audioFilePath)
        if (!file.exists()) return

        observeCurrentSongUpdates(song.songId)

        if (recordPlayCount) {
            val now = System.currentTimeMillis()
            songDao.incrementPlayCount(song.songId, now)
            currentHistoryRowId = historyDao.insertHistory(
                PlaybackHistoryEntity(
                    userId = song.ownerUserId,
                    songId = song.songId,
                    playlistId = playlistId,
                    playedAt = now,
                    durationListenedMs = 0L,
                    completed = false
                )
            )
            listeningAccumulatorMs = 0L
            lastTickRealtimeMs = now
        }

        val freshSong = songDao.getSongById(song.songId) ?: song
        _uiState.update {
            it.copy(
                currentSong = freshSong,
                durationMs = freshSong.durationMs,
                positionMs = 0L,
                outputDeviceName = detectOutputDevice()
            )
        }

        val metadataBuilder = MediaMetadata.Builder()
            .setTitle(freshSong.displayTitle)
            .setArtist(freshSong.artist)
            .setAlbumTitle(freshSong.album)
        freshSong.artworkPath?.let { artPath ->
            val artFile = File(artPath)
            if (artFile.exists()) {
                metadataBuilder.setArtworkUri(Uri.fromFile(artFile))
            }
        }

        val mediaItem = MediaItem.Builder()
            .setMediaId(freshSong.songId.toString())
            .setUri(Uri.fromFile(file))
            .setMediaMetadata(metadataBuilder.build())
            .build()

        val mc = controller
        if (mc != null) {
            mc.setMediaItem(mediaItem)
            mc.prepare()
            mc.play()
        }
    }

    private fun observeCurrentSongUpdates(songId: Long) {
        songObserverJob?.cancel()
        songObserverJob = scope.launch {
            songDao.observeSongById(songId).collectLatest { updated ->
                if (updated != null) {
                    _uiState.update { it.copy(currentSong = updated) }
                }
            }
        }
    }

    private fun startPositionTicker() {
        positionTickerJob?.cancel()
        positionTickerJob = scope.launch {
            while (isActive) {
                val mc = controller
                if (mc != null && mc.isPlaying) {
                    val now = System.currentTimeMillis()
                    if (lastTickRealtimeMs > 0L) {
                        listeningAccumulatorMs += (now - lastTickRealtimeMs).coerceIn(0L, 2000L)
                    }
                    lastTickRealtimeMs = now
                    val pos = mc.currentPosition.coerceAtLeast(0L)
                    val dur = mc.duration.takeIf { it > 0L } ?: _uiState.value.durationMs
                    _uiState.update { it.copy(positionMs = pos, durationMs = dur) }
                    if (listeningAccumulatorMs >= 3000L && currentHistoryRowId != null) {
                        val rowId = currentHistoryRowId!!
                        val total = listeningAccumulatorMs
                        launch(Dispatchers.IO) {
                            historyDao.updateHistoryDuration(rowId, total, false)
                        }
                    }
                }
                delay(400L)
            }
        }
    }

    private fun stopPositionTicker() {
        positionTickerJob?.cancel()
        positionTickerJob = null
    }

    private fun flushListeningTime(completed: Boolean) {
        val rowId = currentHistoryRowId ?: return
        val now = System.currentTimeMillis()
        if (lastTickRealtimeMs > 0L && _uiState.value.isPlaying) {
            listeningAccumulatorMs += (now - lastTickRealtimeMs).coerceIn(0L, 2000L)
        }
        lastTickRealtimeMs = now
        val total = listeningAccumulatorMs
        scope.launch(Dispatchers.IO) {
            historyDao.updateHistoryDuration(rowId, total, completed)
        }
    }

    private suspend fun persistCycle(userId: Long, playlistId: Long?, cycle: ShuffleCycleState) {
        val key = "$userId:${playlistId ?: "library"}"
        shuffleCycleDao.upsertCycle(
            ShuffleCycleEntity(
                cycleKey = key,
                orderedSongIdsCsv = cycle.orderedIds.joinToString(","),
                currentIndex = cycle.currentIndex,
                lastCycleTailSongId = cycle.lastCycleTailId
            )
        )
    }

    private suspend fun saveSettingsShuffle(userId: Long, enabled: Boolean) {
        val current = settingsDao.getSettingsOnce(userId) ?: UserSettingsEntity(userId = userId)
        settingsDao.upsertSettings(current.copy(shuffleEnabled = enabled))
    }

    private suspend fun saveSettingsRepeat(userId: Long, mode: RepeatModeState) {
        val current = settingsDao.getSettingsOnce(userId) ?: UserSettingsEntity(userId = userId)
        settingsDao.upsertSettings(current.copy(repeatMode = mode.code))
    }

    private fun syncFromController(mc: MediaController) {
        _uiState.update {
            it.copy(
                isPlaying = mc.isPlaying,
                positionMs = mc.currentPosition.coerceAtLeast(0L),
                durationMs = mc.duration.takeIf { d -> d > 0L } ?: it.durationMs,
                outputDeviceName = detectOutputDevice()
            )
        }
        if (mc.isPlaying) startPositionTicker()
    }

    fun refreshOutputDevice() {
        _uiState.update { it.copy(outputDeviceName = detectOutputDevice()) }
    }

    private fun detectOutputDevice(): String {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return "Phone Speaker"
        val devices = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        for (dev in devices) {
            when (dev.type) {
                AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                AudioDeviceInfo.TYPE_BLUETOOTH_SCO,
                AudioDeviceInfo.TYPE_BLE_HEADSET,
                AudioDeviceInfo.TYPE_BLE_SPEAKER -> {
                    val name = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) dev.productName?.toString() else null
                    return name?.takeIf { it.isNotBlank() } ?: "Bluetooth Audio"
                }
                AudioDeviceInfo.TYPE_WIRED_HEADSET,
                AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                AudioDeviceInfo.TYPE_USB_HEADSET -> return "Wired Headphones"
            }
        }
        return "Phone Speaker"
    }
}
