package com.example.domain.shuffle

import kotlin.random.Random

/**
 * Pure Fisher-Yates shuffle cycle engine.
 * Guarantees every song plays exactly once per cycle, preserves the active song,
 * prevents repeating the previous cycle's last song as the next cycle's first song
 * when > 1 song exists, and reconciles dynamic additions/removals cleanly.
 */
data class ShuffleCycleState(
    val orderedIds: List<Long>,
    val currentIndex: Int,
    val lastCycleTailId: Long? = null
) {
    val currentSongId: Long?
        get() = orderedIds.getOrNull(currentIndex)

    val hasNextInCycle: Boolean
        get() = currentIndex + 1 < orderedIds.size

    val hasPreviousInCycle: Boolean
        get() = currentIndex > 0
}

class ShuffleEngine(private val random: Random = Random.Default) {

    fun createNewCycle(
        songIds: List<Long>,
        preserveCurrentSongId: Long? = null,
        previousCycleLastSongId: Long? = null
    ): ShuffleCycleState {
        val uniqueIds = songIds.distinct()
        if (uniqueIds.isEmpty()) {
            return ShuffleCycleState(emptyList(), -1, previousCycleLastSongId)
        }
        if (uniqueIds.size == 1) {
            return ShuffleCycleState(uniqueIds, 0, uniqueIds.first())
        }

        val mutable = uniqueIds.toMutableList()
        if (preserveCurrentSongId != null && mutable.contains(preserveCurrentSongId)) {
            mutable.remove(preserveCurrentSongId)
            fisherYates(mutable)
            val result = listOf(preserveCurrentSongId) + mutable
            return ShuffleCycleState(
                orderedIds = result,
                currentIndex = 0,
                lastCycleTailId = previousCycleLastSongId
            )
        } else {
            fisherYates(mutable)
            // Avoid repeating the previous cycle's last song as the first song of the new cycle
            if (previousCycleLastSongId != null && mutable.first() == previousCycleLastSongId) {
                val swapIdx = if (mutable.size > 1) random.nextInt(1, mutable.size) else 0
                val tmp = mutable[0]
                mutable[0] = mutable[swapIdx]
                mutable[swapIdx] = tmp
            }
            return ShuffleCycleState(
                orderedIds = mutable,
                currentIndex = 0,
                lastCycleTailId = previousCycleLastSongId
            )
        }
    }

    fun moveNext(
        state: ShuffleCycleState,
        allSongIds: List<Long>,
        repeatPlaylist: Boolean
    ): Pair<ShuffleCycleState, Long?> {
        val synced = syncWithLibrary(state, allSongIds)
        if (synced.orderedIds.isEmpty()) return synced to null

        if (synced.currentIndex + 1 < synced.orderedIds.size) {
            val nextIndex = synced.currentIndex + 1
            val nextState = synced.copy(currentIndex = nextIndex)
            return nextState to nextState.currentSongId
        }

        // End of cycle reached
        if (!repeatPlaylist) {
            return synced to null
        }

        val tailId = synced.orderedIds.lastOrNull()
        val freshCycle = createNewCycle(
            songIds = allSongIds,
            preserveCurrentSongId = null,
            previousCycleLastSongId = tailId
        )
        return freshCycle to freshCycle.currentSongId
    }

    fun movePrevious(state: ShuffleCycleState): Pair<ShuffleCycleState, Long?> {
        if (state.orderedIds.isEmpty()) return state to null
        if (state.currentIndex > 0) {
            val prevState = state.copy(currentIndex = state.currentIndex - 1)
            return prevState to prevState.currentSongId
        }
        return state to state.currentSongId
    }

    fun syncWithLibrary(
        state: ShuffleCycleState,
        allSongIds: List<Long>
    ): ShuffleCycleState {
        val validSet = allSongIds.toSet()
        if (validSet.isEmpty()) {
            return ShuffleCycleState(emptyList(), -1, state.lastCycleTailId)
        }
        if (state.orderedIds.isEmpty()) {
            return createNewCycle(allSongIds, null, state.lastCycleTailId)
        }

        val currentSongId = state.currentSongId
        val filtered = state.orderedIds.filter { it in validSet }
        val existingSet = filtered.toSet()
        val newlyAdded = allSongIds.filter { it !in existingSet }.toMutableList()
        fisherYates(newlyAdded)

        val currentIdxInFiltered = if (currentSongId != null) {
            filtered.indexOf(currentSongId).coerceAtLeast(0)
        } else {
            0
        }

        // Keep played portion intact, mix new songs into upcoming portion
        val playedAndCurrent = if (filtered.isNotEmpty()) {
            filtered.subList(0, (currentIdxInFiltered + 1).coerceAtMost(filtered.size))
        } else {
            emptyList()
        }
        val upcoming = if (currentIdxInFiltered + 1 < filtered.size) {
            (filtered.subList(currentIdxInFiltered + 1, filtered.size) + newlyAdded).toMutableList()
        } else {
            newlyAdded
        }
        fisherYates(upcoming)

        val combined = playedAndCurrent + upcoming
        val finalIndex = if (currentSongId != null) {
            combined.indexOf(currentSongId).coerceAtLeast(0)
        } else {
            0
        }
        return state.copy(orderedIds = combined, currentIndex = finalIndex)
    }

    private fun <T> fisherYates(list: MutableList<T>) {
        for (i in list.size - 1 downTo 1) {
            val j = random.nextInt(i + 1)
            val tmp = list[i]
            list[i] = list[j]
            list[j] = tmp
        }
    }
}
