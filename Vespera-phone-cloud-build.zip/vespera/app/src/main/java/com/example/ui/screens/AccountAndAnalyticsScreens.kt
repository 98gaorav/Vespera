package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.db.SongEntity
import com.example.data.local.db.UserEntity
import com.example.data.local.db.UserSettingsEntity
import com.example.data.repository.ActivityPoint
import com.example.data.repository.AnalyticsRange
import com.example.data.repository.AnalyticsSnapshot
import com.example.ui.components.SongArtwork
import com.example.ui.components.UserAvatar
import com.example.ui.theme.*
import com.example.ui.util.formatBytes
import com.example.ui.util.formatDate
import com.example.ui.util.formatDurationMs
import com.example.ui.util.formatListeningDuration

@Composable
fun AccountScreen(
    user: UserEntity?,
    analytics: AnalyticsSnapshot,
    onUpdateAvatar: (Uri) -> Unit,
    onOpenAnalytics: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenChangePassword: () -> Unit,
    onOpenAccountSwitcher: () -> Unit,
    onSignOut: () -> Unit
) {
    val avatarPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> if (uri != null) onUpdateAvatar(uri) }
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(PaletteDeepNavy.copy(alpha = 0.65f), NavyAbyss, NavyAbyss)
                )
            ),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 160.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column(
                modifier = Modifier.fillMaxWidth().statusBarsPadding(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier.clickable {
                        avatarPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                ) {
                    if (user != null) {
                        UserAvatar(
                            username = user.username,
                            avatarPath = user.avatarPath,
                            avatarColorHex = user.avatarColorHex,
                            size = 92.dp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(PaletteWarmOrange),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.CameraAlt, contentDescription = "Change avatar", tint = NavyAbyss, modifier = Modifier.size(16.dp))
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = user?.username ?: "Listener",
                    style = MaterialTheme.typography.headlineMedium,
                    color = PaletteCream
                )
                Text(
                    text = "Long-press Account tab anytime to switch profiles",
                    style = MaterialTheme.typography.bodySmall,
                    color = CreamSoft
                )
            }
        }

        // Quick Analytics Summary Card
        item {
            Surface(
                color = PaletteDeepNavy,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpenAnalytics)
                    .testTag("open_analytics_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Rounded.BarChart, contentDescription = null, tint = PaletteWarmOrange)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Music Analytics Dashboard", style = MaterialTheme.typography.titleMedium, color = PaletteCream)
                        }
                        Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = PaletteWarmOrange)
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        MiniMetric("Downloaded", "${analytics.totalSongsDownloaded}")
                        MiniMetric("Plays", "${analytics.totalPlays}")
                        MiniMetric("Listened", formatListeningDuration(analytics.totalListeningMs))
                    }
                }
            }
        }

        item {
            AccountMenuRow(Icons.Rounded.People, "Switch / Manage Accounts", "account_switcher_row", onOpenAccountSwitcher)
        }
        item {
            AccountMenuRow(Icons.Rounded.Settings, "App Settings", "account_settings_row", onOpenSettings)
        }
        item {
            AccountMenuRow(Icons.Rounded.LockReset, "Change Password", "account_change_pw_row", onOpenChangePassword)
        }
        item {
            AccountMenuRow(
                icon = Icons.AutoMirrored.Rounded.Logout,
                title = "Sign Out",
                testTag = "account_signout_row",
                onClick = onSignOut,
                tint = PaletteTerracotta
            )
        }
    }
}

@Composable
private fun MiniMetric(label: String, value: String) {
    Column {
        Text(value, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = PaletteWarmOrange)
        Text(label, style = MaterialTheme.typography.bodySmall, color = CreamSoft)
    }
}

@Composable
private fun AccountMenuRow(
    icon: ImageVector,
    title: String,
    testTag: String,
    onClick: () -> Unit,
    tint: androidx.compose.ui.graphics.Color = PaletteCream
) {
    Surface(
        color = NavySurface,
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clickable(onClick = onClick)
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = if (tint == PaletteCream) PaletteWarmOrange else tint)
            Spacer(modifier = Modifier.width(14.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, color = tint, modifier = Modifier.weight(1f))
            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = CreamSoft)
        }
    }
}

@Composable
fun AnalyticsDashboardScreen(
    snapshot: AnalyticsSnapshot,
    selectedRange: AnalyticsRange,
    onSelectRange: (AnalyticsRange) -> Unit,
    onBack: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyAbyss)
            .safeDrawingPadding(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Icon(Icons.Rounded.ArrowBackIosNew, contentDescription = "Back", tint = PaletteCream)
                }
                Text("Music Analytics", style = MaterialTheme.typography.headlineMedium, color = PaletteCream)
            }
        }

        // Range filter chips: Day, Week, Month, All Time
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AnalyticsRange.entries.forEach { range ->
                    val selected = range == selectedRange
                    FilterChip(
                        selected = selected,
                        onClick = { onSelectRange(range) },
                        label = { Text(range.label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PaletteWarmOrange,
                            selectedLabelColor = NavyAbyss,
                            containerColor = NavySurface,
                            labelColor = PaletteCream
                        ),
                        modifier = Modifier.weight(1f).testTag("analytics_filter_${range.name}")
                    )
                }
            }
        }

        // KPI grid
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                KpiCard("Downloaded", "${snapshot.totalSongsDownloaded}", PaletteDeepTeal, Modifier.weight(1f))
                KpiCard("Total Plays", "${snapshot.totalPlays}", PaletteWarmOrange, Modifier.weight(1f))
                KpiCard("Listening Time", formatListeningDuration(snapshot.totalListeningMs), PaletteTerracotta, Modifier.weight(1f))
            }
        }

        // Real Listening Activity Graph
        item {
            Surface(
                color = NavySurface,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Listening Activity (${selectedRange.label})", style = MaterialTheme.typography.titleMedium, color = PaletteCream)
                    Text("Real locally recorded playbacks", style = MaterialTheme.typography.bodySmall, color = CreamSoft)
                    Spacer(modifier = Modifier.height(16.dp))
                    ListeningActivityChart(points = snapshot.activityPoints)
                }
            }
        }

        // Top Highlights
        item {
            Surface(
                color = PaletteDeepNavy,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Top Highlights", style = MaterialTheme.typography.titleMedium, color = PaletteWarmOrange)
                    HighlightRow("Most Played Song", snapshot.mostPlayedSong?.displayTitle ?: "No plays yet")
                    HighlightRow("Most Played Artist", snapshot.mostPlayedArtist ?: "No plays yet")
                    HighlightRow("Most Played Playlist", snapshot.mostPlayedPlaylist?.name ?: "No playlist plays yet")
                }
            }
        }

        // Ranking list 1, 2, 3...
        item {
            Text("Most Played Ranking", style = MaterialTheme.typography.titleLarge, color = PaletteCream)
        }
        if (snapshot.rankedSongs.isEmpty()) {
            item {
                Surface(color = NavySurface, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Play songs in your offline library to build your real listening ranking.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CreamSoft,
                        modifier = Modifier.padding(18.dp)
                    )
                }
            }
        } else {
            items(snapshot.rankedSongs, key = { it.song.songId }) { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(NavySurface)
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${item.rank}.",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = if (item.rank == 1) PaletteWarmOrange else if (item.rank == 2) PaletteTerracotta else PaletteDeepTeal,
                        modifier = Modifier.width(34.dp)
                    )
                    SongArtwork(item.song.artworkPath, item.song.displayTitle, Modifier.size(46.dp), 10.dp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(item.song.displayTitle, style = MaterialTheme.typography.titleSmall, color = PaletteCream, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(item.song.artist, style = MaterialTheme.typography.bodySmall, color = CreamSoft, maxLines = 1)
                    }
                    Surface(color = PaletteDeepNavy, shape = RoundedCornerShape(8.dp)) {
                        Text(
                            text = "${item.playsInRange} plays",
                            style = MaterialTheme.typography.labelMedium,
                            color = PaletteWarmOrange,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun KpiCard(title: String, value: String, accent: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    Surface(color = NavySurface, shape = RoundedCornerShape(14.dp), modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, style = MaterialTheme.typography.bodySmall, color = CreamSoft, maxLines = 1)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = accent, maxLines = 1)
        }
    }
}

@Composable
private fun HighlightRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = CreamSoft)
        Spacer(modifier = Modifier.width(12.dp))
        Text(value, style = MaterialTheme.typography.titleSmall, color = PaletteCream, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun ListeningActivityChart(points: List<ActivityPoint>) {
    if (points.isEmpty()) return
    val maxPlays = (points.maxOfOrNull { it.playCount } ?: 0).coerceAtLeast(1)

    Column {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
        ) {
            val count = points.size
            val slotWidth = size.width / count
            val barWidth = (slotWidth * 0.48f).coerceAtMost(44f)
            val usableHeight = size.height - 16f

            val linePath = Path()
            points.forEachIndexed { idx, pt ->
                val frac = pt.playCount.toFloat() / maxPlays.toFloat()
                val barH = (usableHeight * frac).coerceAtLeast(if (pt.playCount > 0) 10f else 4f)
                val xCenter = slotWidth * idx + slotWidth / 2f
                val topY = size.height - barH

                drawRoundRect(
                    color = if (pt.playCount > 0) PaletteDeepTeal else NavyAbyss,
                    topLeft = Offset(xCenter - barWidth / 2f, topY),
                    size = Size(barWidth, barH),
                    cornerRadius = CornerRadius(10f, 10f)
                )

                if (idx == 0) linePath.moveTo(xCenter, topY) else linePath.lineTo(xCenter, topY)
            }

            drawPath(
                path = linePath,
                color = PaletteWarmOrange,
                style = Stroke(width = 4f, cap = StrokeCap.Round)
            )

            points.forEachIndexed { idx, pt ->
                val frac = pt.playCount.toFloat() / maxPlays.toFloat()
                val barH = (usableHeight * frac).coerceAtLeast(if (pt.playCount > 0) 10f else 4f)
                val xCenter = slotWidth * idx + slotWidth / 2f
                val topY = size.height - barH
                drawCircle(
                    color = PaletteWarmOrange,
                    radius = 6f,
                    center = Offset(xCenter, topY)
                )
            }
        }
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
            points.forEach { pt ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${pt.playCount}", style = MaterialTheme.typography.labelSmall, color = PaletteWarmOrange)
                    Text(pt.label, style = MaterialTheme.typography.labelSmall, color = CreamSoft)
                }
            }
        }
    }
}

@Composable
fun SongDetailsScreen(
    song: SongEntity?,
    onBack: () -> Unit,
    onPlay: (SongEntity) -> Unit,
    onRename: (SongEntity) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyAbyss)
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                Icon(Icons.Rounded.ArrowBackIosNew, contentDescription = "Back", tint = PaletteCream)
            }
            Text("Song Details", style = MaterialTheme.typography.headlineMedium, color = PaletteCream)
        }
        if (song == null) {
            Spacer(modifier = Modifier.height(40.dp))
            Text("Song not found.", style = MaterialTheme.typography.bodyLarge, color = CreamSoft)
            return
        }

        Spacer(modifier = Modifier.height(14.dp))
        SongArtwork(
            artworkPath = song.artworkPath,
            contentDescription = song.displayTitle,
            modifier = Modifier.size(180.dp).align(Alignment.CenterHorizontally),
            cornerRadius = 18.dp
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = song.displayTitle,
            style = MaterialTheme.typography.headlineMedium,
            color = PaletteCream,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Text(
            text = song.artist,
            style = MaterialTheme.typography.titleMedium,
            color = PaletteWarmOrange,
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        Spacer(modifier = Modifier.height(14.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = { onPlay(song) },
                colors = ButtonDefaults.buttonColors(containerColor = PaletteWarmOrange, contentColor = NavyAbyss),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Play", fontWeight = FontWeight.Bold)
            }
            OutlinedButton(
                onClick = { onRename(song) },
                border = androidx.compose.foundation.BorderStroke(1.dp, PaletteDeepTeal),
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Rounded.Edit, contentDescription = null, tint = PaletteCream)
                Spacer(modifier = Modifier.width(4.dp))
                Text("Rename", color = PaletteCream)
            }
        }

        Spacer(modifier = Modifier.height(18.dp))
        Surface(color = NavySurface, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DetailRow("Song played", "${song.playCount}")
                DetailRow("Original Title", song.originalTitle)
                DetailRow("Album", song.album)
                DetailRow("Duration", formatDurationMs(song.durationMs))
                DetailRow("File Size", formatBytes(song.fileSizeBytes))
                DetailRow("Audio Format", song.audioFormat)
                DetailRow("Source", song.sourceType)
                DetailRow("Offline Status", if (song.isAvailableOffline) "Saved on Device" else "Online Only")
                DetailRow("Downloaded", formatDate(song.downloadDate))
                DetailRow("Last Played", formatDate(song.lastPlayedAt))
                song.sourceUrl?.let { DetailRow("Source URL", it) }
            }
        }
        Spacer(modifier = Modifier.height(80.dp))
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelSmall, color = PaletteWarmOrange)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = PaletteCream)
    }
}

@Composable
fun SettingsScreen(
    settings: UserSettingsEntity?,
    onBack: () -> Unit,
    onUpdateSettings: ((UserSettingsEntity) -> UserSettingsEntity) -> Unit
) {
    val current = settings ?: UserSettingsEntity(userId = 0L)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyAbyss)
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                Icon(Icons.Rounded.ArrowBackIosNew, contentDescription = "Back", tint = PaletteCream)
            }
            Text("App Settings", style = MaterialTheme.typography.headlineMedium, color = PaletteCream)
        }
        Spacer(modifier = Modifier.height(16.dp))

        Text("Default Download Audio Quality", style = MaterialTheme.typography.titleMedium, color = PaletteWarmOrange)
        Spacer(modifier = Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            listOf("HIGH" to "High", "STANDARD" to "Standard", "DATA_SAVER" to "Saver").forEach { (key, label) ->
                FilterChip(
                    selected = current.preferredQuality == key,
                    onClick = { onUpdateSettings { it.copy(preferredQuality = key) } },
                    label = { Text(label) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = PaletteWarmOrange,
                        selectedLabelColor = NavyAbyss,
                        containerColor = NavySurface,
                        labelColor = PaletteCream
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
        Surface(color = NavySurface, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Auto-fetch Lyrics", style = MaterialTheme.typography.titleMedium, color = PaletteCream)
                        Text("Automatically cache synced lyrics when online", style = MaterialTheme.typography.bodySmall, color = CreamSoft)
                    }
                    Switch(
                        checked = current.autoFetchLyrics,
                        onCheckedChange = { checked -> onUpdateSettings { it.copy(autoFetchLyrics = checked) } },
                        colors = SwitchDefaults.colors(checkedThumbColor = NavyAbyss, checkedTrackColor = PaletteWarmOrange)
                    )
                }
                HorizontalDivider(color = PaletteDeepNavy)
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Keep Screen On in Player", style = MaterialTheme.typography.titleMedium, color = PaletteCream)
                        Text("Useful while following synced lyrics", style = MaterialTheme.typography.bodySmall, color = CreamSoft)
                    }
                    Switch(
                        checked = current.keepScreenOnPlayer,
                        onCheckedChange = { checked -> onUpdateSettings { it.copy(keepScreenOnPlayer = checked) } },
                        colors = SwitchDefaults.colors(checkedThumbColor = NavyAbyss, checkedTrackColor = PaletteWarmOrange)
                    )
                }
            }
        }
    }
}

@Composable
fun ChangePasswordScreen(
    onBack: () -> Unit,
    onSubmit: (current: String, next: String, confirm: String) -> Unit
) {
    var current by remember { mutableStateOf("") }
    var next by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyAbyss)
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                Icon(Icons.Rounded.ArrowBackIosNew, contentDescription = "Back", tint = PaletteCream)
            }
            Text("Change Password", style = MaterialTheme.typography.headlineMedium, color = PaletteCream)
        }
        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = current,
            onValueChange = { current = it },
            label = { Text("Current Password") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            colors = authTextFieldColors(),
            modifier = Modifier.fillMaxWidth().testTag("change_pw_current")
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
            value = next,
            onValueChange = { next = it },
            label = { Text("New Password (min 6 characters)") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            colors = authTextFieldColors(),
            modifier = Modifier.fillMaxWidth().testTag("change_pw_new")
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
            value = confirm,
            onValueChange = { confirm = it },
            label = { Text("Confirm New Password") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            colors = authTextFieldColors(),
            modifier = Modifier.fillMaxWidth().testTag("change_pw_confirm")
        )
        Spacer(modifier = Modifier.height(22.dp))
        Button(
            onClick = { onSubmit(current, next, confirm) },
            colors = ButtonDefaults.buttonColors(containerColor = PaletteWarmOrange, contentColor = NavyAbyss),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("change_pw_submit")
        ) {
            Text("Update Password", fontWeight = FontWeight.Bold)
        }
    }
}
