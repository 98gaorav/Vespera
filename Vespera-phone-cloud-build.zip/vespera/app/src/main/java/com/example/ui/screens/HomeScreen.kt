package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.db.DownloadTaskEntity
import com.example.data.local.db.PlaylistWithMeta
import com.example.data.local.db.SongEntity
import com.example.data.local.db.UserEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.util.formatBytes
import java.util.Calendar

@Composable
fun HomeScreen(
    user: UserEntity?,
    allSongs: List<SongEntity>,
    recentlyPlayed: List<SongEntity>,
    recentlyAdded: List<SongEntity>,
    recentlyPlayedPlaylists: List<PlaylistWithMeta>,
    activeDownloads: List<DownloadTaskEntity>,
    totalStorageBytes: Long,
    currentPlayingSongId: Long?,
    isPlaying: Boolean,
    onImportAudioFiles: (List<android.net.Uri>) -> Unit,
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenYouTubeDownload: () -> Unit,
    onPlaySong: (SongEntity, List<SongEntity>, String) -> Unit,
    onOpenSongOptions: (SongEntity) -> Unit,
    onOpenPlaylist: (Long) -> Unit,
    onPauseDownload: (String) -> Unit,
    onResumeDownload: (String) -> Unit,
    onCancelDownload: (String) -> Unit,
    onDismissFailedDownload: (String) -> Unit
) {
    val importAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments(),
        onResult = { uris -> if (uris.isNotEmpty()) onImportAudioFiles(uris) }
    )

    val greeting = remember {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        when {
            hour < 12 -> "Good morning"
            hour < 17 -> "Good afternoon"
            else -> "Good evening"
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(PaletteDeepNavy.copy(alpha = 0.55f), NavyAbyss, NavyAbyss)
                )
            ),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 160.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Header greeting & utility actions
        item {
            Row(
                modifier = Modifier.fillMaxWidth().statusBarsPadding(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (user != null) {
                    UserAvatar(
                        username = user.username,
                        avatarPath = user.avatarPath,
                        avatarColorHex = user.avatarColorHex,
                        size = 44.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "$greeting, ${user?.username ?: "Listener"}",
                        style = MaterialTheme.typography.headlineMedium,
                        color = PaletteCream,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "Your offline music sanctuary",
                        style = MaterialTheme.typography.bodySmall,
                        color = CreamSoft
                    )
                }
                IconButton(
                    onClick = { importAudioLauncher.launch(arrayOf("audio/*")) },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("import_audio_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.LibraryAdd,
                        contentDescription = "Import local audio files",
                        tint = PaletteWarmOrange
                    )
                }
                IconButton(
                    onClick = onOpenSettings,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("home_settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Settings,
                        contentDescription = "Settings",
                        tint = PaletteCream
                    )
                }
            }
        }

        // Search entry bar
        item {
            Surface(
                color = NavySurface,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onOpenSearch)
                    .testTag("home_search_bar")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Rounded.Search, contentDescription = null, tint = PaletteWarmOrange)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Search songs, artists, albums, playlists…",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CreamSoft
                    )
                }
            }
        }

        // Library Statistics Row
        item {
            val totalPlays = remember(allSongs) { allSongs.sumOf { it.playCount } }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                LibraryStatChip(
                    label = "Tracks",
                    value = "${allSongs.size}",
                    accent = PaletteWarmOrange,
                    modifier = Modifier.weight(1f)
                )
                LibraryStatChip(
                    label = "Plays",
                    value = "$totalPlays",
                    accent = PaletteTerracotta,
                    modifier = Modifier.weight(1f)
                )
                LibraryStatChip(
                    label = "Offline",
                    value = formatBytes(totalStorageBytes),
                    accent = PaletteDeepTeal,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Active YouTube Downloads
        if (activeDownloads.isNotEmpty()) {
            item {
                ActiveDownloadsSection(
                    tasks = activeDownloads,
                    onPause = onPauseDownload,
                    onResume = onResumeDownload,
                    onCancel = onCancelDownload,
                    onDismissFailed = onDismissFailedDownload
                )
            }
        }

        // Recently Played Songs
        if (recentlyPlayed.isNotEmpty()) {
            item {
                SectionHeader("Recently Played", "${recentlyPlayed.size} tracks")
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(recentlyPlayed, key = { "recent_${it.songId}" }) { song ->
                        HorizontalSongCard(
                            song = song,
                            isCurrent = song.songId == currentPlayingSongId,
                            onClick = { onPlaySong(song, recentlyPlayed, "Recently Played") },
                            onOptions = { onOpenSongOptions(song) }
                        )
                    }
                }
            }
        }

        // Recently Played Playlists
        if (recentlyPlayedPlaylists.isNotEmpty()) {
            item {
                SectionHeader("Recently Played Playlists", "${recentlyPlayedPlaylists.size} lists")
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(recentlyPlayedPlaylists, key = { "rpl_${it.playlist.playlistId}" }) { meta ->
                        Column(
                            modifier = Modifier
                                .width(142.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(NavySurface)
                                .clickable { onOpenPlaylist(meta.playlist.playlistId) }
                                .padding(10.dp)
                        ) {
                            PlaylistCollageArtwork(
                                customCoverPath = meta.playlist.customCoverPath,
                                collageArtworks = meta.collageArtworks,
                                contentDescription = meta.playlist.name,
                                modifier = Modifier.fillMaxWidth().aspectRatio(1f),
                                cornerRadius = 10.dp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = meta.playlist.name,
                                style = MaterialTheme.typography.titleSmall,
                                color = PaletteCream,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${meta.songCount} songs",
                                style = MaterialTheme.typography.bodySmall,
                                color = CreamSoft
                            )
                        }
                    }
                }
            }
        }

        // Recently Added Songs
        if (recentlyAdded.isNotEmpty()) {
            item {
                SectionHeader("Recently Added", "Fresh offline")
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(recentlyAdded, key = { "added_${it.songId}" }) { song ->
                        HorizontalSongCard(
                            song = song,
                            isCurrent = song.songId == currentPlayingSongId,
                            onClick = { onPlaySong(song, recentlyAdded, "Recently Added") },
                            onOptions = { onOpenSongOptions(song) }
                        )
                    }
                }
            }
        }

        // All Downloaded Songs Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                SectionHeader("All Downloaded Songs", "${allSongs.size} offline")
                TextButton(onClick = { importAudioLauncher.launch(arrayOf("audio/*")) }) {
                    Icon(Icons.Rounded.Add, contentDescription = null, tint = PaletteWarmOrange, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Import", color = PaletteWarmOrange)
                }
            }
        }

        if (allSongs.isEmpty()) {
            item {
                Surface(
                    color = NavySurface,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.MusicOff,
                            contentDescription = null,
                            tint = PaletteWarmOrange,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Your offline library is quiet",
                            style = MaterialTheme.typography.titleLarge,
                            color = PaletteCream
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Import local audio files or tap the orange download button to extract audio from YouTube.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CreamSoft
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(
                                onClick = { importAudioLauncher.launch(arrayOf("audio/*")) },
                                border = androidx.compose.foundation.BorderStroke(1.dp, PaletteDeepTeal)
                            ) {
                                Text("Import Audio", color = PaletteCream)
                            }
                            Button(
                                onClick = onOpenYouTubeDownload,
                                colors = ButtonDefaults.buttonColors(containerColor = PaletteWarmOrange, contentColor = NavyAbyss)
                            ) {
                                Text("YouTube Download", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        } else {
            items(allSongs, key = { it.songId }) { song ->
                SongRowItem(
                    song = song,
                    isCurrentSong = song.songId == currentPlayingSongId,
                    isPlaying = isPlaying,
                    onClick = { onPlaySong(song, allSongs, "Offline Library") },
                    onOptionsClick = { onOpenSongOptions(song) }
                )
            }
        }
    }
}

@Composable
private fun LibraryStatChip(
    label: String,
    value: String,
    accent: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = NavySurface,
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Text(text = label, style = MaterialTheme.typography.bodySmall, color = CreamSoft)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = accent,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun SectionHeader(title: String, badge: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = PaletteCream
        )
        Spacer(modifier = Modifier.width(8.dp))
        Surface(color = PaletteDeepNavy, shape = RoundedCornerShape(8.dp)) {
            Text(
                text = badge,
                style = MaterialTheme.typography.labelSmall,
                color = PaletteWarmOrange,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
        }
    }
}

@Composable
private fun HorizontalSongCard(
    song: SongEntity,
    isCurrent: Boolean,
    onClick: () -> Unit,
    onOptions: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(146.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (isCurrent) PaletteDeepNavy else NavySurface)
            .clickable(onClick = onClick)
            .padding(10.dp)
    ) {
        Box {
            SongArtwork(
                artworkPath = song.artworkPath,
                contentDescription = song.displayTitle,
                modifier = Modifier.fillMaxWidth().aspectRatio(1f),
                cornerRadius = 10.dp
            )
            IconButton(
                onClick = onOptions,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(NavyAbyss.copy(alpha = 0.65f))
            ) {
                Icon(Icons.Rounded.MoreVert, contentDescription = "Options", tint = PaletteCream, modifier = Modifier.size(18.dp))
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = song.displayTitle,
            style = MaterialTheme.typography.titleSmall,
            color = if (isCurrent) PaletteWarmOrange else PaletteCream,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = song.artist,
            style = MaterialTheme.typography.bodySmall,
            color = CreamSoft,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
