package com.example.ui.navigation

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryMusic
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.data.local.db.DownloadStatus
import com.example.data.local.db.SongEntity
import com.example.ui.VesperaViewModel
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.serialization.Serializable

@Serializable object SplashRoute
@Serializable object LoginRoute
@Serializable object SignUpRoute
@Serializable object HomeRoute
@Serializable object PlaylistsRoute
@Serializable object AccountRoute
@Serializable object SearchRoute
@Serializable object CreatePlaylistRoute
@Serializable data class PlaylistDetailRoute(val playlistId: Long)
@Serializable object PlayerRoute
@Serializable object LyricsRoute
@Serializable object AnalyticsRoute
@Serializable data class SongDetailsRoute(val songId: Long)
@Serializable object SettingsRoute
@Serializable object ChangePasswordRoute

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VesperaAppRoot(viewModel: VesperaViewModel) {
    val navController = rememberNavController()
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    val sessionLoaded by viewModel.sessionLoaded.collectAsStateWithLifecycle()
    val activeUserId by viewModel.activeUserId.collectAsStateWithLifecycle()
    val activeUser by viewModel.activeUser.collectAsStateWithLifecycle()
    val allAccounts by viewModel.allRegisteredAccounts.collectAsStateWithLifecycle()
    val allSongs by viewModel.allSongs.collectAsStateWithLifecycle()
    val recentlyPlayed by viewModel.recentlyPlayedSongs.collectAsStateWithLifecycle()
    val recentlyAdded by viewModel.recentlyAddedSongs.collectAsStateWithLifecycle()
    val totalStorageBytes by viewModel.totalStorageBytes.collectAsStateWithLifecycle()
    val playlistsWithMeta by viewModel.playlistsWithMeta.collectAsStateWithLifecycle()
    val recentlyPlayedPlaylists by viewModel.recentlyPlayedPlaylists.collectAsStateWithLifecycle()
    val activeDownloads by viewModel.activeDownloads.collectAsStateWithLifecycle()
    val recentDownloads by viewModel.recentDownloads.collectAsStateWithLifecycle()
    val playbackState by viewModel.playbackState.collectAsStateWithLifecycle()
    val userSettings by viewModel.userSettings.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val searchMatchedSongs by viewModel.searchMatchedSongs.collectAsStateWithLifecycle()
    val searchMatchedPlaylists by viewModel.searchMatchedPlaylists.collectAsStateWithLifecycle()
    val searchMatchedArtists by viewModel.searchMatchedArtists.collectAsStateWithLifecycle()
    val searchMatchedAlbums by viewModel.searchMatchedAlbums.collectAsStateWithLifecycle()
    val analyticsRange by viewModel.analyticsRange.collectAsStateWithLifecycle()
    val analyticsSnapshot by viewModel.analyticsSnapshot.collectAsStateWithLifecycle()
    val lyricsEntity by viewModel.currentSongLyrics.collectAsStateWithLifecycle()
    val parsedLrc by viewModel.parsedLrcLines.collectAsStateWithLifecycle()
    val lyricsLoading by viewModel.lyricsLoading.collectAsStateWithLifecycle()
    val youtubePreview by viewModel.youtubePreview.collectAsStateWithLifecycle()
    val authError by viewModel.authError.collectAsStateWithLifecycle()
    val authBusy by viewModel.authBusy.collectAsStateWithLifecycle()

    var splashDone by remember { mutableStateOf(false) }
    var showYouTubeDownloadSheet by remember { mutableStateOf(false) }
    var showAccountSwitcher by remember { mutableStateOf(false) }

    // Song Options & Modals State
    var optionsTargetSong by remember { mutableStateOf<SongEntity?>(null) }
    var optionsPlaylistContextId by remember { mutableStateOf<Long?>(null) }
    var addToPlaylistSong by remember { mutableStateOf<SongEntity?>(null) }
    var renameTargetSong by remember { mutableStateOf<SongEntity?>(null) }
    var deleteConfirmSong by remember { mutableStateOf<SongEntity?>(null) }
    var artworkTargetSongId by remember { mutableStateOf<Long?>(null) }
    var downloadBannerTitle by remember { mutableStateOf<String?>(null) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = {}
    )

    val songArtworkPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            val sid = artworkTargetSongId
            if (uri != null && sid != null) {
                viewModel.updateSongArtwork(sid, uri)
            }
            artworkTargetSongId = null
        }
    )

    LaunchedEffect(Unit) {
        viewModel.uiMessages.collect { msg ->
            snackbarHostState.showSnackbar(msg, duration = SnackbarDuration.Short)
        }
    }

    // Celebrate newly completed downloads
    var lastCompletedIds by remember { mutableStateOf<Set<String>>(emptySet()) }
    LaunchedEffect(recentDownloads) {
        val completed = recentDownloads.filter { it.status == DownloadStatus.COMPLETED }
        val newCompleted = completed.firstOrNull { it.taskId !in lastCompletedIds }
        if (lastCompletedIds.isNotEmpty() && newCompleted != null) {
            downloadBannerTitle = newCompleted.title
            delay(3200)
            downloadBannerTitle = null
        }
        lastCompletedIds = completed.map { it.taskId }.toSet()
    }

    // Automatic navigation when session state changes after splash
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDest = navBackStackEntry?.destination

    LaunchedEffect(splashDone, sessionLoaded, activeUserId) {
        if (!splashDone || !sessionLoaded) return@LaunchedEffect
        val inAuthOrSplash = currentDest?.hasRoute<SplashRoute>() == true ||
            currentDest?.hasRoute<LoginRoute>() == true ||
            currentDest?.hasRoute<SignUpRoute>() == true

        if (activeUserId == null && currentDest?.hasRoute<LoginRoute>() != true && currentDest?.hasRoute<SignUpRoute>() != true) {
            navController.navigate(LoginRoute) {
                popUpTo(0) { inclusive = true }
            }
        } else if (activeUserId != null && inAuthOrSplash) {
            navController.navigate(HomeRoute) {
                popUpTo(0) { inclusive = true }
            }
        }
    }

    val showMainChrome = activeUserId != null && (
        currentDest?.hasRoute<HomeRoute>() == true ||
            currentDest?.hasRoute<PlaylistsRoute>() == true ||
            currentDest?.hasRoute<AccountRoute>() == true ||
            currentDest?.hasRoute<PlaylistDetailRoute>() == true
        )

    Scaffold(
        containerColor = NavyAbyss,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = {
            SnackbarHost(snackbarHostState) { data ->
                Snackbar(
                    snackbarData = data,
                    containerColor = PaletteDeepNavy,
                    contentColor = PaletteCream,
                    actionColor = PaletteWarmOrange
                )
            }
        },
        bottomBar = {
            if (showMainChrome) {
                VesperaBottomBar(
                    isHome = currentDest?.hasRoute<HomeRoute>() == true,
                    isPlaylists = currentDest?.hasRoute<PlaylistsRoute>() == true || currentDest?.hasRoute<PlaylistDetailRoute>() == true,
                    isAccount = currentDest?.hasRoute<AccountRoute>() == true,
                    onSelectHome = {
                        navController.navigate(HomeRoute) {
                            popUpTo(HomeRoute) { inclusive = true }
                            launchSingleTop = true
                        }
                    },
                    onSelectPlaylists = {
                        navController.navigate(PlaylistsRoute) {
                            popUpTo(HomeRoute)
                            launchSingleTop = true
                        }
                    },
                    onSelectAccount = {
                        navController.navigate(AccountRoute) {
                            popUpTo(HomeRoute)
                            launchSingleTop = true
                        }
                    },
                    onLongPressAccount = {
                        showAccountSwitcher = true
                    }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            NavHost(
                navController = navController,
                startDestination = SplashRoute,
                enterTransition = {
                    fadeIn(tween(240)) + slideInHorizontally(tween(260)) { it / 12 }
                },
                exitTransition = {
                    fadeOut(tween(180))
                },
                popEnterTransition = {
                    fadeIn(tween(220))
                },
                popExitTransition = {
                    fadeOut(tween(200)) + slideOutHorizontally(tween(220)) { it / 12 }
                }
            ) {
                composable<SplashRoute> {
                    SplashScreen(
                        onFinished = {
                            splashDone = true
                            if (activeUserId != null) {
                                navController.navigate(HomeRoute) {
                                    popUpTo(SplashRoute) { inclusive = true }
                                }
                            } else {
                                navController.navigate(LoginRoute) {
                                    popUpTo(SplashRoute) { inclusive = true }
                                }
                            }
                        }
                    )
                }

                composable<LoginRoute> {
                    LoginScreen(
                        existingAccounts = allAccounts,
                        authError = authError,
                        isBusy = authBusy,
                        onClearError = { viewModel.clearAuthError() },
                        onLogin = { u, p ->
                            viewModel.login(u, p) {
                                navController.navigate(HomeRoute) {
                                    popUpTo(0) { inclusive = true }
                                }
                            }
                        },
                        onQuickSwitch = { uid ->
                            viewModel.switchAccount(uid)
                            navController.navigate(HomeRoute) {
                                popUpTo(0) { inclusive = true }
                            }
                        },
                        onNavigateToSignUp = { navController.navigate(SignUpRoute) }
                    )
                }

                composable<SignUpRoute> {
                    SignUpScreen(
                        authError = authError,
                        isBusy = authBusy,
                        onClearError = { viewModel.clearAuthError() },
                        onSignUp = { u, p, c ->
                            viewModel.signUp(u, p, c) {
                                navController.navigate(HomeRoute) {
                                    popUpTo(0) { inclusive = true }
                                }
                            }
                        },
                        onBackToLogin = { navController.popBackStack() }
                    )
                }

                composable<HomeRoute> {
                    HomeScreen(
                        user = activeUser,
                        allSongs = allSongs,
                        recentlyPlayed = recentlyPlayed,
                        recentlyAdded = recentlyAdded,
                        recentlyPlayedPlaylists = recentlyPlayedPlaylists,
                        activeDownloads = activeDownloads,
                        totalStorageBytes = totalStorageBytes,
                        currentPlayingSongId = playbackState.currentSong?.songId,
                        isPlaying = playbackState.isPlaying,
                        onImportAudioFiles = { uris -> viewModel.importAudioFiles(uris) },
                        onOpenSearch = { navController.navigate(SearchRoute) },
                        onOpenSettings = { navController.navigate(SettingsRoute) },
                        onOpenYouTubeDownload = {
                            requestNotificationPermIfNeeded(context, notificationPermissionLauncher)
                            viewModel.resetYouTubePreview()
                            showYouTubeDownloadSheet = true
                        },
                        onPlaySong = { song, col, label -> viewModel.playSong(song, col, null, label) },
                        onOpenSongOptions = { song ->
                            optionsPlaylistContextId = null
                            optionsTargetSong = song
                        },
                        onOpenPlaylist = { pid -> navController.navigate(PlaylistDetailRoute(pid)) },
                        onPauseDownload = { viewModel.pauseDownload(it) },
                        onResumeDownload = { viewModel.resumeDownload(it) },
                        onCancelDownload = { viewModel.cancelDownload(it) },
                        onDismissFailedDownload = { viewModel.dismissDownloadTask(it) }
                    )
                }

                composable<PlaylistsRoute> {
                    PlaylistsLibraryScreen(
                        playlists = playlistsWithMeta,
                        onCreatePlaylist = { navController.navigate(CreatePlaylistRoute) },
                        onOpenPlaylist = { pid -> navController.navigate(PlaylistDetailRoute(pid)) }
                    )
                }

                composable<CreatePlaylistRoute> {
                    CreatePlaylistScreen(
                        allSongs = allSongs,
                        onCreate = { name, coverUri, songIds ->
                            viewModel.createPlaylist(name, coverUri, songIds) { newPid ->
                                navController.popBackStack()
                                navController.navigate(PlaylistDetailRoute(newPid))
                            }
                        },
                        onCancel = { navController.popBackStack() }
                    )
                }

                composable<PlaylistDetailRoute> { entry ->
                    val route = entry.toRoute<PlaylistDetailRoute>()
                    val playlist by viewModel.observePlaylist(route.playlistId).collectAsStateWithLifecycle(initialValue = null)
                    val items by viewModel.observePlaylistSongs(route.playlistId).collectAsStateWithLifecycle(initialValue = emptyList())
                    PlaylistDetailScreen(
                        playlist = playlist,
                        items = items,
                        allSongs = allSongs,
                        currentPlayingSongId = playbackState.currentSong?.songId,
                        isPlaying = playbackState.isPlaying,
                        onBack = { navController.popBackStack() },
                        onPlayAll = { songs, shuffle ->
                            viewModel.playPlaylist(songs, route.playlistId, playlist?.name ?: "Playlist", shuffle)
                        },
                        onPlaySong = { song, songs ->
                            viewModel.playSong(song, songs, route.playlistId, playlist?.name ?: "Playlist")
                        },
                        onOpenSongOptions = { song ->
                            optionsPlaylistContextId = route.playlistId
                            optionsTargetSong = song
                        },
                        onAddSongs = { songIds -> viewModel.addSongsToPlaylist(route.playlistId, songIds) },
                        onRenamePlaylist = { newName -> viewModel.renamePlaylist(route.playlistId, newName) },
                        onUpdateCover = { uri -> viewModel.updatePlaylistCover(route.playlistId, uri) },
                        onDeletePlaylist = {
                            viewModel.deletePlaylist(route.playlistId) {
                                navController.popBackStack()
                            }
                        }
                    )
                }

                composable<AccountRoute> {
                    AccountScreen(
                        user = activeUser,
                        analytics = analyticsSnapshot,
                        onUpdateAvatar = { uri -> viewModel.updateProfilePicture(uri) },
                        onOpenAnalytics = { navController.navigate(AnalyticsRoute) },
                        onOpenSettings = { navController.navigate(SettingsRoute) },
                        onOpenChangePassword = { navController.navigate(ChangePasswordRoute) },
                        onOpenAccountSwitcher = { showAccountSwitcher = true },
                        onSignOut = { viewModel.signOutActive() }
                    )
                }

                composable<SearchRoute> {
                    SearchScreen(
                        query = searchQuery,
                        matchedSongs = searchMatchedSongs,
                        matchedPlaylists = searchMatchedPlaylists,
                        matchedArtists = searchMatchedArtists,
                        matchedAlbums = searchMatchedAlbums,
                        currentSongId = playbackState.currentSong?.songId,
                        isPlaying = playbackState.isPlaying,
                        onQueryChange = { viewModel.updateSearchQuery(it) },
                        onBack = { navController.popBackStack() },
                        onPlaySong = { song, col -> viewModel.playSong(song, col, null, "Search Results") },
                        onOpenSongOptions = { song ->
                            optionsPlaylistContextId = null
                            optionsTargetSong = song
                        },
                        onOpenPlaylist = { pid -> navController.navigate(PlaylistDetailRoute(pid)) }
                    )
                }

                composable<PlayerRoute>(
                    enterTransition = { slideInVertically(tween(320)) { it } + fadeIn(tween(240)) },
                    exitTransition = { slideOutVertically(tween(280)) { it } + fadeOut(tween(200)) }
                ) {
                    PlayerScreen(
                        state = playbackState,
                        onBack = { navController.popBackStack() },
                        onTogglePlayPause = { viewModel.togglePlayPause() },
                        onSeek = { viewModel.seekTo(it) },
                        onNext = { viewModel.skipNext() },
                        onPrevious = { viewModel.skipPrevious() },
                        onToggleShuffle = { viewModel.toggleShuffle() },
                        onCycleRepeat = { viewModel.cycleRepeatMode() },
                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                        onOpenLyrics = { navController.navigate(LyricsRoute) },
                        onOpenOptions = { song ->
                            optionsPlaylistContextId = playbackState.sourcePlaylistId
                            optionsTargetSong = song
                        },
                        onJumpToQueueIndex = { viewModel.jumpToQueueIndex(it) }
                    )
                }

                composable<LyricsRoute>(
                    enterTransition = { slideInVertically(tween(300)) { it } },
                    exitTransition = { slideOutVertically(tween(260)) { it } }
                ) {
                    LyricsScreen(
                        song = playbackState.currentSong,
                        lyricsEntity = lyricsEntity,
                        parsedLrc = parsedLrc,
                        positionMs = playbackState.positionMs,
                        isLoading = lyricsLoading,
                        onBack = { navController.popBackStack() },
                        onRefreshLyrics = { viewModel.refreshCurrentLyrics() },
                        onSaveManualLyrics = { sid, plain, lrc -> viewModel.saveManualLyrics(sid, plain, lrc) }
                    )
                }

                composable<AnalyticsRoute> {
                    AnalyticsDashboardScreen(
                        snapshot = analyticsSnapshot,
                        selectedRange = analyticsRange,
                        onSelectRange = { viewModel.setAnalyticsRange(it) },
                        onBack = { navController.popBackStack() }
                    )
                }

                composable<SongDetailsRoute> { entry ->
                    val route = entry.toRoute<SongDetailsRoute>()
                    val song by viewModel.observeSongById(route.songId).collectAsStateWithLifecycle(initialValue = null)
                    SongDetailsScreen(
                        song = song,
                        onBack = { navController.popBackStack() },
                        onPlay = { s -> viewModel.playSong(s, allSongs, null, "Offline Library") },
                        onRename = { s -> renameTargetSong = s }
                    )
                }

                composable<SettingsRoute> {
                    SettingsScreen(
                        settings = userSettings,
                        onBack = { navController.popBackStack() },
                        onUpdateSettings = { transform -> viewModel.updateSettings(transform) }
                    )
                }

                composable<ChangePasswordRoute> {
                    ChangePasswordScreen(
                        onBack = { navController.popBackStack() },
                        onSubmit = { curr, next, conf ->
                            viewModel.changePassword(curr, next, conf) {
                                navController.popBackStack()
                            }
                        }
                    )
                }
            }

            // Download Completion Celebration Banner
            AnimatedVisibility(
                visible = downloadBannerTitle != null,
                enter = slideInVertically { -it } + fadeIn(),
                exit = slideOutVertically { -it } + fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 12.dp, start = 20.dp, end = 20.dp)
            ) {
                Surface(
                    color = PaletteDeepTeal,
                    shape = RoundedCornerShape(16.dp),
                    shadowElevation = 10.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.CheckCircle, contentDescription = null, tint = PaletteWarmOrange)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Offline ready: ${downloadBannerTitle.orEmpty()}",
                            style = MaterialTheme.typography.titleSmall,
                            color = PaletteCream
                        )
                    }
                }
            }

            // Floating MiniPlayer + Bottom-Right Download FAB over main screens
            if (showMainChrome) {
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FloatingDownloadButton(
                        onClick = {
                            requestNotificationPermIfNeeded(context, notificationPermissionLauncher)
                            viewModel.resetYouTubePreview()
                            showYouTubeDownloadSheet = true
                        }
                    )

                    val currentSong = playbackState.currentSong
                    if (currentSong != null) {
                        val dur = playbackState.durationMs.coerceAtLeast(currentSong.durationMs).coerceAtLeast(1L)
                        MiniPlayerBar(
                            song = currentSong,
                            isPlaying = playbackState.isPlaying,
                            progressFraction = (playbackState.positionMs.toFloat() / dur.toFloat()),
                            onExpand = { navController.navigate(PlayerRoute) },
                            onTogglePlayPause = { viewModel.togglePlayPause() },
                            onNext = { viewModel.skipNext() }
                        )
                    }
                }
            }
        }
    }

    // --- Global Modals & Bottom Sheets ---

    optionsTargetSong?.let { song ->
        val pidContext = optionsPlaylistContextId
        SongOptionsSheet(
            song = song,
            onDismiss = { optionsTargetSong = null },
            onAddToPlaylist = { addToPlaylistSong = song },
            onPlayOnRepeat = {
                viewModel.playOnRepeat(song, allSongs, pidContext, if (pidContext != null) "Playlist" else "Offline Library")
            },
            onRenameSong = { renameTargetSong = song },
            onChangeArtwork = {
                artworkTargetSongId = song.songId
                songArtworkPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
            onViewDetails = { navController.navigate(SongDetailsRoute(song.songId)) },
            onDeleteSong = { deleteConfirmSong = song },
            extraRemoveFromPlaylistLabel = if (pidContext != null) "Remove from playlist" else null,
            onRemoveFromPlaylist = if (pidContext != null) {
                { viewModel.removeSongFromPlaylist(pidContext, song.songId) }
            } else null
        )
    }

    addToPlaylistSong?.let { song ->
        val containingIds by viewModel.observePlaylistsContainingSong(song.songId).collectAsStateWithLifecycle(initialValue = emptyList())
        AddToPlaylistDialog(
            song = song,
            playlists = playlistsWithMeta,
            containingPlaylistIds = containingIds,
            onTogglePlaylist = { meta ->
                viewModel.toggleSongInPlaylist(meta.playlist.playlistId, meta.playlist.name, song.songId)
            },
            onCreateNewPlaylist = { navController.navigate(CreatePlaylistRoute) },
            onDismiss = { addToPlaylistSong = null }
        )
    }

    renameTargetSong?.let { song ->
        RenameSongDialog(
            currentTitle = song.displayTitle,
            onConfirm = { newTitle ->
                viewModel.renameSong(song.songId, newTitle)
                renameTargetSong = null
            },
            onDismiss = { renameTargetSong = null }
        )
    }

    deleteConfirmSong?.let { song ->
        DeleteSongConfirmDialog(
            songTitle = song.displayTitle,
            onConfirm = {
                viewModel.deleteSong(song.songId)
                deleteConfirmSong = null
            },
            onDismiss = { deleteConfirmSong = null }
        )
    }

    if (showYouTubeDownloadSheet) {
        YouTubeDownloadSheet(
            state = youtubePreview,
            onUrlChange = { viewModel.updateYouTubeUrl(it) },
            onFetchInfo = { viewModel.fetchYouTubeInfo(it) },
            onTitleChange = { viewModel.updateYouTubeEditableTitle(it) },
            onArtworkPicked = { viewModel.updateYouTubeCustomArtwork(it) },
            onQualityChange = { viewModel.updateYouTubeQuality(it) },
            onStartDownload = {
                viewModel.startYouTubeDownload {
                    showYouTubeDownloadSheet = false
                }
            },
            onDismiss = { showYouTubeDownloadSheet = false }
        )
    }

    if (showAccountSwitcher) {
        AccountSwitcherSheet(
            activeUser = activeUser,
            accounts = allAccounts,
            onSwitchAccount = { uid -> viewModel.switchAccount(uid) },
            onAddAccountLogin = {
                navController.navigate(LoginRoute)
            },
            onChangePassword = {
                navController.navigate(ChangePasswordRoute)
            },
            onSignOutActive = { viewModel.signOutActive() },
            onDismiss = { showAccountSwitcher = false }
        )
    }
}

@Composable
private fun FloatingDownloadButton(onClick: () -> Unit) {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.90f else 1f,
        animationSpec = spring(dampingRatio = 0.6f),
        label = "fab_scale"
    )
    Surface(
        onClick = onClick,
        interactionSource = interactionSource,
        shape = RoundedCornerShape(18.dp),
        color = PaletteWarmOrange,
        contentColor = NavyAbyss,
        shadowElevation = 10.dp,
        modifier = Modifier
            .scale(scale)
            .size(56.dp)
            .shadow(8.dp, RoundedCornerShape(18.dp))
            .testTag("floating_download_button")
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = Icons.Rounded.Download,
                contentDescription = "Download audio from YouTube",
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun VesperaBottomBar(
    isHome: Boolean,
    isPlaylists: Boolean,
    isAccount: Boolean,
    onSelectHome: () -> Unit,
    onSelectPlaylists: () -> Unit,
    onSelectAccount: () -> Unit,
    onLongPressAccount: () -> Unit
) {
    val haptics = LocalHapticFeedback.current
    Surface(
        color = NavySurface,
        tonalElevation = 8.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(
                label = "Home",
                selected = isHome,
                selectedIcon = Icons.Rounded.Home,
                unselectedIcon = Icons.Outlined.Home,
                onClick = onSelectHome,
                modifier = Modifier.weight(1f).testTag("nav_home")
            )
            BottomNavItem(
                label = "Playlists",
                selected = isPlaylists,
                selectedIcon = Icons.Rounded.LibraryMusic,
                unselectedIcon = Icons.Outlined.LibraryMusic,
                onClick = onSelectPlaylists,
                modifier = Modifier.weight(1f).testTag("nav_playlists")
            )
            BottomNavItem(
                label = "Account",
                selected = isAccount,
                selectedIcon = Icons.Rounded.Person,
                unselectedIcon = Icons.Outlined.Person,
                onClick = onSelectAccount,
                onLongClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongPressAccount()
                },
                modifier = Modifier.weight(1f).testTag("nav_account")
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun BottomNavItem(
    label: String,
    selected: Boolean,
    selectedIcon: ImageVector,
    unselectedIcon: ImageVector,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val pillColor by animateColorAsState(
        targetValue = if (selected) PaletteTerracotta.copy(alpha = 0.25f) else androidx.compose.ui.graphics.Color.Transparent,
        label = "nav_pill"
    )
    Column(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(16.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(pillColor)
                .padding(horizontal = 18.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (selected) selectedIcon else unselectedIcon,
                contentDescription = label,
                tint = if (selected) PaletteWarmOrange else CreamSoft,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
            ),
            color = if (selected) PaletteWarmOrange else CreamSoft
        )
    }
}

private fun requestNotificationPermIfNeeded(
    context: android.content.Context,
    launcher: androidx.activity.result.ActivityResultLauncher<String>
) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        val granted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
        if (!granted) {
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
