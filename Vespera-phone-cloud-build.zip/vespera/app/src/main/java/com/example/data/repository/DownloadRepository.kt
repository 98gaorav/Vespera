package com.example.data.repository

import android.content.Context
import android.net.Uri
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.example.data.local.db.DownloadStatus
import com.example.data.local.db.DownloadTaskDao
import com.example.data.local.db.DownloadTaskEntity
import com.example.data.local.storage.LocalStorageManager
import com.example.data.network.YouTubeAudioExtractor
import com.example.data.network.YouTubeTrackInfo
import com.example.worker.AudioDownloadWorker
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class DownloadRepository(
    private val context: Context,
    private val downloadTaskDao: DownloadTaskDao,
    private val extractor: YouTubeAudioExtractor,
    private val storageManager: LocalStorageManager
) {
    private val workManager: WorkManager by lazy { WorkManager.getInstance(context) }

    fun observeActiveTasks(userId: Long): Flow<List<DownloadTaskEntity>> =
        downloadTaskDao.observeActiveTasks(userId)

    fun observeRecentTasks(userId: Long): Flow<List<DownloadTaskEntity>> =
        downloadTaskDao.observeRecentTasks(userId)

    fun isValidYouTubeUrl(url: String): Boolean = extractor.isValidYouTubeUrl(url)

    suspend fun fetchYouTubeMetadata(url: String): Result<YouTubeTrackInfo> =
        extractor.fetchMetadata(url)

    suspend fun enqueueDownload(
        userId: Long,
        youtubeUrl: String,
        videoId: String,
        customTitle: String,
        artist: String,
        durationMs: Long,
        thumbnailUrl: String?,
        customArtworkUri: Uri?,
        quality: String
    ): String {
        val taskId = UUID.randomUUID().toString()
        val localThumbPath = customArtworkUri?.let {
            runCatching { storageManager.copyImageUriToArtwork(userId, it) }.getOrNull()
        }
        val task = DownloadTaskEntity(
            taskId = taskId,
            userId = userId,
            youtubeUrl = youtubeUrl.trim(),
            videoId = videoId,
            title = customTitle.trim().ifBlank { "YouTube Audio" },
            artist = artist.trim().ifBlank { "YouTube Creator" },
            durationMs = durationMs,
            thumbnailUrl = thumbnailUrl,
            localThumbnailPath = localThumbPath,
            audioQuality = quality,
            status = DownloadStatus.QUEUED
        )
        downloadTaskDao.upsertTask(task)
        scheduleWorker(taskId)
        return taskId
    }

    suspend fun pauseDownload(taskId: String) {
        val task = downloadTaskDao.getTaskById(taskId) ?: return
        downloadTaskDao.upsertTask(
            task.copy(status = DownloadStatus.PAUSED, speedBytesPerSec = 0L, etaSeconds = -1L)
        )
        workManager.cancelUniqueWork(workName(taskId))
    }

    suspend fun resumeDownload(taskId: String) {
        val task = downloadTaskDao.getTaskById(taskId) ?: return
        downloadTaskDao.upsertTask(
            task.copy(status = DownloadStatus.QUEUED, errorMessage = null)
        )
        scheduleWorker(taskId)
    }

    suspend fun cancelDownload(taskId: String) {
        val task = downloadTaskDao.getTaskById(taskId)
        if (task != null) {
            downloadTaskDao.upsertTask(task.copy(status = DownloadStatus.CANCELLED))
            storageManager.deleteFileSafely(task.tempAudioPath)
            storageManager.deleteFileSafely(task.localThumbnailPath)
            downloadTaskDao.deleteTask(taskId)
        }
        workManager.cancelUniqueWork(workName(taskId))
    }

    suspend fun dismissTask(taskId: String) {
        downloadTaskDao.deleteTask(taskId)
    }

    private fun scheduleWorker(taskId: String) {
        val input = Data.Builder()
            .putString(AudioDownloadWorker.KEY_TASK_ID, taskId)
            .build()
        val request = OneTimeWorkRequestBuilder<AudioDownloadWorker>()
            .setInputData(input)
            .build()
        workManager.enqueueUniqueWork(
            workName(taskId),
            ExistingWorkPolicy.REPLACE,
            request
        )
    }

    private fun workName(taskId: String) = "yt_download_$taskId"
}
