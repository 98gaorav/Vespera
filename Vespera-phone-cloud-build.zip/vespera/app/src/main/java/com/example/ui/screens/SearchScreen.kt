package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.local.db.PlaylistWithMeta
import com.example.data.local.db.SongEntity
import com.example.ui.components.PlaylistCollageArtwork
import com.example.ui.components.SongRowItem
import com.example.ui.theme.*

@Composable
fun SearchScreen(
    query: String,
    matchedSongs: List<SongEntity>,
    matchedPlaylists: List<PlaylistWithMeta>,
    matchedArtists: List<String>,
    matchedAlbums: List<String>,
    currentSongId: Long?,
    isPlaying: Boolean,
    onQueryChange: (String) -> Unit,
    onBack: () -> Unit,
    onPlaySong: (SongEntity, List<SongEntity>) -> Unit,
    onOpenSongOptions: (SongEntity) -> Unit,
    onOpenPlaylist: (Long) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyAbyss)
            .safeDrawingPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.minimumInteractiveComponentSize()
            ) {
                Icon(Icons.Rounded.ArrowBackIosNew, contentDescription = "Back", tint = PaletteCream)
            }
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                placeholder = { Text("Songs, artists, albums, playlists…", color = CreamMuted) },
                singleLine = true,
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, tint = PaletteWarmOrange) },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { onQueryChange("") }) {
                            Icon(Icons.Rounded.Close, contentDescription = "Clear search", tint = CreamSoft)
                        }
                    }
                },
                colors = authTextFieldColors(),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.weight(1f).testTag("search_query_input")
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (query.trim().isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = PaletteDeepTeal, modifier = Modifier.size(56.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Search your offline library", style = MaterialTheme.typography.titleMedium, color = PaletteCream)
                    Text("Type a song title, artist, album, or playlist name", style = MaterialTheme.typography.bodySmall, color = CreamSoft)
                }
            }
        } else if (matchedSongs.isEmpty() && matchedPlaylists.isEmpty() && matchedArtists.isEmpty() && matchedAlbums.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.SearchOff, contentDescription = null, tint = PaletteTerracotta, modifier = Modifier.size(52.dp))
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("No matches for \"$query\"", style = MaterialTheme.typography.titleMedium, color = PaletteCream)
                    Text("Try a different spelling or import more tracks", style = MaterialTheme.typography.bodySmall, color = CreamSoft)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 120.dp)
            ) {
                if (matchedSongs.isNotEmpty()) {
                    item {
                        Text("Songs", style = MaterialTheme.typography.titleMedium, color = PaletteWarmOrange)
                    }
                    items(matchedSongs, key = { "s_${it.songId}" }) { song ->
                        SongRowItem(
                            song = song,
                            isCurrentSong = song.songId == currentSongId,
                            isPlaying = isPlaying,
                            onClick = { onPlaySong(song, matchedSongs) },
                            onOptionsClick = { onOpenSongOptions(song) }
                        )
                    }
                }

                if (matchedPlaylists.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Playlists", style = MaterialTheme.typography.titleMedium, color = PaletteWarmOrange)
                    }
                    items(matchedPlaylists, key = { "p_${it.playlist.playlistId}" }) { meta ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(NavySurface)
                                .clickable { onOpenPlaylist(meta.playlist.playlistId) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PlaylistCollageArtwork(
                                customCoverPath = meta.playlist.customCoverPath,
                                collageArtworks = meta.collageArtworks,
                                contentDescription = meta.playlist.name,
                                modifier = Modifier.size(48.dp),
                                cornerRadius = 10.dp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(meta.playlist.name, style = MaterialTheme.typography.titleMedium, color = PaletteCream)
                                Text("${meta.songCount} songs", style = MaterialTheme.typography.bodySmall, color = CreamSoft)
                            }
                        }
                    }
                }

                if (matchedArtists.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Artists", style = MaterialTheme.typography.titleMedium, color = PaletteWarmOrange)
                    }
                    items(matchedArtists, key = { "a_$it" }) { artist ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(NavySurface)
                                .clickable { onQueryChange(artist) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Person, contentDescription = null, tint = PaletteDeepTeal)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(artist, style = MaterialTheme.typography.bodyLarge, color = PaletteCream)
                        }
                    }
                }

                if (matchedAlbums.isNotEmpty()) {
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Albums", style = MaterialTheme.typography.titleMedium, color = PaletteWarmOrange)
                    }
                    items(matchedAlbums, key = { "al_$it" }) { album ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(NavySurface)
                                .clickable { onQueryChange(album) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Rounded.Album, contentDescription = null, tint = PaletteTerracotta)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(album, style = MaterialTheme.typography.bodyLarge, color = PaletteCream)
                        }
                    }
                }
            }
        }
    }
}
