package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.VesperaModularLogo
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(
    onFinished: () -> Unit
) {
    val leftProgress = remember { Animatable(0f) }
    val topProgress = remember { Animatable(0f) }
    val bottomProgress = remember { Animatable(0f) }
    val rightProgress = remember { Animatable(0f) }
    val rotationDeg = remember { Animatable(-24f) }
    val logoScale = remember { Animatable(0.84f) }
    val glowProgress = remember { Animatable(0f) }
    val titleAlpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        val springSpec = spring<Float>(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        )
        // Staggered directional entry
        launch {
            leftProgress.animateTo(1f, tween(620, easing = FastOutSlowInEasing))
        }
        launch {
            delay(90)
            bottomProgress.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
        }
        launch {
            delay(160)
            topProgress.animateTo(1f, tween(620, easing = FastOutSlowInEasing))
        }
        launch {
            delay(230)
            rightProgress.animateTo(1f, springSpec)
        }
        launch {
            rotationDeg.animateTo(0f, tween(820, easing = FastOutSlowInEasing))
        }
        launch {
            logoScale.animateTo(1f, springSpec)
        }

        delay(820)
        launch {
            glowProgress.animateTo(1f, tween(420, easing = FastOutSlowInEasing))
        }
        launch {
            titleAlpha.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
        }
        delay(650)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(PaletteDeepNavy, NavyAbyss)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            VesperaModularLogo(
                size = 152.dp,
                leftProgress = leftProgress.value,
                topProgress = topProgress.value,
                bottomProgress = bottomProgress.value,
                rightProgress = rightProgress.value,
                glowProgress = glowProgress.value,
                assembleRotationDeg = rotationDeg.value,
                modifier = Modifier.scale(logoScale.value)
            )
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "VESPERA",
                style = MaterialTheme.typography.displayLarge.copy(letterSpacing = 6.sp),
                color = PaletteCream,
                modifier = Modifier.alpha(titleAlpha.value)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "OFFLINE AUDIO SANCTUARY",
                style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 2.5.sp),
                color = PaletteWarmOrange,
                modifier = Modifier.alpha(titleAlpha.value)
            )
        }
    }
}
