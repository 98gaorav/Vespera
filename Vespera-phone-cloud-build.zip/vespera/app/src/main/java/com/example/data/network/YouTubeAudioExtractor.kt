package com.example.data.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class YouTubeTrackInfo(
    val videoId: String,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val thumbnailUrl: String
)

data class ResolvedAudioStream(
    val streamUrl: String,
    val mimeType: String,
    val formatExtension: String,
    val contentLengthBytes: Long,
    val bitrateKbps: Int
)

class YouTubeAudioExtractor(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
) {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    fun extractVideoId(url: String): String? {
        val trimmed = url.trim()
        val patterns = listOf(
            Regex("""(?:youtube\.com/watch\?.*v=|youtu\.be/|youtube\.com/shorts/|youtube\.com/embed/|youtube\.com/live/|music\.youtube\.com/watch\?.*v=)([A-Za-z0-9_-]{11})"""),
            Regex("""^([A-Za-z0-9_-]{11})$""")
        )
        for (pattern in patterns) {
            val match = pattern.find(trimmed)
            if (match != null) return match.groupValues[1]
        }
        return null
    }

    fun isValidYouTubeUrl(url: String): Boolean = extractVideoId(url) != null

    suspend fun fetchMetadata(url: String): Result<YouTubeTrackInfo> = withContext(Dispatchers.IO) {
        runCatching {
            val videoId = extractVideoId(url)
                ?: throw IllegalArgumentException("Please enter a valid YouTube or YouTube Music link.")
            val canonicalUrl = "https://www.youtube.com/watch?v=$videoId"
            val fallbackThumb = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg"

            var title: String? = null
            var artist: String? = null
            var thumbUrl: String? = null
            var durationMs = 0L

            // 1) Try InnerTube player API for full duration, title, author, thumbnail
            runCatching {
                val playerJson = callInnerTubePlayer(videoId)
                val details = playerJson.optJSONObject("videoDetails")
                if (details != null) {
                    title = details.optString("title").takeIf { it.isNotBlank() }
                    artist = details.optString("author").takeIf { it.isNotBlank() }
                    durationMs = details.optString("lengthSeconds").toLongOrNull()?.times(1000L) ?: 0L
                    val thumbs = details.optJSONObject("thumbnail")?.optJSONArray("thumbnails")
                    if (thumbs != null && thumbs.length() > 0) {
                        thumbUrl = thumbs.getJSONObject(thumbs.length() - 1).optString("url")
                            .takeIf { it.isNotBlank() }
                    }
                }
            }

            // 2) Fallback/enrich with official YouTube oEmbed endpoint
            if (title.isNullOrBlank() || artist.isNullOrBlank()) {
                val encoded = URLEncoder.encode(canonicalUrl, "UTF-8")
                val oembedReq = Request.Builder()
                    .url("https://www.youtube.com/oembed?url=$encoded&format=json")
                    .header("User-Agent", "Mozilla/5.0")
                    .build()
                client.newCall(oembedReq).execute().use { resp ->
                    if (resp.isSuccessful) {
                        val body = resp.body?.string().orEmpty()
                        val obj = JSONObject(body)
                        if (title.isNullOrBlank()) {
                            title = obj.optString("title").takeIf { it.isNotBlank() }
                        }
                        if (artist.isNullOrBlank()) {
                            artist = obj.optString("author_name").takeIf { it.isNotBlank() }
                        }
                        if (thumbUrl.isNullOrBlank()) {
                            thumbUrl = obj.optString("thumbnail_url").takeIf { it.isNotBlank() }
                        }
                    }
                }
            }

            // 3) Fallback duration via watch page HTML meta if still 0
            if (durationMs == 0L) {
                runCatching {
                    val pageReq = Request.Builder()
                        .url(canonicalUrl)
                        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14)")
                        .build()
                    client.newCall(pageReq).execute().use { resp ->
                        val html = resp.body?.string().orEmpty()
                        Regex(""""lengthSeconds":"(\d+)"""").find(html)?.groupValues?.get(1)
                            ?.toLongOrNull()?.let { durationMs = it * 1000L }
                        if (title.isNullOrBlank()) {
                            Regex("""<title>(.*?)</title>""").find(html)?.groupValues?.get(1)
                                ?.replace(" - YouTube", "")?.trim()?.let { title = it }
                        }
                    }
                }
            }

            YouTubeTrackInfo(
                videoId = videoId,
                title = title ?: "YouTube Audio ($videoId)",
                artist = artist ?: "YouTube Creator",
                durationMs = durationMs,
                thumbnailUrl = thumbUrl ?: fallbackThumb
            )
        }
    }

    suspend fun resolveAudioStream(
        videoId: String,
        qualityPreference: String
    ): Result<ResolvedAudioStream> = withContext(Dispatchers.IO) {
        runCatching {
            val candidates = mutableListOf<ResolvedAudioStream>()

            // Attempt 1: YouTube InnerTube IOS & ANDROID clients (provide direct audio-only URLs)
            val clients = listOf(
                Triple("IOS", "19.29.1", "com.google.ios.youtube/19.29.1 (iPhone16,2; U; CPU iOS 17_5_1 like Mac OS X;)"),
                Triple("ANDROID", "19.29.37", "com.google.android.youtube/19.29.37 (Linux; U; Android 14) gzip")
            )
            for ((clientName, clientVersion, userAgent) in clients) {
                runCatching {
                    val json = callInnerTubePlayer(videoId, clientName, clientVersion, userAgent)
                    val adaptive = json.optJSONObject("streamingData")?.optJSONArray("adaptiveFormats")
                    if (adaptive != null) {
                        for (i in 0 until adaptive.length()) {
                            val item = adaptive.getJSONObject(i)
                            val mime = item.optString("mimeType")
                            val url = item.optString("url")
                            if (mime.startsWith("audio/") && url.isNotBlank()) {
                                val isM4a = mime.contains("audio/mp4") || mime.contains("mp4a")
                                val ext = if (isM4a) "m4a" else "webm"
                                val bitrate = (item.optInt("averageBitrate", item.optInt("bitrate", 128000))) / 1000
                                val contentLen = item.optString("contentLength").toLongOrNull() ?: -1L
                                candidates.add(
                                    ResolvedAudioStream(
                                        streamUrl = url,
                                        mimeType = mime,
                                        formatExtension = ext,
                                        contentLengthBytes = contentLen,
                                        bitrateKbps = bitrate
                                    )
                                )
                            }
                        }
                    }
                }
                if (candidates.isNotEmpty()) break
            }

            // Attempt 2: Piped public instances fallback for audio-only stream resolution
            if (candidates.isEmpty()) {
                val pipedInstances = listOf(
                    "https://pipedapi.kavin.rocks",
                    "https://pipedapi.adminforge.de"
                )
                for (host in pipedInstances) {
                    runCatching {
                        val req = Request.Builder()
                            .url("$host/streams/$videoId")
                            .header("User-Agent", "Vespera/1.0")
                            .build()
                        client.newCall(req).execute().use { resp ->
                            if (resp.isSuccessful) {
                                val obj = JSONObject(resp.body?.string().orEmpty())
                                val audioStreams = obj.optJSONArray("audioStreams")
                                if (audioStreams != null) {
                                    for (i in 0 until audioStreams.length()) {
                                        val s = audioStreams.getJSONObject(i)
                                        val url = s.optString("url")
                                        val mime = s.optString("mimeType", "audio/mp4")
                                        if (url.isNotBlank()) {
                                            val isM4a = mime.contains("mp4") || s.optString("format") == "M4A"
                                            candidates.add(
                                                ResolvedAudioStream(
                                                    streamUrl = url,
                                                    mimeType = mime,
                                                    formatExtension = if (isM4a) "m4a" else "webm",
                                                    contentLengthBytes = s.optLong("contentLength", -1L),
                                                    bitrateKbps = (s.optInt("bitrate", 128000)) / 1000
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (candidates.isNotEmpty()) break
                }
            }

            if (candidates.isEmpty()) {
                throw IllegalStateException(
                    "Unable to extract an audio stream for this video right now. Verify network connectivity or try a different public music video."
                )
            }

            // Prefer M4A (AAC) for universal Media3/Android playback compatibility
            val m4aFirst = candidates.sortedWith(
                compareByDescending<ResolvedAudioStream> { it.formatExtension == "m4a" }
                    .thenBy {
                        when (qualityPreference.uppercase()) {
                            "DATA_SAVER" -> it.bitrateKbps
                            "STANDARD" -> kotlin.math.abs(it.bitrateKbps - 128)
                            else -> -it.bitrateKbps
                        }
                    }
            )
            m4aFirst.first()
        }
    }

    private fun callInnerTubePlayer(
        videoId: String,
        clientName: String = "IOS",
        clientVersion: String = "19.29.1",
        userAgent: String = "com.google.ios.youtube/19.29.1 (iPhone16,2; U; CPU iOS 17_5_1 like Mac OS X;)"
    ): JSONObject {
        val payload = JSONObject().apply {
            put("videoId", videoId)
            put("context", JSONObject().apply {
                put("client", JSONObject().apply {
                    put("clientName", clientName)
                    put("clientVersion", clientVersion)
                    put("hl", "en")
                    put("gl", "US")
                })
            })
            put("contentCheckOk", true)
            put("racyCheckOk", true)
        }

        val req = Request.Builder()
            .url("https://www.youtube.com/youtubei/v1/player?prettyPrint=false")
            .header("Content-Type", "application/json")
            .header("User-Agent", userAgent)
            .post(payload.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) {
                throw IllegalStateException("YouTube metadata HTTP ${resp.code}")
            }
            return JSONObject(resp.body?.string().orEmpty())
        }
    }
}
