package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Strict 5-color Vespera palette
val PaletteTerracotta = Color(0xFFB65B3F)
val PaletteWarmOrange = Color(0xFFF9BC66)
val PaletteCream = Color(0xFFE5DFC0)
val PaletteDeepTeal = Color(0xFF087586)
val PaletteDeepNavy = Color(0xFF0A4771)

// Tonal steps strictly derived from the 5-color palette for accessible layering & contrast
val NavyAbyss = Color(0xFF05243A)
val NavySurface = Color(0xFF073250)
val NavyElevated = Color(0xFF0C5180)
val TealDeep = Color(0xFF065B68)
val TealMuted = Color(0xFF0A8598)
val CreamSoft = Color(0xFFC4BFA4)
val CreamMuted = Color(0xFF9C9882)
val TerracottaDeep = Color(0xFF8E422B)
val OrangeSoft = Color(0xFFFBD193)

val AvatarPaletteHex = listOf(
    "#B65B3F",
    "#087586",
    "#0A4771",
    "#F9BC66",
    "#8E422B"
)
