package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.db.LyricsEntity
import com.example.data.local.db.SongEntity
import com.example.data.network.LrcLine
import com.example.data.network.LrcParser
import com.example.player.PlaybackUiState
import com.example.player.RepeatModeState
import com.example.ui.components.SongArtwork
import com.example.ui.theme.*
import com.example.ui.util.formatDurationMs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerScreen(
    state: PlaybackUiState,
    onBack: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onSeek: (Long) -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onToggleShuffle: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleFavorite: (Long) -> Unit,
    onOpenLyrics: () -> Unit,
    onOpenOptions: (SongEntity) -> Unit,
    onJumpToQueueIndex: (Int) -> Unit
) {
    val song = state.currentSong
    var showQueueSheet by remember { mutableStateOf(false) }
    var isScrubbing by remember { mutableStateOf(false) }
    var scrubPositionMs by remember { mutableLongStateOf(0L) }

    val displayedPos = if (isScrubbing) scrubPositionMs else state.positionMs
    val totalDur = state.durationMs.coerceAtLeast(song?.durationMs ?: 1L).coerceAtLeast(1L)
    val remainingMs = (totalDur - displayedPos).coerceAtLeast(0L)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(PaletteDeepTeal.copy(alpha = 0.72f), PaletteDeepNavy, NavyAbyss)
                )
            )
            .safeDrawingPadding()
    ) {
        if (song == null) {
            Column(
                modifier = Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                IconButton(onClick = onBack, modifier = Modifier.align(Alignment.Start)) {
                    Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Close player", tint = PaletteCream)
                }
                Spacer(modifier = Modifier.weight(1f))
                Icon(Icons.Rounded.MusicNote, contentDescription = null, tint = PaletteWarmOrange, modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text("Select a track to play", style = MaterialTheme.typography.titleLarge, color = PaletteCream)
                Spacer(modifier = Modifier.weight(1f))
            }
            return@Box
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 560.dp)
                .align(Alignment.Center)
                .padding(horizontal = 24.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("player_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.KeyboardArrowDown,
                        contentDescription = "Minimize player",
                        tint = PaletteCream,
                        modifier = Modifier.size(30.dp)
                    )
                }
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "PLAYING FROM",
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.6.sp),
                        color = CreamSoft
                    )
                    Text(
                        text = state.sourceLabel,
                        style = MaterialTheme.typography.titleSmall,
                        color = PaletteCream,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(
                    onClick = { onOpenOptions(song) },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("player_options_button")
                ) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = "Song options", tint = PaletteCream)
                }
            }

            Spacer(modifier = Modifier.weight(0.6f))

            // Large Square Artwork with smooth transition on song change
            AnimatedContent(
                targetState = song.songId to song.artworkPath,
                transitionSpec = {
                    (fadeIn(tween(300)) + scaleIn(initialScale = 0.94f, animationSpec = tween(300)))
                        .togetherWith(fadeOut(tween(220)))
                },
                label = "player_artwork_transition"
            ) { (_, artPath) ->
                SongArtwork(
                    artworkPath = artPath,
                    contentDescription = "${song.displayTitle} cover art",
                    cornerRadius = 22.dp,
                    modifier = Modifier
                        .fillMaxWidth(0.88f)
                        .aspectRatio(1f)
                        .shadow(20.dp, RoundedCornerShape(22.dp))
                )
            }

            Spacer(modifier = Modifier.weight(0.6f))

            // Song Title, Artist, Favorite Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AnimatedContent(
                    targetState = song.displayTitle to song.artist,
                    transitionSpec = { fadeIn(tween(260)) togetherWith fadeOut(tween(180)) },
                    modifier = Modifier.weight(1f),
                    label = "player_title_transition"
                ) { (title, artist) ->
                    Column {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.headlineMedium,
                            color = PaletteCream,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = artist,
                            style = MaterialTheme.typography.titleMedium,
                            color = CreamSoft,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                IconButton(
                    onClick = { onToggleFavorite(song.songId) },
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("player_favorite_button")
                ) {
                    Icon(
                        imageVector = if (song.isFavorite) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        contentDescription = if (song.isFavorite) "Remove favorite" else "Favorite song",
                        tint = if (song.isFavorite) PaletteTerracotta else PaletteCream,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Seekable progress slider + timestamps (current / remaining / total)
            Slider(
                value = (displayedPos.toFloat() / totalDur.toFloat()).coerceIn(0f, 1f),
                onValueChange = { frac ->
                    isScrubbing = true
                    scrubPositionMs = (frac * totalDur).toLong()
                },
                onValueChangeFinished = {
                    onSeek(scrubPositionMs)
                    isScrubbing = false
                },
                colors = SliderDefaults.colors(
                    thumbColor = PaletteWarmOrange,
                    activeTrackColor = PaletteWarmOrange,
                    inactiveTrackColor = NavySurface
                ),
                modifier = Modifier.fillMaxWidth().testTag("player_seek_slider")
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatDurationMs(displayedPos),
                    style = MaterialTheme.typography.labelSmall,
                    color = CreamSoft
                )
                Text(
                    text = "-${formatDurationMs(remainingMs)}",
                    style = MaterialTheme.typography.labelSmall,
                    color = CreamMuted
                )
                Text(
                    text = formatDurationMs(totalDur),
                    style = MaterialTheme.typography.labelSmall,
                    color = CreamSoft
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Primary Playback Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Shuffle
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = onToggleShuffle,
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("player_shuffle_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Shuffle,
                            contentDescription = "Toggle shuffle",
                            tint = if (state.shuffleEnabled) PaletteWarmOrange else CreamSoft,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    if (state.shuffleEnabled) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(PaletteWarmOrange)
                        )
                    }
                }

                // Previous
                IconButton(
                    onClick = onPrevious,
                    modifier = Modifier.size(54.dp).testTag("player_prev_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.SkipPrevious,
                        contentDescription = "Previous song",
                        tint = PaletteCream,
                        modifier = Modifier.size(38.dp)
                    )
                }

                // Large circular Play / Pause
                FilledIconButton(
                    onClick = onTogglePlayPause,
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = PaletteWarmOrange,
                        contentColor = NavyAbyss
                    ),
                    modifier = Modifier
                        .size(72.dp)
                        .shadow(12.dp, CircleShape)
                        .testTag("player_play_pause_button")
                ) {
                    Icon(
                        imageVector = if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (state.isPlaying) "Pause" else "Play",
                        modifier = Modifier.size(40.dp)
                    )
                }

                // Next
                IconButton(
                    onClick = onNext,
                    modifier = Modifier.size(54.dp).testTag("player_next_button")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.SkipNext,
                        contentDescription = "Next song",
                        tint = PaletteCream,
                        modifier = Modifier.size(38.dp)
                    )
                }

                // Repeat (OFF -> PLAYLIST -> ONE)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    IconButton(
                        onClick = onCycleRepeat,
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("player_repeat_button")
                    ) {
                        Icon(
                            imageVector = when (state.repeatMode) {
                                RepeatModeState.ONE -> Icons.Rounded.RepeatOne
                                else -> Icons.Rounded.Repeat
                            },
                            contentDescription = "Repeat mode: ${state.repeatMode.name}",
                            tint = when (state.repeatMode) {
                                RepeatModeState.OFF -> CreamSoft
                                RepeatModeState.PLAYLIST -> PaletteWarmOrange
                                RepeatModeState.ONE -> PaletteTerracotta
                            },
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    if (state.repeatMode != RepeatModeState.OFF) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(
                                    if (state.repeatMode == RepeatModeState.ONE) PaletteTerracotta else PaletteWarmOrange
                                )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Secondary Controls: Output Device, Lyrics, Queue
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = NavySurface.copy(alpha = 0.7f),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (state.outputDeviceName.contains("Bluetooth")) Icons.Rounded.BluetoothAudio else Icons.Rounded.Speaker,
                            contentDescription = "Audio output",
                            tint = PaletteDeepTeal,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = state.outputDeviceName,
                            style = MaterialTheme.typography.labelSmall,
                            color = PaletteCream
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(
                        onClick = onOpenLyrics,
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = PaletteDeepTeal,
                            contentColor = PaletteCream
                        ),
                        modifier = Modifier.height(40.dp).testTag("player_lyrics_button")
                    ) {
                        Icon(Icons.Rounded.Lyrics, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Lyrics")
                    }

                    IconButton(
                        onClick = { showQueueSheet = true },
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("player_queue_button")
                    ) {
                        Icon(Icons.AutoMirrored.Rounded.QueueMusic, contentDescription = "Open playback queue", tint = PaletteCream)
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }
    }

    if (showQueueSheet) {
        ModalBottomSheet(
            onDismissRequest = { showQueueSheet = false },
            containerColor = NavySurface,
            contentColor = PaletteCream
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (state.shuffleEnabled) "Shuffled Queue (${state.queue.size})" else "Up Next (${state.queue.size})",
                        style = MaterialTheme.typography.titleLarge,
                        color = PaletteCream
                    )
                    Text(
                        text = state.sourceLabel,
                        style = MaterialTheme.typography.labelMedium,
                        color = PaletteWarmOrange
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                LazyColumn(
                    modifier = Modifier.heightIn(max = 380.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(state.queue, key = { idx, s -> "${idx}_${s.songId}" }) { index, item ->
                        val isCurrent = index == state.currentQueueIndex
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isCurrent) PaletteDeepNavy else NavyAbyss.copy(alpha = 0.5f))
                                .clickable {
                                    onJumpToQueueIndex(index)
                                    showQueueSheet = false
                                }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${index + 1}",
                                style = MaterialTheme.typography.labelMedium,
                                color = if (isCurrent) PaletteWarmOrange else CreamSoft,
                                modifier = Modifier.width(28.dp)
                            )
                            SongArtwork(item.artworkPath, item.displayTitle, Modifier.size(40.dp), 8.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.displayTitle,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = if (isCurrent) PaletteWarmOrange else PaletteCream,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = item.artist,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CreamSoft,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            if (isCurrent) {
                                Icon(Icons.Rounded.GraphicEq, contentDescription = "Now playing", tint = PaletteWarmOrange)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun LyricsScreen(
    song: SongEntity?,
    lyricsEntity: LyricsEntity?,
    parsedLrc: List<LrcLine>,
    positionMs: Long,
    isLoading: Boolean,
    onBack: () -> Unit,
    onRefreshLyrics: () -> Unit,
    onSaveManualLyrics: (songId: Long, plain: String?, synced: String?) -> Unit
) {
    var showEditor by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val activeLineIdx = remember(parsedLrc, positionMs) {
        LrcParser.findActiveLineIndex(parsedLrc, positionMs)
    }

    LaunchedEffect(activeLineIdx) {
        if (activeLineIdx >= 0 && parsedLrc.isNotEmpty()) {
            listState.animateScrollToItem((activeLineIdx - 2).coerceAtLeast(0))
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(PaletteTerracotta.copy(alpha = 0.55f), PaletteDeepNavy, NavyAbyss)
                )
            )
            .safeDrawingPadding()
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("lyrics_back_button")
                ) {
                    Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = "Close lyrics", tint = PaletteCream)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song?.displayTitle ?: "Lyrics",
                        style = MaterialTheme.typography.titleMedium,
                        color = PaletteCream,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = song?.artist ?: "",
                        style = MaterialTheme.typography.bodySmall,
                        color = CreamSoft
                    )
                }
                IconButton(onClick = onRefreshLyrics, modifier = Modifier.minimumInteractiveComponentSize()) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Fetch lyrics", tint = PaletteCream)
                }
                if (song != null) {
                    IconButton(
                        onClick = { showEditor = true },
                        modifier = Modifier.minimumInteractiveComponentSize().testTag("lyrics_edit_button")
                    ) {
                        Icon(Icons.Rounded.EditNote, contentDescription = "Edit lyrics", tint = PaletteWarmOrange)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = PaletteWarmOrange)
                }
            } else if (parsedLrc.isNotEmpty()) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(18.dp),
                    contentPadding = PaddingValues(vertical = 32.dp)
                ) {
                    itemsIndexed(parsedLrc) { idx, line ->
                        val isActive = idx == activeLineIdx
                        Text(
                            text = line.text,
                            style = if (isActive) {
                                MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                            } else {
                                MaterialTheme.typography.titleLarge
                            },
                            color = if (isActive) PaletteWarmOrange else CreamSoft.copy(alpha = 0.55f),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            } else if (!lyricsEntity?.plainLyrics.isNullOrBlank()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(vertical = 16.dp)
                ) {
                    Text(
                        text = lyricsEntity?.plainLyrics.orEmpty(),
                        style = MaterialTheme.typography.titleLarge.copy(lineHeight = 32.sp),
                        color = PaletteCream
                    )
                }
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Icon(Icons.Rounded.Lyrics, contentDescription = null, tint = PaletteWarmOrange, modifier = Modifier.size(56.dp))
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "No lyrics found offline",
                            style = MaterialTheme.typography.titleLarge,
                            color = PaletteCream
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap Retry Lookup when online, or add your own plain or [mm:ss.xx] synced lyrics manually.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CreamSoft,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                        if (song != null) {
                            Button(
                                onClick = { showEditor = true },
                                colors = ButtonDefaults.buttonColors(containerColor = PaletteWarmOrange, contentColor = NavyAbyss)
                            ) {
                                Text("Add / Edit Lyrics", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditor && song != null) {
        var plainInput by remember(lyricsEntity) { mutableStateOf(lyricsEntity?.plainLyrics.orEmpty()) }
        var lrcInput by remember(lyricsEntity) { mutableStateOf(lyricsEntity?.syncedLrc.orEmpty()) }
        AlertDialog(
            onDismissRequest = { showEditor = false },
            containerColor = NavySurface,
            titleContentColor = PaletteCream,
            title = { Text("Edit Lyrics", style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(
                    modifier = Modifier.verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = lrcInput,
                        onValueChange = { lrcInput = it },
                        label = { Text("Synced LRC (optional, e.g. [00:12.50] Line)") },
                        minLines = 3,
                        maxLines = 6,
                        colors = authTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("lyrics_lrc_input")
                    )
                    OutlinedTextField(
                        value = plainInput,
                        onValueChange = { plainInput = it },
                        label = { Text("Plain Lyrics") },
                        minLines = 4,
                        maxLines = 8,
                        colors = authTextFieldColors(),
                        modifier = Modifier.fillMaxWidth().testTag("lyrics_plain_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSaveManualLyrics(song.songId, plainInput, lrcInput)
                        showEditor = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PaletteWarmOrange, contentColor = NavyAbyss),
                    modifier = Modifier.testTag("lyrics_save_button")
                ) {
                    Text("Save Offline")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditor = false }) {
                    Text("Cancel", color = CreamSoft)
                }
            }
        )
    }
}
