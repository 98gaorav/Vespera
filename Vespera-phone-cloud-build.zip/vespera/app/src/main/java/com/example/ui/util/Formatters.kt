package com.example.ui.util

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.PaletteDeepNavy
import com.example.ui.theme.PaletteDeepTeal
import com.example.ui.theme.PaletteTerracotta
import com.example.ui.theme.PaletteWarmOrange
import com.example.ui.theme.TerracottaDeep
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatDurationMs(ms: Long): String {
    if (ms <= 0L) return "0:00"
    val totalSeconds = ms / 1000L
    val hours = totalSeconds / 3600L
    val minutes = (totalSeconds % 3600L) / 60L
    val seconds = totalSeconds % 60L
    return if (hours > 0L) {
        String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format(Locale.US, "%d:%02d", minutes, seconds)
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1.0 -> String.format(Locale.US, "%.2f GB", gb)
        mb >= 1.0 -> String.format(Locale.US, "%.1f MB", mb)
        kb >= 1.0 -> String.format(Locale.US, "%.0f KB", kb)
        else -> "$bytes B"
    }
}

fun formatEtaSeconds(seconds: Long): String {
    if (seconds < 0L) return "Calculating…"
    if (seconds == 0L) return "Finishing…"
    val mins = seconds / 60L
    val secs = seconds % 60L
    return if (mins > 0L) {
        "${mins}m ${secs}s remaining"
    } else {
        "$secs seconds remaining"
    }
}

fun formatListeningDuration(ms: Long): String {
    if (ms <= 0L) return "0m"
    val totalMinutes = ms / 60_000L
    val hours = totalMinutes / 60L
    val mins = totalMinutes % 60L
    return when {
        hours > 0L -> "${hours}h ${mins}m"
        totalMinutes > 0L -> "${totalMinutes}m"
        else -> "${ms / 1000L}s"
    }
}

fun formatDate(timestamp: Long?): String {
    if (timestamp == null || timestamp <= 0L) return "Never"
    val fmt = SimpleDateFormat("MMM d, yyyy · HH:mm", Locale.getDefault())
    return fmt.format(Date(timestamp))
}

fun parsePaletteColor(hex: String): Color {
    return when (hex.uppercase()) {
        "#B65B3F" -> PaletteTerracotta
        "#087586" -> PaletteDeepTeal
        "#0A4771" -> PaletteDeepNavy
        "#F9BC66" -> PaletteWarmOrange
        "#8E422B" -> TerracottaDeep
        else -> PaletteTerracotta
    }
}
