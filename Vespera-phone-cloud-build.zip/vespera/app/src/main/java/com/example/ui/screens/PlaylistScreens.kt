package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.local.db.PlaylistEntity
import com.example.data.local.db.PlaylistSongItem
import com.example.data.local.db.PlaylistWithMeta
import com.example.data.local.db.SongEntity
import com.example.ui.components.PlaylistCollageArtwork
import com.example.ui.components.RenameSongDialog
import com.example.ui.components.SongArtwork
import com.example.ui.components.SongRowItem
import com.example.ui.theme.*

@Composable
fun PlaylistsLibraryScreen(
    playlists: List<PlaylistWithMeta>,
    onCreatePlaylist: () -> Unit,
    onOpenPlaylist: (Long) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(PaletteDeepNavy.copy(alpha = 0.55f), NavyAbyss, NavyAbyss)
                )
            )
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Playlists", style = MaterialTheme.typography.headlineLarge, color = PaletteCream)
                Text("${playlists.size} collection${if (playlists.size == 1) "" else "s"}", style = MaterialTheme.typography.bodySmall, color = CreamSoft)
            }
            FilledIconButton(
                onClick = onCreatePlaylist,
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = PaletteWarmOrange,
                    contentColor = NavyAbyss
                ),
                modifier = Modifier.size(48.dp).testTag("create_playlist_plus_button")
            ) {
                Icon(Icons.Rounded.Add, contentDescription = "Create playlist")
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        if (playlists.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(bottom = 120.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = NavySurface,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Rounded.QueueMusic, contentDescription = null, tint = PaletteWarmOrange, modifier = Modifier.size(52.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No playlists yet", style = MaterialTheme.typography.titleLarge, color = PaletteCream)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "Tap the + button to build your first playlist with custom artwork or an auto-generated 4-track collage.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CreamSoft
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onCreatePlaylist,
                            colors = ButtonDefaults.buttonColors(containerColor = PaletteWarmOrange, contentColor = NavyAbyss)
                        ) {
                            Icon(Icons.Rounded.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Create Playlist", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 156.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 160.dp)
            ) {
                items(playlists, key = { it.playlist.playlistId }) { meta ->
                    Column(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(NavySurface)
                            .clickable { onOpenPlaylist(meta.playlist.playlistId) }
                            .padding(10.dp)
                            .testTag("playlist_card_${meta.playlist.playlistId}")
                    ) {
                        PlaylistCollageArtwork(
                            customCoverPath = meta.playlist.customCoverPath,
                            collageArtworks = meta.collageArtworks,
                            contentDescription = meta.playlist.name,
                            modifier = Modifier.fillMaxWidth().aspectRatio(1f),
                            cornerRadius = 12.dp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = meta.playlist.name,
                            style = MaterialTheme.typography.titleMedium,
                            color = PaletteCream,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${meta.songCount} song${if (meta.songCount == 1) "" else "s"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = CreamSoft
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CreatePlaylistScreen(
    allSongs: List<SongEntity>,
    onCreate: (name: String, coverUri: Uri?, selectedSongIds: List<Long>) -> Unit,
    onCancel: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var coverUri by remember { mutableStateOf<Uri?>(null) }
    var selectedSongIds by remember { mutableStateOf<List<Long>>(emptyList()) }
    var showAddSongsModal by remember { mutableStateOf(false) }

    val imagePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> if (uri != null) coverUri = uri }
    )

    val selectedSongs = remember(allSongs, selectedSongIds) {
        val map = allSongs.associateBy { it.songId }
        selectedSongIds.mapNotNull { map[it] }
    }

    if (showAddSongsModal) {
        AddSongsMultiSelectScreen(
            allSongs = allSongs,
            alreadySelectedIds = selectedSongIds.toSet(),
            onConfirm = { newIds ->
                selectedSongIds = newIds
                showAddSongsModal = false
            },
            onCancel = { showAddSongsModal = false }
        )
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyAbyss)
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onCancel, modifier = Modifier.minimumInteractiveComponentSize()) {
                Icon(Icons.Rounded.Close, contentDescription = "Cancel", tint = PaletteCream)
            }
            Text("Create Playlist", style = MaterialTheme.typography.titleLarge, color = PaletteCream)
        }

        Spacer(modifier = Modifier.height(18.dp))

        Box(
            modifier = Modifier
                .size(164.dp)
                .align(Alignment.CenterHorizontally)
                .clip(RoundedCornerShape(18.dp))
                .background(PaletteDeepNavy)
                .clickable {
                    imagePicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
            contentAlignment = Alignment.Center
        ) {
            if (coverUri != null) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current).data(coverUri).build(),
                    contentDescription = "Playlist cover",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else if (selectedSongs.isNotEmpty()) {
                PlaylistCollageArtwork(
                    customCoverPath = null,
                    collageArtworks = selectedSongs.mapNotNull { it.artworkPath },
                    contentDescription = "Auto collage preview",
                    modifier = Modifier.fillMaxSize(),
                    cornerRadius = 18.dp
                )
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.AddPhotoAlternate, contentDescription = null, tint = PaletteWarmOrange, modifier = Modifier.size(40.dp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Choose Image", style = MaterialTheme.typography.labelLarge, color = PaletteCream)
                    Text("or auto 4-art collage", style = MaterialTheme.typography.bodySmall, color = CreamSoft)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Playlist name") },
            singleLine = true,
            colors = authTextFieldColors(),
            modifier = Modifier.fillMaxWidth().testTag("create_playlist_name_input")
        )

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedButton(
            onClick = { showAddSongsModal = true },
            border = androidx.compose.foundation.BorderStroke(1.dp, PaletteDeepTeal),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().height(50.dp).testTag("create_playlist_add_songs_btn")
        ) {
            Icon(Icons.Rounded.LibraryMusic, contentDescription = null, tint = PaletteWarmOrange)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (selectedSongs.isEmpty()) "Add Songs" else "Add / Edit Songs (${selectedSongs.size} selected)",
                color = PaletteCream
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (selectedSongs.isNotEmpty()) {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(selectedSongs, key = { _, s -> s.songId }) { index, song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(NavySurface)
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${index + 1}", style = MaterialTheme.typography.labelMedium, color = PaletteWarmOrange, modifier = Modifier.width(24.dp))
                        SongArtwork(song.artworkPath, song.displayTitle, Modifier.size(40.dp), 8.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(song.displayTitle, style = MaterialTheme.typography.titleSmall, color = PaletteCream, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(song.artist, style = MaterialTheme.typography.bodySmall, color = CreamSoft, maxLines = 1)
                        }
                    }
                }
            }
        } else {
            Spacer(modifier = Modifier.weight(1f))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onCancel,
                border = androidx.compose.foundation.BorderStroke(1.dp, PaletteDeepTeal),
                modifier = Modifier.weight(1f).height(50.dp)
            ) {
                Text("Cancel", color = PaletteCream)
            }
            Button(
                onClick = { onCreate(name, coverUri, selectedSongIds) },
                enabled = name.trim().isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = PaletteWarmOrange, contentColor = NavyAbyss),
                modifier = Modifier.weight(1.4f).height(50.dp).testTag("create_playlist_confirm_button")
            ) {
                Text("Create", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AddSongsMultiSelectScreen(
    allSongs: List<SongEntity>,
    alreadySelectedIds: Set<Long>,
    onConfirm: (List<Long>) -> Unit,
    onCancel: () -> Unit
) {
    BackHandler(onBack = onCancel)
    var selectedIds by remember(alreadySelectedIds) { mutableStateOf(alreadySelectedIds.toList()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyAbyss)
            .safeDrawingPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = onCancel, modifier = Modifier.testTag("add_songs_cancel_button")) {
                Text("Cancel", color = CreamSoft)
            }
            Text(
                text = "Add Songs (${selectedIds.size})",
                style = MaterialTheme.typography.titleLarge,
                color = PaletteCream
            )
            Button(
                onClick = { onConfirm(selectedIds) },
                colors = ButtonDefaults.buttonColors(containerColor = PaletteWarmOrange, contentColor = NavyAbyss),
                modifier = Modifier.testTag("add_songs_confirm_button")
            ) {
                Text("Confirm", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (allSongs.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No offline songs available yet.", style = MaterialTheme.typography.bodyLarge, color = CreamSoft)
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(bottom = 32.dp)
            ) {
                items(allSongs, key = { it.songId }) { song ->
                    val isSelected = song.songId in selectedIds
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSelected) PaletteDeepNavy else NavySurface)
                            .clickable {
                                selectedIds = if (isSelected) {
                                    selectedIds - song.songId
                                } else {
                                    selectedIds + song.songId
                                }
                            }
                            .padding(horizontal = 12.dp, vertical = 10.dp)
                            .testTag("select_song_row_${song.songId}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SongArtwork(song.artworkPath, song.displayTitle, Modifier.size(48.dp), 10.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(song.displayTitle, style = MaterialTheme.typography.titleMedium, color = PaletteCream, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(song.artist, style = MaterialTheme.typography.bodySmall, color = CreamSoft, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Checkbox(
                            checked = isSelected,
                            onCheckedChange = { checked ->
                                selectedIds = if (checked) (selectedIds + song.songId).distinct() else selectedIds - song.songId
                            },
                            colors = CheckboxDefaults.colors(
                                checkedColor = PaletteWarmOrange,
                                checkmarkColor = NavyAbyss,
                                uncheckedColor = PaletteDeepTeal
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PlaylistDetailScreen(
    playlist: PlaylistEntity?,
    items: List<PlaylistSongItem>,
    allSongs: List<SongEntity>,
    currentPlayingSongId: Long?,
    isPlaying: Boolean,
    onBack: () -> Unit,
    onPlayAll: (List<SongEntity>, Boolean) -> Unit,
    onPlaySong: (SongEntity, List<SongEntity>) -> Unit,
    onOpenSongOptions: (SongEntity) -> Unit,
    onAddSongs: (List<Long>) -> Unit,
    onRenamePlaylist: (String) -> Unit,
    onUpdateCover: (Uri) -> Unit,
    onDeletePlaylist: () -> Unit
) {
    var showAddSongs by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showRenameDialog by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val coverPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> if (uri != null) onUpdateCover(uri) }
    )

    if (showAddSongs) {
        AddSongsMultiSelectScreen(
            allSongs = allSongs,
            alreadySelectedIds = items.map { it.song.songId }.toSet(),
            onConfirm = { selected ->
                val existing = items.map { it.song.songId }.toSet()
                val toAdd = selected.filter { it !in existing }
                if (toAdd.isNotEmpty()) onAddSongs(toAdd)
                showAddSongs = false
            },
            onCancel = { showAddSongs = false }
        )
        return
    }

    val songs = remember(items) { items.map { it.song } }
    val collagePaths = remember(songs) { songs.mapNotNull { it.artworkPath }.distinct().take(4) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(PaletteDeepTeal.copy(alpha = 0.65f), NavyAbyss, NavyAbyss)
                )
            ),
        contentPadding = PaddingValues(bottom = 160.dp)
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.Rounded.ArrowBackIosNew, contentDescription = "Back", tint = PaletteCream)
                    }
                    Box {
                        IconButton(
                            onClick = { showMenu = true },
                            modifier = Modifier.minimumInteractiveComponentSize().testTag("playlist_options_button")
                        ) {
                            Icon(Icons.Rounded.MoreVert, contentDescription = "Playlist options", tint = PaletteCream)
                        }
                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            containerColor = NavySurface
                        ) {
                            DropdownMenuItem(
                                text = { Text("Add Songs", color = PaletteCream) },
                                leadingIcon = { Icon(Icons.Rounded.Add, contentDescription = null, tint = PaletteWarmOrange) },
                                onClick = {
                                    showMenu = false
                                    showAddSongs = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Rename Playlist", color = PaletteCream) },
                                leadingIcon = { Icon(Icons.Rounded.Edit, contentDescription = null, tint = PaletteCream) },
                                onClick = {
                                    showMenu = false
                                    showRenameDialog = true
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Change Cover Art", color = PaletteCream) },
                                leadingIcon = { Icon(Icons.Rounded.Image, contentDescription = null, tint = PaletteCream) },
                                onClick = {
                                    showMenu = false
                                    coverPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Delete Playlist", color = PaletteTerracotta) },
                                leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null, tint = PaletteTerracotta) },
                                onClick = {
                                    showMenu = false
                                    showDeleteConfirm = true
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                PlaylistCollageArtwork(
                    customCoverPath = playlist?.customCoverPath,
                    collageArtworks = collagePaths,
                    contentDescription = playlist?.name ?: "Playlist",
                    modifier = Modifier.size(200.dp),
                    cornerRadius = 18.dp
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = playlist?.name ?: "Playlist",
                    style = MaterialTheme.typography.headlineLarge,
                    color = PaletteCream
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${items.size} song${if (items.size == 1) "" else "s"} · Offline Ready",
                    style = MaterialTheme.typography.bodySmall,
                    color = CreamSoft
                )
                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally)
                ) {
                    Button(
                        onClick = { if (songs.isNotEmpty()) onPlayAll(songs, false) },
                        enabled = songs.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = PaletteWarmOrange, contentColor = NavyAbyss),
                        shape = CircleShape,
                        modifier = Modifier.height(48.dp).weight(1f).testTag("playlist_play_button")
                    ) {
                        Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Play", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = { if (songs.isNotEmpty()) onPlayAll(songs, true) },
                        enabled = songs.isNotEmpty(),
                        border = androidx.compose.foundation.BorderStroke(1.dp, PaletteWarmOrange),
                        shape = CircleShape,
                        modifier = Modifier.height(48.dp).weight(1f).testTag("playlist_shuffle_button")
                    ) {
                        Icon(Icons.Rounded.Shuffle, contentDescription = null, tint = PaletteWarmOrange)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Shuffle", color = PaletteWarmOrange, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (items.isEmpty()) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("This playlist is empty", style = MaterialTheme.typography.titleMedium, color = PaletteCream)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { showAddSongs = true },
                            colors = ButtonDefaults.buttonColors(containerColor = PaletteDeepTeal, contentColor = PaletteCream)
                        ) {
                            Text("Add Songs")
                        }
                    }
                }
            }
        } else {
            itemsIndexed(items, key = { _, item -> item.song.songId }) { index, item ->
                // Continuous 1..N numbering strictly reflecting current playlist order
                Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    SongRowItem(
                        song = item.song,
                        isCurrentSong = item.song.songId == currentPlayingSongId,
                        isPlaying = isPlaying,
                        trackNumber = index + 1,
                        onClick = { onPlaySong(item.song, songs) },
                        onOptionsClick = { onOpenSongOptions(item.song) }
                    )
                }
            }
        }
    }

    if (showRenameDialog && playlist != null) {
        RenameSongDialog(
            currentTitle = playlist.name,
            onConfirm = { newName ->
                onRenamePlaylist(newName)
                showRenameDialog = false
            },
            onDismiss = { showRenameDialog = false }
        )
    }

    if (showDeleteConfirm && playlist != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            containerColor = NavySurface,
            titleContentColor = PaletteCream,
            textContentColor = CreamSoft,
            title = { Text("Delete Playlist?") },
            text = { Text("Delete \"${playlist.name}\"? Your downloaded songs will remain in your library.") },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDeletePlaylist()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PaletteTerracotta, contentColor = PaletteCream)
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel", color = PaletteCream) }
            }
        )
    }
}
