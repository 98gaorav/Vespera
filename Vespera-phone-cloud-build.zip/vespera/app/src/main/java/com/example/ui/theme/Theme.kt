package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val VesperaColorScheme = darkColorScheme(
    primary = PaletteWarmOrange,
    onPrimary = NavyAbyss,
    primaryContainer = PaletteTerracotta,
    onPrimaryContainer = PaletteCream,
    secondary = PaletteDeepTeal,
    onSecondary = PaletteCream,
    secondaryContainer = TealDeep,
    onSecondaryContainer = PaletteCream,
    tertiary = PaletteTerracotta,
    onTertiary = PaletteCream,
    tertiaryContainer = TerracottaDeep,
    onTertiaryContainer = PaletteCream,
    background = NavyAbyss,
    onBackground = PaletteCream,
    surface = NavySurface,
    onSurface = PaletteCream,
    surfaceVariant = PaletteDeepNavy,
    onSurfaceVariant = CreamSoft,
    surfaceContainerLowest = NavyAbyss,
    surfaceContainerLow = NavySurface,
    surfaceContainer = PaletteDeepNavy,
    surfaceContainerHigh = NavyElevated,
    surfaceContainerHighest = TealDeep,
    outline = PaletteDeepTeal,
    outlineVariant = NavyElevated,
    error = PaletteTerracotta,
    onError = PaletteCream,
    errorContainer = TerracottaDeep,
    onErrorContainer = PaletteCream
)

val VesperaShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun VesperaTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = VesperaColorScheme,
        typography = VesperaTypography,
        shapes = VesperaShapes,
        content = content
    )
}
