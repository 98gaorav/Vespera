package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.db.SongEntity
import com.example.data.local.db.UserEntity
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountSwitcherSheet(
    activeUser: UserEntity?,
    accounts: List<UserEntity>,
    onSwitchAccount: (Long) -> Unit,
    onAddAccountLogin: () -> Unit,
    onChangePassword: () -> Unit,
    onSignOutActive: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = NavySurface,
        contentColor = PaletteCream
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Text(
                text = "Switch Account",
                style = MaterialTheme.typography.titleLarge,
                color = PaletteCream
            )
            Text(
                text = "Each account keeps isolated playlists, library & analytics",
                style = MaterialTheme.typography.bodySmall,
                color = CreamSoft
            )
            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(
                modifier = Modifier.heightIn(max = 260.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(accounts, key = { it.userId }) { user ->
                    val isActive = user.userId == activeUser?.userId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isActive) PaletteDeepNavy else NavyAbyss.copy(alpha = 0.55f))
                            .clickable {
                                if (!isActive) onSwitchAccount(user.userId)
                                onDismiss()
                            }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                            .testTag("switch_account_${user.userId}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        UserAvatar(
                            username = user.username,
                            avatarPath = user.avatarPath,
                            avatarColorHex = user.avatarColorHex,
                            size = 42.dp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = user.username,
                                style = MaterialTheme.typography.titleMedium,
                                color = PaletteCream
                            )
                            Text(
                                text = if (isActive) "Active session" else "Tap to switch",
                                style = MaterialTheme.typography.bodySmall,
                                color = if (isActive) PaletteWarmOrange else CreamSoft
                            )
                        }
                        if (isActive) {
                            Icon(
                                imageVector = Icons.Rounded.CheckCircle,
                                contentDescription = "Active account",
                                tint = PaletteWarmOrange
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = PaletteDeepNavy)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable {
                        onDismiss()
                        onAddAccountLogin()
                    }
                    .padding(horizontal = 8.dp, vertical = 12.dp)
                    .testTag("add_another_account_btn"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(PaletteDeepTeal),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.PersonAdd, contentDescription = null, tint = PaletteCream, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(14.dp))
                Text("Add or Login to Another Account", style = MaterialTheme.typography.bodyLarge, color = PaletteCream)
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable {
                        onDismiss()
                        onChangePassword()
                    }
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(PaletteDeepNavy),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.LockReset, contentDescription = null, tint = PaletteWarmOrange, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(14.dp))
                Text("Change Password", style = MaterialTheme.typography.bodyLarge, color = PaletteCream)
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable {
                        onDismiss()
                        onSignOutActive()
                    }
                    .padding(horizontal = 8.dp, vertical = 12.dp)
                    .testTag("sign_out_active_btn"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(TerracottaDeep),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = null, tint = PaletteCream, modifier = Modifier.size(18.dp))
                }
                Spacer(modifier = Modifier.width(14.dp))
                Text("Sign Out", style = MaterialTheme.typography.bodyLarge, color = PaletteTerracotta, fontWeight = FontWeight.SemiBold)
            }

            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}

@Composable
fun MiniPlayerBar(
    song: SongEntity,
    isPlaying: Boolean,
    progressFraction: Float,
    onExpand: () -> Unit,
    onTogglePlayPause: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = PaletteDeepNavy,
        shape = RoundedCornerShape(16.dp),
        tonalElevation = 6.dp,
        shadowElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onExpand)
            .testTag("mini_player_bar")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SongArtwork(
                    artworkPath = song.artworkPath,
                    contentDescription = song.displayTitle,
                    modifier = Modifier.size(44.dp),
                    cornerRadius = 9.dp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song.displayTitle,
                        style = MaterialTheme.typography.titleSmall,
                        color = PaletteCream,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = song.artist,
                        style = MaterialTheme.typography.bodySmall,
                        color = CreamSoft,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(
                    onClick = onTogglePlayPause,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("mini_player_play_pause")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = PaletteWarmOrange
                    )
                }
                IconButton(
                    onClick = onNext,
                    modifier = Modifier.minimumInteractiveComponentSize().testTag("mini_player_next")
                ) {
                    Icon(
                        imageVector = Icons.Rounded.SkipNext,
                        contentDescription = "Next song",
                        tint = PaletteCream
                    )
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .background(NavyAbyss)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progressFraction.coerceIn(0f, 1f))
                        .fillMaxHeight()
                        .background(PaletteWarmOrange)
                )
            }
        }
    }
}
