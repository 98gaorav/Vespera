package com.example.data.network

import com.example.data.local.db.LyricsDao
import com.example.data.local.db.LyricsEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class LrcLine(
    val timestampMs: Long,
    val text: String
)

object LrcParser {
    private val lineRegex = Regex("""^\[(\d{1,3}):(\d{2})(?:\.(\d{1,3}))?](.*)$""")

    fun parse(lrcText: String?): List<LrcLine> {
        if (lrcText.isNullOrBlank()) return emptyList()
        val parsed = mutableListOf<LrcLine>()
        lrcText.lines().forEach { rawLine ->
            val match = lineRegex.find(rawLine.trim()) ?: return@forEach
            val min = match.groupValues[1].toLongOrNull() ?: 0L
            val sec = match.groupValues[2].toLongOrNull() ?: 0L
            val fracRaw = match.groupValues[3]
            val millis = when (fracRaw.length) {
                1 -> (fracRaw.toLongOrNull() ?: 0L) * 100L
                2 -> (fracRaw.toLongOrNull() ?: 0L) * 10L
                3 -> fracRaw.toLongOrNull() ?: 0L
                else -> 0L
            }
            val text = match.groupValues[4].trim()
            if (text.isNotEmpty()) {
                parsed.add(LrcLine(timestampMs = (min * 60_000L) + (sec * 1_000L) + millis, text = text))
            }
        }
        return parsed.sortedBy { it.timestampMs }
    }

    fun findActiveLineIndex(lines: List<LrcLine>, positionMs: Long): Int {
        if (lines.isEmpty()) return -1
        var active = -1
        for (i in lines.indices) {
            if (lines[i].timestampMs <= positionMs) {
                active = i
            } else {
                break
            }
        }
        return active
    }
}

class LyricsRepository(
    private val lyricsDao: LyricsDao,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
) {
    fun observeLyrics(songId: Long): Flow<LyricsEntity?> = lyricsDao.observeLyrics(songId)

    suspend fun saveManualLyrics(
        songId: Long,
        userId: Long,
        plainLyrics: String?,
        syncedLrc: String?
    ) {
        lyricsDao.upsertLyrics(
            LyricsEntity(
                songId = songId,
                userId = userId,
                plainLyrics = plainLyrics?.takeIf { it.isNotBlank() },
                syncedLrc = syncedLrc?.takeIf { it.isNotBlank() },
                source = "MANUAL",
                updatedAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun fetchAndCacheLyricsIfNeeded(
        songId: Long,
        userId: Long,
        title: String,
        artist: String,
        durationMs: Long,
        forceRefresh: Boolean = false
    ): Result<LyricsEntity?> = withContext(Dispatchers.IO) {
        val existing = lyricsDao.getLyricsOnce(songId)
        if (!forceRefresh && existing != null && (!existing.syncedLrc.isNullOrBlank() || !existing.plainLyrics.isNullOrBlank())) {
            return@withContext Result.success(existing)
        }

        runCatching {
            val cleanTitle = cleanTrackQuery(title)
            val cleanArtist = artist.takeIf { it != "Unknown Artist" && it != "YouTube Creator" } ?: ""

            // 1) Try exact LRCLIB /api/get
            var synced: String? = null
            var plain: String? = null

            if (cleanArtist.isNotBlank()) {
                val url = buildString {
                    append("https://lrclib.net/api/get?track_name=")
                    append(URLEncoder.encode(cleanTitle, "UTF-8"))
                    append("&artist_name=")
                    append(URLEncoder.encode(cleanArtist, "UTF-8"))
                    if (durationMs > 0L) {
                        append("&duration=").append((durationMs / 1000L).coerceAtLeast(1L))
                    }
                }
                executeGet(url)?.let { body ->
                    val obj = JSONObject(body)
                    synced = obj.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
                    plain = obj.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" }
                }
            }

            // 2) Fallback to LRCLIB /api/search
            if (synced.isNullOrBlank() && plain.isNullOrBlank()) {
                val query = listOf(cleanTitle, cleanArtist).filter { it.isNotBlank() }.joinToString(" ")
                val searchUrl = "https://lrclib.net/api/search?q=${URLEncoder.encode(query, "UTF-8")}"
                executeGet(searchUrl)?.let { body ->
                    val arr = JSONArray(body)
                    if (arr.length() > 0) {
                        // Prefer result with syncedLyrics
                        var best = arr.getJSONObject(0)
                        for (i in 0 until arr.length()) {
                            val cand = arr.getJSONObject(i)
                            if (cand.optString("syncedLyrics").isNotBlank() && cand.optString("syncedLyrics") != "null") {
                                best = cand
                                break
                            }
                        }
                        synced = best.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
                        plain = best.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" }
                    }
                }
            }

            if (!synced.isNullOrBlank() || !plain.isNullOrBlank()) {
                val entity = LyricsEntity(
                    songId = songId,
                    userId = userId,
                    plainLyrics = plain,
                    syncedLrc = synced,
                    source = "LRCLIB",
                    updatedAt = System.currentTimeMillis()
                )
                lyricsDao.upsertLyrics(entity)
                entity
            } else {
                existing
            }
        }
    }

    private fun executeGet(url: String): String? {
        val req = Request.Builder()
            .url(url)
            .header("User-Agent", "VesperaOfflinePlayer/1.0")
            .build()
        return client.newCall(req).execute().use { resp ->
            if (resp.isSuccessful) resp.body?.string() else null
        }
    }

    private fun cleanTrackQuery(raw: String): String {
        return raw
            .replace(Regex("""\s*\([^)]*(?:official|audio|video|lyrics|hd|4k|mv)[^)]*\)""", RegexOption.IGNORE_CASE), "")
            .replace(Regex("""\s*\[[^]]*(?:official|audio|video|lyrics|hd|4k|mv)[^]]*]""", RegexOption.IGNORE_CASE), "")
            .trim()
    }
}
