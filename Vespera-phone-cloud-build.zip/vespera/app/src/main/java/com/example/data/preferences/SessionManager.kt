package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "vespera_session")

class SessionManager(private val context: Context) {

    private object Keys {
        val ACTIVE_USER_ID = longPreferencesKey("active_user_id")
        val SIGNED_IN_USER_IDS = stringSetPreferencesKey("signed_in_user_ids")
        val HAS_SEEN_SPLASH = booleanPreferencesKey("has_seen_splash")
    }

    val activeUserIdFlow: Flow<Long?> = context.dataStore.data.map { prefs ->
        val id = prefs[Keys.ACTIVE_USER_ID]
        if (id != null && id > 0L) id else null
    }

    val signedInUserIdsFlow: Flow<Set<Long>> = context.dataStore.data.map { prefs ->
        prefs[Keys.SIGNED_IN_USER_IDS]?.mapNotNull { it.toLongOrNull() }?.toSet() ?: emptySet()
    }

    suspend fun setActiveUser(userId: Long) {
        context.dataStore.edit { prefs ->
            prefs[Keys.ACTIVE_USER_ID] = userId
            val currentSet = prefs[Keys.SIGNED_IN_USER_IDS]?.toMutableSet() ?: mutableSetOf()
            currentSet.add(userId.toString())
            prefs[Keys.SIGNED_IN_USER_IDS] = currentSet
        }
    }

    suspend fun signOutActiveUser(): Long? {
        var nextUserId: Long? = null
        context.dataStore.edit { prefs ->
            val current = prefs[Keys.ACTIVE_USER_ID]
            val set = prefs[Keys.SIGNED_IN_USER_IDS]?.toMutableSet() ?: mutableSetOf()
            if (current != null) {
                set.remove(current.toString())
            }
            prefs[Keys.SIGNED_IN_USER_IDS] = set
            val remaining = set.firstOrNull()?.toLongOrNull()
            nextUserId = remaining
            if (remaining != null) {
                prefs[Keys.ACTIVE_USER_ID] = remaining
            } else {
                prefs.remove(Keys.ACTIVE_USER_ID)
            }
        }
        return nextUserId
    }

    suspend fun signOutAll() {
        context.dataStore.edit { prefs ->
            prefs.remove(Keys.ACTIVE_USER_ID)
            prefs.remove(Keys.SIGNED_IN_USER_IDS)
        }
    }
}
