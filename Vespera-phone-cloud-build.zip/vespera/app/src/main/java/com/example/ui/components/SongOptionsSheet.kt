package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.db.PlaylistWithMeta
import com.example.data.local.db.SongEntity
import com.example.ui.theme.*
import com.example.ui.util.formatDurationMs

@Composable
fun SongRowItem(
    song: SongEntity,
    isCurrentSong: Boolean,
    isPlaying: Boolean,
    trackNumber: Int? = null,
    onClick: () -> Unit,
    onOptionsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgColor by animateColorAsState(
        targetValue = if (isCurrentSong) PaletteDeepNavy.copy(alpha = 0.85f) else NavySurface.copy(alpha = 0.55f),
        label = "song_row_bg"
    )
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(bgColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (trackNumber != null) {
            Text(
                text = "$trackNumber",
                style = MaterialTheme.typography.labelMedium,
                color = if (isCurrentSong) PaletteWarmOrange else CreamSoft,
                modifier = Modifier.width(26.dp)
            )
        }
        Box(contentAlignment = Alignment.Center) {
            SongArtwork(
                artworkPath = song.artworkPath,
                contentDescription = "${song.displayTitle} artwork",
                modifier = Modifier.size(52.dp),
                cornerRadius = 10.dp
            )
            if (isCurrentSong) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(NavyAbyss.copy(alpha = 0.55f)),
                    contentAlignment = Alignment.Center
                ) {
                    AnimatedEqualizerBars(isPlaying = isPlaying)
                }
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = song.displayTitle,
                style = MaterialTheme.typography.titleMedium,
                color = if (isCurrentSong) PaletteWarmOrange else PaletteCream,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (song.isAvailableOffline) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = "Available offline",
                        tint = PaletteDeepTeal,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                }
                Text(
                    text = "${song.artist} · ${formatDurationMs(song.durationMs)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CreamSoft,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        IconButton(
            onClick = onOptionsClick,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .testTag("song_options_${song.songId}")
        ) {
            Icon(
                imageVector = Icons.Rounded.MoreVert,
                contentDescription = "Song options for ${song.displayTitle}",
                tint = CreamSoft
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SongOptionsSheet(
    song: SongEntity,
    onDismiss: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onPlayOnRepeat: () -> Unit,
    onRenameSong: () -> Unit,
    onChangeArtwork: () -> Unit,
    onViewDetails: () -> Unit,
    onDeleteSong: () -> Unit,
    extraRemoveFromPlaylistLabel: String? = null,
    onRemoveFromPlaylist: (() -> Unit)? = null
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = NavySurface,
        contentColor = PaletteCream
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                SongArtwork(
                    artworkPath = song.artworkPath,
                    contentDescription = song.displayTitle,
                    modifier = Modifier.size(56.dp),
                    cornerRadius = 12.dp
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song.displayTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = PaletteCream,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = song.artist,
                        style = MaterialTheme.typography.bodySmall,
                        color = CreamSoft,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        color = PaletteDeepNavy,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "Song played: ${song.playCount}",
                            style = MaterialTheme.typography.labelSmall,
                            color = PaletteWarmOrange,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = PaletteDeepNavy)
            Spacer(modifier = Modifier.height(6.dp))

            SheetOptionRow(Icons.AutoMirrored.Rounded.PlaylistAdd, "Add to playlist", "add_to_playlist_option") {
                onDismiss()
                onAddToPlaylist()
            }
            SheetOptionRow(Icons.Rounded.RepeatOne, "Play on repeat", "play_on_repeat_option") {
                onDismiss()
                onPlayOnRepeat()
            }
            SheetOptionRow(Icons.Rounded.Edit, "Rename song", "rename_song_option") {
                onDismiss()
                onRenameSong()
            }
            SheetOptionRow(Icons.Rounded.Image, "Change song artwork", "change_artwork_option") {
                onDismiss()
                onChangeArtwork()
            }
            SheetOptionRow(Icons.Rounded.Info, "View song details", "view_details_option") {
                onDismiss()
                onViewDetails()
            }
            if (extraRemoveFromPlaylistLabel != null && onRemoveFromPlaylist != null) {
                SheetOptionRow(Icons.Rounded.PlaylistRemove, extraRemoveFromPlaylistLabel, "remove_from_playlist_option") {
                    onDismiss()
                    onRemoveFromPlaylist()
                }
            }
            SheetOptionRow(
                icon = Icons.Rounded.DeleteForever,
                label = "Delete downloaded song",
                testTag = "delete_song_option",
                tint = PaletteTerracotta
            ) {
                onDismiss()
                onDeleteSong()
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun SheetOptionRow(
    icon: ImageVector,
    label: String,
    testTag: String,
    tint: androidx.compose.ui.graphics.Color = PaletteCream,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 12.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = tint)
        Spacer(modifier = Modifier.width(16.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
            color = tint
        )
    }
}

@Composable
fun AddToPlaylistDialog(
    song: SongEntity,
    playlists: List<PlaylistWithMeta>,
    containingPlaylistIds: List<Long>,
    onTogglePlaylist: (PlaylistWithMeta) -> Unit,
    onCreateNewPlaylist: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NavySurface,
        titleContentColor = PaletteCream,
        textContentColor = PaletteCream,
        title = {
            Column {
                Text("Add to Playlist", style = MaterialTheme.typography.titleLarge)
                Text(
                    text = song.displayTitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = CreamSoft,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        },
        text = {
            if (playlists.isEmpty()) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "You haven't created any playlists yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CreamSoft
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            onDismiss()
                            onCreateNewPlaylist()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PaletteWarmOrange, contentColor = NavyAbyss)
                    ) {
                        Icon(Icons.Rounded.Add, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Create Playlist")
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 320.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(playlists, key = { it.playlist.playlistId }) { item ->
                        val isAdded = item.playlist.playlistId in containingPlaylistIds
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isAdded) PaletteDeepNavy else NavyAbyss.copy(alpha = 0.5f))
                                .clickable { onTogglePlaylist(item) }
                                .padding(10.dp)
                                .testTag("playlist_toggle_${item.playlist.playlistId}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PlaylistCollageArtwork(
                                customCoverPath = item.playlist.customCoverPath,
                                collageArtworks = item.collageArtworks,
                                contentDescription = item.playlist.name,
                                modifier = Modifier.size(44.dp),
                                cornerRadius = 8.dp
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.playlist.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = PaletteCream,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${item.songCount} song${if (item.songCount == 1) "" else "s"}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CreamSoft
                                )
                            }
                            Icon(
                                imageVector = if (isAdded) Icons.Rounded.CheckCircle else Icons.Rounded.AddCircleOutline,
                                contentDescription = if (isAdded) "Added" else "Add",
                                tint = if (isAdded) PaletteWarmOrange else CreamSoft
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Done", color = PaletteWarmOrange)
            }
        }
    )
}

@Composable
fun RenameSongDialog(
    currentTitle: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember(currentTitle) { mutableStateOf(currentTitle) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NavySurface,
        titleContentColor = PaletteCream,
        title = { Text("Rename Song", style = MaterialTheme.typography.titleLarge) },
        text = {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                singleLine = true,
                label = { Text("Song title") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PaletteWarmOrange,
                    unfocusedBorderColor = PaletteDeepTeal,
                    focusedTextColor = PaletteCream,
                    unfocusedTextColor = PaletteCream,
                    focusedLabelColor = PaletteWarmOrange,
                    unfocusedLabelColor = CreamSoft
                ),
                modifier = Modifier.fillMaxWidth().testTag("rename_song_input")
            )
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(title) },
                enabled = title.trim().isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = PaletteWarmOrange, contentColor = NavyAbyss),
                modifier = Modifier.testTag("rename_song_confirm")
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = CreamSoft)
            }
        }
    )
}

@Composable
fun DeleteSongConfirmDialog(
    songTitle: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = NavySurface,
        titleContentColor = PaletteCream,
        textContentColor = CreamSoft,
        title = { Text("Delete Downloaded Song?", style = MaterialTheme.typography.titleLarge) },
        text = {
            Text("Permanently remove \"$songTitle\" from offline storage and all playlists? This cannot be undone.")
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = PaletteTerracotta, contentColor = PaletteCream),
                modifier = Modifier.testTag("confirm_delete_song")
            ) {
                Text("Delete")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = PaletteCream)
            }
        }
    )
}
