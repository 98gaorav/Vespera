package com.example.data.repository

import android.net.Uri
import com.example.data.local.db.*
import com.example.data.local.storage.LocalStorageManager
import com.example.data.preferences.SessionManager
import com.example.security.PasswordHasher
import com.example.ui.theme.AvatarPaletteHex
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlin.math.abs

class AuthRepository(
    private val userDao: UserDao,
    private val settingsDao: UserSettingsDao,
    private val sessionManager: SessionManager,
    private val storageManager: LocalStorageManager
) {
    val activeUserId: Flow<Long?> = sessionManager.activeUserIdFlow
    val signedInUserIds: Flow<Set<Long>> = sessionManager.signedInUserIdsFlow

    @OptIn(ExperimentalCoroutinesApi::class)
    val activeUser: Flow<UserEntity?> = activeUserId.flatMapLatest { id ->
        if (id == null) flowOf(null) else userDao.observeUserById(id)
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val signedInAccounts: Flow<List<UserEntity>> = signedInUserIds.flatMapLatest { ids ->
        if (ids.isEmpty()) flowOf(emptyList()) else userDao.observeUsersByIds(ids.toList())
    }

    val allRegisteredAccounts: Flow<List<UserEntity>> = userDao.observeAllUsers()

    suspend fun signUp(username: String, password: String, confirmPassword: String): Result<UserEntity> {
        val cleanName = username.trim()
        if (cleanName.length < 3) {
            return Result.failure(IllegalArgumentException("Username must be at least 3 characters."))
        }
        if (!cleanName.matches(Regex("^[a-zA-Z0-9_.-]+$"))) {
            return Result.failure(IllegalArgumentException("Username may only contain letters, numbers, '.', '-', or '_'."))
        }
        if (password.length < 6) {
            return Result.failure(IllegalArgumentException("Password must be at least 6 characters."))
        }
        if (password != confirmPassword) {
            return Result.failure(IllegalArgumentException("Passwords do not match."))
        }
        if (userDao.findByUsername(cleanName) != null) {
            return Result.failure(IllegalStateException("Username '$cleanName' is already taken."))
        }

        val salt = PasswordHasher.generateSalt()
        val hash = PasswordHasher.hashPassword(password, salt)
        val colorHex = AvatarPaletteHex[abs(cleanName.lowercase().hashCode()) % AvatarPaletteHex.size]
        val newUser = UserEntity(
            username = cleanName,
            passwordHash = hash,
            salt = salt,
            avatarColorHex = colorHex
        )
        val insertedId = userDao.insertUser(newUser)
        val savedUser = newUser.copy(userId = insertedId)
        settingsDao.upsertSettings(UserSettingsEntity(userId = insertedId))
        sessionManager.setActiveUser(insertedId)
        return Result.success(savedUser)
    }

    suspend fun login(username: String, password: String): Result<UserEntity> {
        val cleanName = username.trim()
        if (cleanName.isBlank() || password.isBlank()) {
            return Result.failure(IllegalArgumentException("Please enter your username and password."))
        }
        val user = userDao.findByUsername(cleanName)
            ?: return Result.failure(IllegalArgumentException("Account not found."))
        val valid = PasswordHasher.verifyPassword(password, user.salt, user.passwordHash)
        if (!valid) {
            return Result.failure(IllegalArgumentException("Incorrect password."))
        }
        if (settingsDao.getSettingsOnce(user.userId) == null) {
            settingsDao.upsertSettings(UserSettingsEntity(userId = user.userId))
        }
        sessionManager.setActiveUser(user.userId)
        return Result.success(user)
    }

    suspend fun switchAccount(userId: Long): Result<Unit> {
        val user = userDao.getUserById(userId)
            ?: return Result.failure(IllegalStateException("Account no longer exists."))
        sessionManager.setActiveUser(user.userId)
        return Result.success(Unit)
    }

    suspend fun signOutActive(): Long? = sessionManager.signOutActiveUser()

    suspend fun signOutAll() = sessionManager.signOutAll()

    suspend fun changePassword(
        userId: Long,
        currentPassword: String,
        newPassword: String,
        confirmNewPassword: String
    ): Result<Unit> {
        val user = userDao.getUserById(userId)
            ?: return Result.failure(IllegalStateException("User not found."))
        if (!PasswordHasher.verifyPassword(currentPassword, user.salt, user.passwordHash)) {
            return Result.failure(IllegalArgumentException("Current password is incorrect."))
        }
        if (newPassword.length < 6) {
            return Result.failure(IllegalArgumentException("New password must be at least 6 characters."))
        }
        if (newPassword != confirmNewPassword) {
            return Result.failure(IllegalArgumentException("New passwords do not match."))
        }
        val newSalt = PasswordHasher.generateSalt()
        val newHash = PasswordHasher.hashPassword(newPassword, newSalt)
        userDao.updateUser(user.copy(salt = newSalt, passwordHash = newHash))
        return Result.success(Unit)
    }

    suspend fun updateProfilePicture(userId: Long, imageUri: Uri): Result<String> = runCatching {
        val user = userDao.getUserById(userId) ?: throw IllegalStateException("User not found")
        val path = storageManager.copyImageUriToAvatar(userId, imageUri)
        storageManager.deleteFileSafely(user.avatarPath)
        userDao.updateUser(user.copy(avatarPath = path))
        path
    }
}

class MusicRepository(
    private val songDao: SongDao,
    private val playlistDao: PlaylistDao,
    private val storageManager: LocalStorageManager
) {
    fun observeAllSongs(userId: Long): Flow<List<SongEntity>> = songDao.observeAllSongs(userId)
    fun observeRecentlyPlayed(userId: Long): Flow<List<SongEntity>> = songDao.observeRecentlyPlayed(userId)
    fun observeRecentlyAdded(userId: Long): Flow<List<SongEntity>> = songDao.observeRecentlyAdded(userId)
    fun observeFavoriteSongs(userId: Long): Flow<List<SongEntity>> = songDao.observeFavoriteSongs(userId)
    fun observeSongById(songId: Long): Flow<SongEntity?> = songDao.observeSongById(songId)
    fun searchSongs(userId: Long, query: String): Flow<List<SongEntity>> = songDao.searchSongs(userId, query)
    fun observeDownloadedCount(userId: Long): Flow<Int> = songDao.observeDownloadedCount(userId)
    fun observeTotalStorageBytes(userId: Long): Flow<Long> = songDao.observeTotalStorageBytes(userId)

    suspend fun getSongById(songId: Long): SongEntity? = songDao.getSongById(songId)

    suspend fun importLocalAudio(userId: Long, uri: Uri): Result<SongEntity> = runCatching {
        val (destFile, meta) = storageManager.copyAudioUriToAppStorage(userId, uri)
        val song = SongEntity(
            ownerUserId = userId,
            originalTitle = meta.title,
            customTitle = meta.title,
            artist = meta.artist,
            album = meta.album,
            durationMs = meta.durationMs,
            artworkPath = meta.artworkPath,
            audioFilePath = destFile.absolutePath,
            fileSizeBytes = meta.fileSizeBytes,
            audioFormat = meta.format,
            sourceType = "LOCAL",
            isAvailableOffline = true
        )
        val id = songDao.insertSong(song)
        song.copy(songId = id)
    }

    suspend fun renameSong(songId: Long, newTitle: String): Result<Unit> = runCatching {
        val clean = newTitle.trim()
        require(clean.isNotEmpty()) { "Song title cannot be blank." }
        songDao.renameSong(songId, clean)
    }

    suspend fun updateSongArtwork(userId: Long, songId: Long, imageUri: Uri): Result<String> = runCatching {
        val existing = songDao.getSongById(songId) ?: throw IllegalStateException("Song not found")
        val path = storageManager.copyImageUriToArtwork(userId, imageUri)
        storageManager.deleteFileSafely(existing.artworkPath)
        songDao.updateArtwork(songId, path)
        path
    }

    suspend fun toggleFavorite(songId: Long) {
        val song = songDao.getSongById(songId) ?: return
        songDao.setFavorite(songId, !song.isFavorite)
    }

    suspend fun deleteSongPermanently(songId: Long) {
        val song = songDao.getSongById(songId) ?: return
        val affectedPlaylists = playlistDao.observePlaylistIdsContainingSong(songId).first()
        songDao.deleteSongById(songId)
        playlistDao.renumberAllPlaylistsContainingSong(songId, affectedPlaylists)
        storageManager.deleteFileSafely(song.audioFilePath)
        storageManager.deleteFileSafely(song.artworkPath)
    }
}

class PlaylistRepository(
    private val playlistDao: PlaylistDao,
    private val storageManager: LocalStorageManager
) {
    fun observePlaylistsWithMeta(userId: Long): Flow<List<PlaylistWithMeta>> {
        return playlistDao.observePlaylists(userId).flatMapLatest { playlists ->
            if (playlists.isEmpty()) {
                flowOf(emptyList())
            } else {
                combine(
                    playlists.map { playlist ->
                        playlistDao.observeSongsInPlaylist(playlist.playlistId).map { items ->
                            PlaylistWithMeta(
                                playlist = playlist,
                                songCount = items.size,
                                collageArtworks = items.mapNotNull { it.song.artworkPath }.distinct().take(4)
                            )
                        }
                    }
                ) { array -> array.toList() }
            }
        }
    }

    fun observeRecentlyPlayedPlaylists(userId: Long): Flow<List<PlaylistWithMeta>> {
        return playlistDao.observeRecentlyPlayedPlaylists(userId).flatMapLatest { playlists ->
            if (playlists.isEmpty()) {
                flowOf(emptyList())
            } else {
                combine(
                    playlists.map { playlist ->
                        playlistDao.observeSongsInPlaylist(playlist.playlistId).map { items ->
                            PlaylistWithMeta(
                                playlist = playlist,
                                songCount = items.size,
                                collageArtworks = items.mapNotNull { it.song.artworkPath }.distinct().take(4)
                            )
                        }
                    }
                ) { array -> array.toList() }
            }
        }
    }

    fun observePlaylistById(playlistId: Long): Flow<PlaylistEntity?> = playlistDao.observePlaylistById(playlistId)
    fun observeSongsInPlaylist(playlistId: Long): Flow<List<PlaylistSongItem>> = playlistDao.observeSongsInPlaylist(playlistId)
    fun observePlaylistIdsContainingSong(songId: Long): Flow<List<Long>> = playlistDao.observePlaylistIdsContainingSong(songId)
    fun searchPlaylists(userId: Long, query: String): Flow<List<PlaylistEntity>> = playlistDao.searchPlaylists(userId, query)

    suspend fun createPlaylist(
        userId: Long,
        name: String,
        coverUri: Uri?,
        initialSongIds: List<Long>
    ): Result<Long> = runCatching {
        val cleanName = name.trim()
        require(cleanName.isNotEmpty()) { "Playlist name cannot be empty." }
        val coverPath = coverUri?.let { storageManager.copyImageUriToArtwork(userId, it) }
        val playlistId = playlistDao.insertPlaylist(
            PlaylistEntity(
                ownerUserId = userId,
                name = cleanName,
                customCoverPath = coverPath
            )
        )
        if (initialSongIds.isNotEmpty()) {
            playlistDao.addSongsPreventDuplicates(playlistId, initialSongIds)
        }
        playlistId
    }

    suspend fun addSongsToPlaylist(playlistId: Long, songIds: List<Long>) {
        playlistDao.addSongsPreventDuplicates(playlistId, songIds)
    }

    suspend fun toggleSongInPlaylist(playlistId: Long, songId: Long): Boolean {
        return if (playlistDao.isSongInPlaylist(playlistId, songId)) {
            playlistDao.removeSongAndRenumber(playlistId, songId)
            false // removed
        } else {
            playlistDao.addSongsPreventDuplicates(playlistId, listOf(songId))
            true // added
        }
    }

    suspend fun removeSongFromPlaylist(playlistId: Long, songId: Long) {
        playlistDao.removeSongAndRenumber(playlistId, songId)
    }

    suspend fun renamePlaylist(playlistId: Long, newName: String) {
        val clean = newName.trim()
        if (clean.isNotEmpty()) {
            playlistDao.renamePlaylist(playlistId, clean, System.currentTimeMillis())
        }
    }

    suspend fun updatePlaylistCover(userId: Long, playlistId: Long, coverUri: Uri) {
        val existing = playlistDao.getPlaylistById(playlistId)
        val path = storageManager.copyImageUriToArtwork(userId, coverUri)
        storageManager.deleteFileSafely(existing?.customCoverPath)
        playlistDao.updatePlaylistCover(playlistId, path, System.currentTimeMillis())
    }

    suspend fun deletePlaylist(playlistId: Long) {
        val existing = playlistDao.getPlaylistById(playlistId)
        playlistDao.deletePlaylistById(playlistId)
        storageManager.deleteFileSafely(existing?.customCoverPath)
    }
}

enum class AnalyticsRange(val label: String) {
    DAY("Day"),
    WEEK("Week"),
    MONTH("Month"),
    ALL_TIME("All Time")
}

data class ActivityPoint(
    val label: String,
    val playCount: Int,
    val listeningMinutes: Float
)

data class SongRankItem(
    val rank: Int,
    val song: SongEntity,
    val playsInRange: Int
)

data class AnalyticsSnapshot(
    val range: AnalyticsRange = AnalyticsRange.ALL_TIME,
    val totalSongsDownloaded: Int = 0,
    val totalPlays: Int = 0,
    val totalListeningMs: Long = 0L,
    val mostPlayedSong: SongEntity? = null,
    val mostPlayedArtist: String? = null,
    val mostPlayedPlaylist: PlaylistEntity? = null,
    val rankedSongs: List<SongRankItem> = emptyList(),
    val activityPoints: List<ActivityPoint> = emptyList()
)

class AnalyticsRepository(
    private val songDao: SongDao,
    private val playlistDao: PlaylistDao,
    private val historyDao: PlaybackHistoryDao
) {
    fun observeAnalytics(userId: Long, range: AnalyticsRange): Flow<AnalyticsSnapshot> {
        val now = System.currentTimeMillis()
        val since = when (range) {
            AnalyticsRange.DAY -> now - 24L * 60L * 60L * 1000L
            AnalyticsRange.WEEK -> now - 7L * 24L * 60L * 60L * 1000L
            AnalyticsRange.MONTH -> now - 30L * 24L * 60L * 60L * 1000L
            AnalyticsRange.ALL_TIME -> 0L
        }

        return combine(
            songDao.observeAllSongs(userId),
            historyDao.observeHistorySince(userId, since),
            playlistDao.observePlaylists(userId)
        ) { songs, history, playlists ->
            val songById = songs.associateBy { it.songId }
            val playlistById = playlists.associateBy { it.playlistId }

            val totalPlays = if (range == AnalyticsRange.ALL_TIME) {
                maxOf(history.size, songs.sumOf { it.playCount })
            } else {
                history.size
            }

            val totalListeningMs = history.sumOf { it.durationListenedMs }

            val playsPerSong: Map<Long, Int> = if (range == AnalyticsRange.ALL_TIME && history.isEmpty()) {
                songs.filter { it.playCount > 0 }.associate { it.songId to it.playCount }
            } else {
                val fromHistory = history.groupingBy { it.songId }.eachCount()
                if (range == AnalyticsRange.ALL_TIME) {
                    songs.associate { s ->
                        s.songId to maxOf(s.playCount, fromHistory[s.songId] ?: 0)
                    }.filterValues { it > 0 }
                } else {
                    fromHistory
                }
            }

            val rankedSongs = playsPerSong.entries
                .mapNotNull { (id, count) -> songById[id]?.let { it to count } }
                .sortedByDescending { it.second }
                .mapIndexed { idx, (song, count) ->
                    SongRankItem(rank = idx + 1, song = song, playsInRange = count)
                }

            val mostPlayedSong = rankedSongs.firstOrNull()?.song

            val mostPlayedArtist = rankedSongs
                .groupBy { it.song.artist }
                .mapValues { (_, list) -> list.sumOf { it.playsInRange } }
                .maxByOrNull { it.value }
                ?.key

            val topPlaylistId = history
                .mapNotNull { it.playlistId }
                .groupingBy { it }
                .eachCount()
                .maxByOrNull { it.value }
                ?.key
            val mostPlayedPlaylist = topPlaylistId?.let { playlistById[it] }

            val activityPoints = buildActivityBuckets(history, range, now)

            AnalyticsSnapshot(
                range = range,
                totalSongsDownloaded = songs.size,
                totalPlays = totalPlays,
                totalListeningMs = totalListeningMs,
                mostPlayedSong = mostPlayedSong,
                mostPlayedArtist = mostPlayedArtist,
                mostPlayedPlaylist = mostPlayedPlaylist,
                rankedSongs = rankedSongs,
                activityPoints = activityPoints
            )
        }
    }

    private fun buildActivityBuckets(
        history: List<PlaybackHistoryEntity>,
        range: AnalyticsRange,
        now: Long
    ): List<ActivityPoint> {
        val cal = java.util.Calendar.getInstance()
        return when (range) {
            AnalyticsRange.DAY -> {
                // 6 buckets of 4 hours each across last 24h
                (5 downTo 0).map { offset ->
                    val end = now - offset * 4L * 3600_000L
                    val start = end - 4L * 3600_000L
                    cal.timeInMillis = end
                    val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
                    val items = history.filter { it.playedAt in start until end }
                    ActivityPoint(
                        label = "${hour}h",
                        playCount = items.size,
                        listeningMinutes = items.sumOf { it.durationListenedMs } / 60_000f
                    )
                }
            }
            AnalyticsRange.WEEK -> {
                val dayFmt = java.text.SimpleDateFormat("EEE", java.util.Locale.getDefault())
                (6 downTo 0).map { daysAgo ->
                    val end = now - daysAgo * 86_400_000L
                    val start = end - 86_400_000L
                    val items = history.filter { it.playedAt in start until end }
                    ActivityPoint(
                        label = dayFmt.format(java.util.Date(end)),
                        playCount = items.size,
                        listeningMinutes = items.sumOf { it.durationListenedMs } / 60_000f
                    )
                }
            }
            AnalyticsRange.MONTH -> {
                (3 downTo 0).map { weekAgo ->
                    val end = now - weekAgo * 7L * 86_400_000L
                    val start = end - 7L * 86_400_000L
                    val items = history.filter { it.playedAt in start until end }
                    ActivityPoint(
                        label = "W${4 - weekAgo}",
                        playCount = items.size,
                        listeningMinutes = items.sumOf { it.durationListenedMs } / 60_000f
                    )
                }
            }
            AnalyticsRange.ALL_TIME -> {
                val monthFmt = java.text.SimpleDateFormat("MMM", java.util.Locale.getDefault())
                (5 downTo 0).map { monthsAgo ->
                    val end = now - monthsAgo * 30L * 86_400_000L
                    val start = end - 30L * 86_400_000L
                    val items = history.filter { it.playedAt in start until end }
                    ActivityPoint(
                        label = monthFmt.format(java.util.Date(end)),
                        playCount = items.size,
                        listeningMinutes = items.sumOf { it.durationListenedMs } / 60_000f
                    )
                }
            }
        }
    }
}
