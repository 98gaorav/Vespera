package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.data.local.db.UserEntity
import com.example.ui.components.UserAvatar
import com.example.ui.components.VesperaModularLogo
import com.example.ui.theme.*

@Composable
fun LoginScreen(
    existingAccounts: List<UserEntity>,
    authError: String?,
    isBusy: Boolean,
    onClearError: () -> Unit,
    onLogin: (username: String, password: String) -> Unit,
    onQuickSwitch: (Long) -> Unit,
    onNavigateToSignUp: () -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(PaletteDeepNavy, NavyAbyss, NavyAbyss)
                )
            )
            .safeDrawingPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 520.dp)
                .align(Alignment.Center)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            VesperaModularLogo(size = 86.dp, glowProgress = 0.45f)
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Welcome Back",
                style = MaterialTheme.typography.headlineLarge,
                color = PaletteCream
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Sign in with your Vespera username",
                style = MaterialTheme.typography.bodyMedium,
                color = CreamSoft
            )

            Spacer(modifier = Modifier.height(28.dp))

            OutlinedTextField(
                value = username,
                onValueChange = {
                    username = it
                    onClearError()
                },
                label = { Text("Username") },
                leadingIcon = { Icon(Icons.Rounded.Person, contentDescription = null, tint = PaletteWarmOrange) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                colors = authTextFieldColors(),
                modifier = Modifier.fillMaxWidth().testTag("login_username_input")
            )

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = password,
                onValueChange = {
                    password = it
                    onClearError()
                },
                label = { Text("Password") },
                leadingIcon = { Icon(Icons.Rounded.Lock, contentDescription = null, tint = PaletteWarmOrange) },
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            imageVector = if (passwordVisible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                            contentDescription = "Toggle password visibility",
                            tint = CreamSoft
                        )
                    }
                },
                singleLine = true,
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                colors = authTextFieldColors(),
                modifier = Modifier.fillMaxWidth().testTag("login_password_input")
            )

            AnimatedVisibility(visible = authError != null) {
                Surface(
                    color = TerracottaDeep,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(top = 14.dp)
                ) {
                    Text(
                        text = authError.orEmpty(),
                        style = MaterialTheme.typography.bodySmall,
                        color = PaletteCream,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            Button(
                onClick = { onLogin(username, password) },
                enabled = !isBusy,
                colors = ButtonDefaults.buttonColors(
                    containerColor = PaletteWarmOrange,
                    contentColor = NavyAbyss
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("login_submit_button")
            ) {
                if (isBusy) {
                    CircularProgressIndicator(color = NavyAbyss, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Text("Sign In", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedButton(
                onClick = {
                    onClearError()
                    onNavigateToSignUp()
                },
                border = androidx.compose.foundation.BorderStroke(1.dp, PaletteDeepTeal),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("go_to_signup_button")
            ) {
                Text("Create New Account", color = PaletteCream)
            }

            if (existingAccounts.isNotEmpty()) {
                Spacer(modifier = Modifier.height(28.dp))
                Text(
                    text = "Saved Local Profiles",
                    style = MaterialTheme.typography.titleSmall,
                    color = CreamSoft
                )
                Spacer(modifier = Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    existingAccounts.forEach { user ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(NavySurface)
                                .clickable { onQuickSwitch(user.userId) }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            UserAvatar(user.username, user.avatarPath, user.avatarColorHex, size = 38.dp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = user.username,
                                style = MaterialTheme.typography.titleMedium,
                                color = PaletteCream,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "Switch",
                                style = MaterialTheme.typography.labelLarge,
                                color = PaletteWarmOrange
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SignUpScreen(
    authError: String?,
    isBusy: Boolean,
    onClearError: () -> Unit,
    onSignUp: (username: String, password: String, confirmPassword: String) -> Unit,
    onBackToLogin: () -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(PaletteDeepNavy, NavyAbyss, NavyAbyss)
                )
            )
            .safeDrawingPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 520.dp)
                .align(Alignment.Center)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        onClearError()
                        onBackToLogin()
                    },
                    modifier = Modifier.minimumInteractiveComponentSize()
                ) {
                    Icon(Icons.Rounded.ArrowBackIosNew, contentDescription = "Back to login", tint = PaletteCream)
                }
                Text("Create Account", style = MaterialTheme.typography.titleLarge, color = PaletteCream)
            }

            Spacer(modifier = Modifier.height(18.dp))
            VesperaModularLogo(size = 76.dp, glowProgress = 0.3f)
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "Your Private Offline Library",
                style = MaterialTheme.typography.headlineMedium,
                color = PaletteCream
            )
            Text(
                text = "Choose a unique username — no email or phone required",
                style = MaterialTheme.typography.bodySmall,
                color = CreamSoft
            )

            Spacer(modifier = Modifier.height(24.dp))

            OutlinedTextField(
                value = username,
                onValueChange = {
                    username = it
                    onClearError()
                },
                label = { Text("Username (min 3 characters)") },
                leadingIcon = { Icon(Icons.Rounded.AlternateEmail, contentDescription = null, tint = PaletteWarmOrange) },
                singleLine = true,
                colors = authTextFieldColors(),
                modifier = Modifier.fillMaxWidth().testTag("signup_username_input")
            )
            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = password,
                onValueChange = {
                    password = it
                    onClearError()
                },
                label = { Text("Password (min 6 characters)") },
                leadingIcon = { Icon(Icons.Rounded.Lock, contentDescription = null, tint = PaletteWarmOrange) },
                trailingIcon = {
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(
                            imageVector = if (passwordVisible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                            contentDescription = "Toggle password",
                            tint = CreamSoft
                        )
                    }
                },
                singleLine = true,
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                colors = authTextFieldColors(),
                modifier = Modifier.fillMaxWidth().testTag("signup_password_input")
            )
            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = confirmPassword,
                onValueChange = {
                    confirmPassword = it
                    onClearError()
                },
                label = { Text("Confirm Password") },
                leadingIcon = { Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = PaletteWarmOrange) },
                singleLine = true,
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                colors = authTextFieldColors(),
                modifier = Modifier.fillMaxWidth().testTag("signup_confirm_input")
            )

            AnimatedVisibility(visible = authError != null) {
                Surface(
                    color = TerracottaDeep,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(top = 14.dp)
                ) {
                    Text(
                        text = authError.orEmpty(),
                        style = MaterialTheme.typography.bodySmall,
                        color = PaletteCream,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(22.dp))

            Button(
                onClick = { onSignUp(username, password, confirmPassword) },
                enabled = !isBusy,
                colors = ButtonDefaults.buttonColors(
                    containerColor = PaletteWarmOrange,
                    contentColor = NavyAbyss
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp).testTag("signup_submit_button")
            ) {
                if (isBusy) {
                    CircularProgressIndicator(color = NavyAbyss, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                } else {
                    Text("Create Account", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
            }
        }
    }
}

@Composable
fun authTextFieldColors(): TextFieldColors = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = PaletteWarmOrange,
    unfocusedBorderColor = PaletteDeepTeal,
    focusedTextColor = PaletteCream,
    unfocusedTextColor = PaletteCream,
    focusedLabelColor = PaletteWarmOrange,
    unfocusedLabelColor = CreamSoft,
    cursorColor = PaletteWarmOrange
)
