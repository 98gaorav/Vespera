package com.example.data.local.storage

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

data class ExtractedAudioMetadata(
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val artworkPath: String?,
    val fileSizeBytes: Long,
    val format: String
)

class LocalStorageManager(private val context: Context) {

    fun audioDir(userId: Long): File =
        File(context.filesDir, "vespera_media/$userId/audio").apply { mkdirs() }

    fun artworkDir(userId: Long): File =
        File(context.filesDir, "vespera_media/$userId/artwork").apply { mkdirs() }

    fun avatarDir(userId: Long): File =
        File(context.filesDir, "vespera_media/$userId/avatar").apply { mkdirs() }

    fun cleanFileName(raw: String): String {
        val cleaned = raw.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            .replace(Regex("_+"), "_")
            .trim('_')
        return cleaned.ifBlank { "track_${System.currentTimeMillis()}" }.take(60)
    }

    fun copyAudioUriToAppStorage(userId: Long, uri: Uri): Pair<File, ExtractedAudioMetadata> {
        val displayName = resolveDisplayName(uri) ?: "Imported_Track.mp3"
        val ext = displayName.substringAfterLast('.', "mp3")
            .lowercase()
            .takeIf { it in setOf("mp3", "m4a", "aac", "ogg", "wav", "flac", "opus", "webm") }
            ?: "mp3"
        val safeBase = cleanFileName(displayName.substringBeforeLast('.'))
        val destFile = File(audioDir(userId), "${safeBase}_${UUID.randomUUID().toString().take(8)}.$ext")

        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(destFile).use { output ->
                input.copyTo(output)
            }
        } ?: throw IllegalStateException("Unable to open selected audio file")

        if (!destFile.exists() || destFile.length() == 0L) {
            destFile.delete()
            throw IllegalStateException("Copied audio file is empty")
        }

        val metadata = extractAudioMetadata(userId, destFile, safeBase.replace('_', ' '), ext.uppercase())
        return destFile to metadata
    }

    fun extractAudioMetadata(
        userId: Long,
        audioFile: File,
        fallbackTitle: String,
        fallbackFormat: String = "M4A"
    ): ExtractedAudioMetadata {
        val retriever = MediaMetadataRetriever()
        var title = fallbackTitle
        var artist = "Unknown Artist"
        var album = "Offline Library"
        var durationMs = 0L
        var artworkPath: String? = null

        try {
            retriever.setDataSource(audioFile.absolutePath)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                ?.takeIf { it.isNotBlank() }?.let { title = it.trim() }
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                ?.takeIf { it.isNotBlank() }?.let { artist = it.trim() }
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
                ?.takeIf { it.isNotBlank() }?.let { album = it.trim() }
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull()?.let { durationMs = it.coerceAtLeast(0L) }

            val artBytes = retriever.embeddedPicture
            if (artBytes != null && artBytes.isNotEmpty()) {
                val artFile = File(artworkDir(userId), "art_${UUID.randomUUID()}.jpg")
                artFile.writeBytes(artBytes)
                artworkPath = artFile.absolutePath
            }
        } catch (_: Exception) {
            // Gracefully fall back if metadata tags are missing
        } finally {
            runCatching { retriever.release() }
        }

        return ExtractedAudioMetadata(
            title = title,
            artist = artist,
            album = album,
            durationMs = durationMs,
            artworkPath = artworkPath,
            fileSizeBytes = audioFile.length(),
            format = fallbackFormat
        )
    }

    fun copyImageUriToArtwork(userId: Long, uri: Uri): String {
        val destFile = File(artworkDir(userId), "art_${UUID.randomUUID()}.jpg")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(destFile).use { output ->
                input.copyTo(output)
            }
        } ?: throw IllegalStateException("Unable to read selected image")
        if (!destFile.exists() || destFile.length() == 0L) {
            destFile.delete()
            throw IllegalStateException("Image file is empty")
        }
        return destFile.absolutePath
    }

    fun copyImageUriToAvatar(userId: Long, uri: Uri): String {
        val destFile = File(avatarDir(userId), "avatar_${UUID.randomUUID()}.jpg")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(destFile).use { output ->
                input.copyTo(output)
            }
        } ?: throw IllegalStateException("Unable to read selected avatar")
        return destFile.absolutePath
    }

    fun deleteFileSafely(path: String?) {
        if (path.isNullOrBlank()) return
        runCatching {
            val file = File(path)
            if (file.exists()) file.delete()
        }
    }

    private fun resolveDisplayName(uri: Uri): String? {
        if (uri.scheme == "file") return File(uri.path ?: return null).name
        return context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
    }
}
