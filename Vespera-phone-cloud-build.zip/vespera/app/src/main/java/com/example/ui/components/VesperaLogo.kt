package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.PaletteCream
import com.example.ui.theme.PaletteDeepNavy
import com.example.ui.theme.PaletteDeepTeal
import com.example.ui.theme.PaletteTerracotta
import com.example.ui.theme.PaletteWarmOrange

/**
 * Modular replaceable Vespera logo asset.
 * Splits the emblem into 4 directional parts (Left, Top, Bottom, Right/Center)
 * so the splash animation can assemble them smoothly from independent directions.
 */
@Composable
fun VesperaModularLogo(
    modifier: Modifier = Modifier,
    size: Dp = 136.dp,
    leftProgress: Float = 1f,
    topProgress: Float = 1f,
    bottomProgress: Float = 1f,
    rightProgress: Float = 1f,
    glowProgress: Float = 0f,
    assembleRotationDeg: Float = 0f
) {
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height
            val cx = w / 2f
            val cy = h / 2f
            val r = minOf(w, h) * 0.42f

            // Finishing glow aura after logo assembly completes
            if (glowProgress > 0.01f) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            PaletteWarmOrange.copy(alpha = 0.42f * glowProgress),
                            PaletteDeepTeal.copy(alpha = 0.22f * glowProgress),
                            Color.Transparent
                        ),
                        center = Offset(cx, cy),
                        radius = r * (1.4f + 0.25f * glowProgress)
                    ),
                    radius = r * 1.65f,
                    center = Offset(cx, cy)
                )
            }

            rotate(degrees = assembleRotationDeg, pivot = Offset(cx, cy)) {
                // 1) LEFT COMPONENT: Deep Teal outer vinyl arc entering from the left
                val leftShift = (1f - leftProgress) * (-w * 0.85f)
                val leftAlpha = leftProgress.coerceIn(0f, 1f)
                if (leftAlpha > 0f) {
                    drawArc(
                        color = PaletteDeepTeal.copy(alpha = leftAlpha),
                        startAngle = 115f,
                        sweepAngle = 155f,
                        useCenter = false,
                        topLeft = Offset(cx - r + leftShift, cy - r),
                        size = Size(r * 2f, r * 2f),
                        style = Stroke(width = w * 0.095f, cap = StrokeCap.Round)
                    )
                }

                // 2) TOP COMPONENT: Cream upper sound-crest arc entering from the top
                val topShift = (1f - topProgress) * (-h * 0.85f)
                val topAlpha = topProgress.coerceIn(0f, 1f)
                if (topAlpha > 0f) {
                    drawArc(
                        color = PaletteCream.copy(alpha = topAlpha),
                        startAngle = 215f,
                        sweepAngle = 120f,
                        useCenter = false,
                        topLeft = Offset(cx - r * 0.72f, cy - r * 0.72f + topShift),
                        size = Size(r * 1.44f, r * 1.44f),
                        style = Stroke(width = w * 0.08f, cap = StrokeCap.Round)
                    )
                }

                // 3) BOTTOM COMPONENT: Terracotta lower crescent entering from the bottom
                val bottomShift = (1f - bottomProgress) * (h * 0.85f)
                val bottomAlpha = bottomProgress.coerceIn(0f, 1f)
                if (bottomAlpha > 0f) {
                    drawArc(
                        color = PaletteTerracotta.copy(alpha = bottomAlpha),
                        startAngle = 25f,
                        sweepAngle = 130f,
                        useCenter = false,
                        topLeft = Offset(cx - r * 0.78f, cy - r * 0.78f + bottomShift),
                        size = Size(r * 1.56f, r * 1.56f),
                        style = Stroke(width = w * 0.085f, cap = StrokeCap.Round)
                    )
                }

                // 4) RIGHT / CENTER COMPONENT: Warm Orange harmonic core & tonearm accent entering from right
                val rightShift = (1f - rightProgress) * (w * 0.85f)
                val rightAlpha = rightProgress.coerceIn(0f, 1f)
                if (rightAlpha > 0f) {
                    scale(scale = 0.65f + 0.35f * rightProgress, pivot = Offset(cx + rightShift, cy)) {
                        drawCircle(
                            color = PaletteDeepNavy.copy(alpha = rightAlpha),
                            radius = r * 0.36f,
                            center = Offset(cx + rightShift, cy)
                        )
                        drawCircle(
                            color = PaletteWarmOrange.copy(alpha = rightAlpha),
                            radius = r * 0.24f,
                            center = Offset(cx + rightShift, cy)
                        )
                        drawLine(
                            color = PaletteWarmOrange.copy(alpha = rightAlpha),
                            start = Offset(cx + r * 0.62f + rightShift, cy - r * 0.52f),
                            end = Offset(cx + r * 0.22f + rightShift, cy + r * 0.05f),
                            strokeWidth = w * 0.075f,
                            cap = StrokeCap.Round
                        )
                        drawCircle(
                            color = PaletteCream.copy(alpha = rightAlpha),
                            radius = r * 0.07f,
                            center = Offset(cx + rightShift, cy)
                        )
                    }
                }
            }
        }
    }
}
