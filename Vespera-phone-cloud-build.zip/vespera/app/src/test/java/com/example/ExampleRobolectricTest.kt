package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.db.*
import com.example.data.network.YouTubeAudioExtractor
import com.example.security.PasswordHasher
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var context: Context
    private lateinit var db: VesperaDatabase

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, VesperaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `app name matches Vespera`() {
        val appName = context.getString(R.string.app_name)
        assertEquals("Vespera", appName)
    }

    @Test
    fun `TEST 1_9_13 - song persists, renames cleanly, and increments play count`() = runTest {
        val userId = db.userDao().insertUser(
            UserEntity(
                username = "alex",
                passwordHash = "hash",
                salt = "salt",
                avatarColorHex = "#B65B3F"
            )
        )
        val songId = db.songDao().insertSong(
            SongEntity(
                ownerUserId = userId,
                originalTitle = "Original Track",
                customTitle = "Original Track",
                artist = "Vespera Artist",
                album = "Sanctuary",
                durationMs = 180_000L,
                audioFilePath = "/tmp/track.m4a",
                isAvailableOffline = true
            )
        )

        // Rename song
        db.songDao().renameSong(songId, "Midnight Acoustic")
        val renamed = db.songDao().getSongById(songId)
        assertNotNull(renamed)
        assertEquals("Midnight Acoustic", renamed!!.displayTitle)
        assertEquals("Original Track", renamed.originalTitle)
        assertEquals("/tmp/track.m4a", renamed.audioFilePath)

        // Increment play count 10 times
        repeat(10) {
            db.songDao().incrementPlayCount(songId, System.currentTimeMillis())
        }
        val afterTen = db.songDao().getSongById(songId)
        assertEquals(10, afterTen?.playCount)
    }

    @Test
    fun `TEST 3_4_5 - playlist numbers 1 to 5, blocks duplicates, and renumbers on removal`() = runTest {
        val userId = db.userDao().insertUser(
            UserEntity(username = "curator", passwordHash = "h", salt = "s", avatarColorHex = "#087586")
        )
        val songIds = (1..5).map { idx ->
            db.songDao().insertSong(
                SongEntity(
                    ownerUserId = userId,
                    originalTitle = "Song $idx",
                    customTitle = "Song $idx",
                    artist = "Artist",
                    album = "Album",
                    durationMs = 120_000L,
                    audioFilePath = "/tmp/s$idx.m4a"
                )
            )
        }
        val playlistId = db.playlistDao().insertPlaylist(
            PlaylistEntity(ownerUserId = userId, name = "Focus Mix")
        )

        // Add 5 songs + attempt adding song 2 again (duplicate must not appear)
        db.playlistDao().addSongsPreventDuplicates(playlistId, songIds)
        db.playlistDao().addSongsPreventDuplicates(playlistId, listOf(songIds[1]))

        val initial = db.playlistDao().getSongsInPlaylistOnce(playlistId)
        assertEquals(5, initial.size)
        assertEquals(listOf(1, 2, 3, 4, 5), initial.map { it.position })

        // Remove song 2 and verify remaining 4 songs renumber 1..4
        db.playlistDao().removeSongAndRenumber(playlistId, songIds[1])
        val afterDelete = db.playlistDao().getSongsInPlaylistOnce(playlistId)
        assertEquals(4, afterDelete.size)
        assertEquals(listOf(1, 2, 3, 4), afterDelete.map { it.position })
        assertEquals(listOf("Song 1", "Song 3", "Song 4", "Song 5"), afterDelete.map { it.song.displayTitle })
    }

    @Test
    fun `TEST 12_14_15 - password hashing, lyrics offline cache, and strict multi-account isolation`() = runTest {
        val saltA = PasswordHasher.generateSalt()
        val hashA = PasswordHasher.hashPassword("secret123", saltA)
        assertTrue(PasswordHasher.verifyPassword("secret123", saltA, hashA))
        assertFalse(PasswordHasher.verifyPassword("wrong", saltA, hashA))

        val userA = db.userDao().insertUser(
            UserEntity(username = "userA", passwordHash = hashA, salt = saltA, avatarColorHex = "#F9BC66")
        )
        val userB = db.userDao().insertUser(
            UserEntity(username = "userB", passwordHash = hashA, salt = saltA, avatarColorHex = "#0A4771")
        )

        val songA = db.songDao().insertSong(
            SongEntity(
                ownerUserId = userA,
                originalTitle = "A Track",
                customTitle = "A Track",
                artist = "Artist A",
                album = "Album A",
                durationMs = 90_000L,
                audioFilePath = "/tmp/a.m4a"
            )
        )
        db.playlistDao().insertPlaylist(PlaylistEntity(ownerUserId = userA, name = "A's Playlist"))
        db.playlistDao().insertPlaylist(PlaylistEntity(ownerUserId = userB, name = "B's Playlist"))

        val songsForA = db.songDao().observeAllSongs(userA).first()
        val songsForB = db.songDao().observeAllSongs(userB).first()
        assertEquals(1, songsForA.size)
        assertEquals(0, songsForB.size)

        val playlistsA = db.playlistDao().observePlaylists(userA).first()
        val playlistsB = db.playlistDao().observePlaylists(userB).first()
        assertEquals(listOf("A's Playlist"), playlistsA.map { it.name })
        assertEquals(listOf("B's Playlist"), playlistsB.map { it.name })

        // Offline lyrics caching
        db.lyricsDao().upsertLyrics(
            LyricsEntity(songId = songA, userId = userA, plainLyrics = "Line one\nLine two", syncedLrc = "[00:05.00] Line one")
        )
        val savedLyrics = db.lyricsDao().getLyricsOnce(songA)
        assertEquals("Line one\nLine two", savedLyrics?.plainLyrics)
        assertEquals("[00:05.00] Line one", savedLyrics?.syncedLrc)
    }

    @Test
    fun `TEST 10 - youtube URL extractor parses standard, short, shorts, and music links`() {
        val extractor = YouTubeAudioExtractor()
        assertEquals("dQw4w9WgXcQ", extractor.extractVideoId("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
        assertEquals("dQw4w9WgXcQ", extractor.extractVideoId("https://youtu.be/dQw4w9WgXcQ?si=abc"))
        assertEquals("dQw4w9WgXcQ", extractor.extractVideoId("https://music.youtube.com/watch?v=dQw4w9WgXcQ"))
        assertEquals("dQw4w9WgXcQ", extractor.extractVideoId("https://youtube.com/shorts/dQw4w9WgXcQ"))
        assertNull(extractor.extractVideoId("https://example.com/not-youtube"))
    }
}
