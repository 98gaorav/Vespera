package com.example

import com.example.data.network.LrcParser
import com.example.domain.shuffle.ShuffleEngine
import org.junit.Assert.*
import org.junit.Test
import kotlin.random.Random

class ShuffleEngineTest {

    @Test
    fun `TEST 6 - shuffle plays all 5 songs once before repeating and preserves current song`() {
        val engine = ShuffleEngine(Random(42))
        val songs = listOf(1L, 2L, 3L, 4L, 5L)

        var state = engine.createNewCycle(songs, preserveCurrentSongId = 2L)
        assertEquals(2L, state.currentSongId)
        assertEquals(5, state.orderedIds.size)
        assertEquals(songs.toSet(), state.orderedIds.toSet())

        val playedInCycle = mutableListOf(state.currentSongId!!)
        repeat(4) {
            val (nextState, nextId) = engine.moveNext(state, songs, repeatPlaylist = false)
            assertNotNull(nextId)
            playedInCycle.add(nextId!!)
            state = nextState
        }

        // All 5 songs played exactly once in the cycle
        assertEquals(5, playedInCycle.size)
        assertEquals(songs.toSet(), playedInCycle.toSet())

        // Repeat OFF stops at end of cycle
        val (_, stopId) = engine.moveNext(state, songs, repeatPlaylist = false)
        assertNull(stopId)

        // Repeat PLAYLIST starts a fresh cycle whose first song does not repeat the previous tail
        val lastOfCycle = playedInCycle.last()
        val (newCycle, firstOfNext) = engine.moveNext(state, songs, repeatPlaylist = true)
        assertNotNull(firstOfNext)
        assertNotEquals(lastOfCycle, firstOfNext)
        assertEquals(songs.toSet(), newCycle.orderedIds.toSet())
    }

    @Test
    fun `syncWithLibrary handles dynamic song additions and removals`() {
        val engine = ShuffleEngine(Random(99))
        val initial = listOf(10L, 20L, 30L)
        val cycle = engine.createNewCycle(initial, preserveCurrentSongId = 20L)

        val updated = engine.syncWithLibrary(cycle, listOf(20L, 30L, 40L, 50L))
        assertEquals(20L, updated.currentSongId)
        assertEquals(setOf(20L, 30L, 40L, 50L), updated.orderedIds.toSet())
        assertFalse(updated.orderedIds.contains(10L))
    }

    @Test
    fun `lrc parser parses synced timestamps and finds active line`() {
        val lrc = """
            [00:05.50] First line
            [00:12.00] Second line
            [00:25.25] Third line
        """.trimIndent()

        val lines = LrcParser.parse(lrc)
        assertEquals(3, lines.size)
        assertEquals(5500L, lines[0].timestampMs)
        assertEquals(0, LrcParser.findActiveLineIndex(lines, 6000L))
        assertEquals(1, LrcParser.findActiveLineIndex(lines, 15000L))
        assertEquals(2, LrcParser.findActiveLineIndex(lines, 30000L))
    }
}
